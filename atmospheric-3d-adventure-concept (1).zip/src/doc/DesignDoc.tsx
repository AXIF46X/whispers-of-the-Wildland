/**
 * DesignDoc.tsx — "Whispers of the Wildland" living Game Design Document.
 * Rendered from data/gdd.ts so the document and the game share one source of
 * truth. Everything herein is original IP created for this project.
 */
import { useState } from "react";
import {
  ArrowLeft,
  AudioLines,
  BookHeart,
  Bug,
  Cpu,
  Droplets,
  Film,
  FlaskConical,
  Gauge,
  Globe2,
  Leaf,
  Lightbulb,
  Map,
  MoonStar,
  Play,
  Puzzle,
  ScrollText,
  ShieldCheck,
  Sparkles,
  Wind,
} from "lucide-react";
import {
  AI_NOTES,
  CREATURES,
  FOLDER_TREE,
  PILLARS,
  REGIONS,
  ROADMAP,
  STORY_BEATS,
  SYSTEMS,
} from "../data/gdd";

const NAV = [
  { id: "vision", label: "Vision & Pillars" },
  { id: "story", label: "Story" },
  { id: "world", label: "The Wildland" },
  { id: "creatures", label: "Creatures" },
  { id: "gameplay", label: "Gameplay & Puzzles" },
  { id: "tech", label: "Technology" },
  { id: "roadmap", label: "Roadmap" },
  { id: "prototype", label: "Phase 1 · This Build" },
];

const STATUS_STYLE: Record<string, string> = {
  PROTOTYPED: "text-ember border-ember/40 bg-ember/10",
  PARTIAL: "text-amber-200/90 border-amber-200/30 bg-amber-200/5",
  PLANNED: "text-moss border-moss/40 bg-moss/5",
};

function Section({
  id,
  eyebrow,
  title,
  lede,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  lede?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-mist/10 py-14 first:border-t-0">
      <p className="font-mono text-[10px] tracking-[0.4em] text-ember">{eyebrow}</p>
      <h2 className="mt-3 font-display text-3xl font-light italic text-[#f6e8cf] md:text-4xl">{title}</h2>
      {lede && <p className="mt-4 max-w-2xl text-sm leading-relaxed text-mist/70">{lede}</p>}
      <div className="mt-8">{children}</div>
    </section>
  );
}

function Img({ src, alt, className }: { src: string; alt: string; className?: string }) {
  const [ok, setOk] = useState(true);
  return (
    <div className={`relative overflow-hidden bg-[#14261a] ${className ?? ""}`}>
      {ok && (
        <img src={src} alt={alt} onError={() => setOk(false)} className="h-full w-full object-cover" loading="lazy" />
      )}
      {!ok && <div className="h-full w-full bg-[radial-gradient(100%_100%_at_30%_20%,#2c4a2e,#0b140d)]" />}
    </div>
  );
}

export default function DesignDoc({ onBack, onPlay }: { onBack: () => void; onPlay: () => void }) {
  return (
    <div className="absolute inset-0 flex flex-col bg-[#0b140d]">
      {/* top bar */}
      <header className="z-40 flex shrink-0 items-center justify-between gap-3 border-b border-mist/10 bg-[#0b140dee] px-4 py-3 backdrop-blur md:px-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-full hairline px-4 py-2 text-xs text-mist/80 transition hover:border-ember/40 hover:text-ember"
        >
          <ArrowLeft size={14} /> Back
        </button>
        <div className="flex items-center gap-3 text-center">
          <ScrollText size={15} className="hidden text-ember md:block" />
          <p className="font-mono text-[10px] tracking-[0.35em] text-mist/70">
            WHISPERS OF THE WILDLAND · GAME DESIGN DOCUMENT · V0.9
          </p>
        </div>
        <button
          onClick={onPlay}
          className="flex items-center gap-2 rounded-full bg-ember px-4 py-2 text-xs font-bold text-[#241708] transition hover:bg-ember-deep"
        >
          <Play size={13} /> Play the prototype
        </button>
      </header>

      <div className="flex min-h-0 flex-1">
        {/* side nav */}
        <nav className="hidden w-56 shrink-0 flex-col gap-1 overflow-y-auto border-r border-mist/10 p-6 lg:flex">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => document.getElementById(n.id)?.scrollIntoView({ behavior: "smooth" })}
              className="rounded-lg px-3 py-2 text-left text-[13px] text-mist/60 transition hover:bg-white/5 hover:text-ember"
            >
              {n.label}
            </button>
          ))}
          <div className="mt-auto rounded-xl hairline p-4 text-[11px] leading-relaxed text-mist/45">
            Original IP notice: every name, creature, region, puzzle and artwork in this
            document was created for Whispers of the Wildland.
          </div>
        </nav>

        {/* content */}
        <main className="wild-scroll min-w-0 flex-1 overflow-y-auto px-5 pb-24 md:px-12">
          {/* hero */}
          <div className="py-12 md:py-16">
            <p className="font-mono text-[10px] tracking-[0.5em] text-moss/80">A LIVING DOCUMENT · UPDATED WITH EACH PHASE</p>
            <h1 className="mt-4 max-w-4xl font-display text-4xl font-light italic leading-tight text-[#f6e8cf] md:text-6xl">
              A forest small enough to fit in your hand, and large enough to get lost in.
            </h1>
            <div className="mt-6 grid max-w-3xl grid-cols-2 gap-3 md:grid-cols-4">
              {[
                { icon: Globe2, k: "GENRE", v: "Atmospheric adventure · puzzle" },
                { icon: Gauge, k: "TARGETS", v: "Android 30/60fps · PC 60+" },
                { icon: Film, k: "LENGTH", v: "8–12h story · 4–6h discoveries" },
                { icon: BookHeart, k: "TONE", v: "Tender, mysterious, wordless" },
              ].map(({ icon: Icon, k, v }) => (
                <div key={k} className="rounded-2xl hairline p-4">
                  <Icon size={15} className="text-ember" />
                  <p className="mt-2 font-mono text-[9px] tracking-[0.3em] text-mist/45">{k}</p>
                  <p className="mt-1 text-[12px] leading-snug text-mist/85">{v}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ------------------------------ VISION ------------------------------ */}
          <Section
            id="vision"
            eyebrow="01 · VISION"
            title="Design pillars"
            lede="Whispers of the Wildland is a 3D atmospheric adventure about being small in a world that is very much alive. It borrows nothing but ambition from the giants of the genre — its characters, language, puzzles and art direction are wholly its own."
          >
            <div className="grid gap-4 md:grid-cols-2">
              {PILLARS.map((p, i) => (
                <div key={p.title} className="group rounded-2xl glass-panel p-6">
                  <p className="font-mono text-[10px] text-ember/70">PILLAR {String(i + 1).padStart(2, "0")}</p>
                  <h3 className="mt-2 font-display text-xl italic text-[#f2ead6]">{p.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mist/70">{p.body}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 grid gap-4 overflow-hidden rounded-3xl hairline md:grid-cols-[2fr_3fr]">
              <Img src="/images/milo.jpg" alt="Milo — concept render" className="min-h-64" />
              <div className="p-6 md:p-8">
                <p className="font-mono text-[10px] tracking-[0.3em] text-ember">THE PROTAGONIST</p>
                <h3 className="mt-2 font-display text-2xl italic text-[#f2ead6]">Milo, the Seed-Engine</h3>
                <p className="mt-3 text-sm leading-relaxed text-mist/70">
                  Milo is a tiny explorer grown from a fallen seed and grafted with fragments of an
                  ancient machine: a heartlight furnace in a cracked husk, four brass-twig legs,
                  one impossibly expressive eye, and a sprout that leans toward whatever Milo
                  cares about. He walks, runs, climbs, crawls, hops gaps, pushes and pulls small
                  objects — and learns new environmental verbs in every region.
                </p>
                <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[12px] text-mist/60">
                  {["Walk / run (analog)", "Climb & crawl", "Short hop", "Push · pull · carry", "Activate plants", "Redirect light & water", "Creature conversation", "Seed-sowing"].map((a) => (
                    <li key={a} className="flex items-center gap-2">
                      <Leaf size={10} className="text-moss" /> {a}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Section>

          {/* ------------------------------ STORY ------------------------------ */}
          <Section
            id="story"
            eyebrow="02 · STORY"
            title="A lullaby the forest forgot"
            lede="Told almost entirely through the environment: broken brass in living roots, drawings under bark, jars of sleeping light, and creatures who remember more than they say. The truth arrives late, and gently."
          >
            <div className="space-y-4">
              {STORY_BEATS.map((b, i) => (
                <div key={b.title} className="flex gap-5 rounded-2xl hairline p-5 md:p-6">
                  <p className="font-display text-3xl font-light italic text-ember/50">{String(i + 1).padStart(2, "0")}</p>
                  <div>
                    <h3 className="font-display text-lg italic text-[#f2ead6]">{b.title}</h3>
                    <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-mist/70">{b.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* ------------------------------ WORLD ------------------------------ */}
          <Section
            id="world"
            eyebrow="03 · WORLD STRUCTURE"
            title="Twelve regions, one living map"
            lede="A connected, streamable world. Each region has its own visual identity, creature cast, hazards, puzzle family, collectibles, hidden areas and ambient soundscape — restored regions visibly heal and repopulate."
          >
            <div className="grid gap-4 md:grid-cols-3">
              <Img src="/images/region-valley.jpg" alt="Mushroom Valley concept" className="min-h-56 rounded-2xl" />
              <Img src="/images/region-stream.jpg" alt="Glass Stream concept" className="min-h-56 rounded-2xl" />
              <Img src="/images/region-workshop.jpg" alt="Forgotten Workshop concept" className="min-h-56 rounded-2xl" />
            </div>
            <div className="mt-6 grid gap-3 md:grid-cols-2">
              {REGIONS.map((r, i) => (
                <div key={r.id} className="rounded-2xl hairline p-5 transition hover:border-moss/35">
                  <div className="flex items-baseline justify-between gap-3">
                    <h4 className="font-display text-lg italic text-[#f2ead6]">
                      <span className="mr-2 font-mono text-[10px] not-italic tracking-widest text-ember/70">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      {r.name}
                    </h4>
                    <span className="font-mono text-[9px] tracking-widest text-moss/60">{r.palette.toUpperCase()}</span>
                  </div>
                  <p className="font-mono text-[10px] italic text-mist/40">— {r.tagline}</p>
                  <p className="mt-2 text-[13px] leading-relaxed text-mist/70">{r.desc}</p>
                  <div className="mt-3 grid gap-1.5 text-[11px] text-mist/55">
                    <p className="flex gap-2"><Wind size={12} className="mt-0.5 shrink-0 text-moss" /> {r.hazard}</p>
                    <p className="flex gap-2"><Puzzle size={12} className="mt-0.5 shrink-0 text-ember" /> {r.puzzle}</p>
                    <p className="flex gap-2"><Bug size={12} className="mt-0.5 shrink-0 text-lume" /> {r.creature}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* ------------------------------ CREATURES ------------------------------ */}
          <Section
            id="creatures"
            eyebrow="04 · CREATURES"
            title="Twenty-two original locals"
            lede="No generic monsters — every creature has a unique silhouette, gait, personality and an invented sound language, communicating through animation and voice rather than exposition."
          >
            <div className="grid gap-3 md:grid-cols-2">
              {CREATURES.map((c) => (
                <div key={c.name} className="flex gap-4 rounded-2xl hairline p-4 transition hover:border-lume/30">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-moss/25 to-lume/10">
                    <Bug size={16} className="text-lume/80" />
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-mist">{c.name}
                      <span className="ml-2 font-mono text-[9px] font-normal tracking-widest text-moss/60">{c.kind.toUpperCase()}</span>
                    </p>
                    <p className="mt-0.5 text-[12px] leading-snug text-mist/60">{c.personality} · {c.sound}</p>
                    <p className="text-[12px] italic leading-snug text-mist/45">{c.signature}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* ------------------------------ GAMEPLAY ------------------------------ */}
          <Section
            id="gameplay"
            eyebrow="05 · GAMEPLAY"
            title="Exploration first, combat never"
            lede="Progress is ability-gated, not XP-gated: new verbs, new regions, creature relationships and puzzle knowledge. Puzzles are multi-step conversations with the ecosystem, with diegetic clues and escalating complexity."
          >
            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl glass-panel p-6">
                <Puzzle size={18} className="text-ember" />
                <h3 className="mt-3 font-display text-xl italic text-[#f2ead6]">Puzzle design law</h3>
                <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-mist/70">
                  {[
                    "Every mechanism is visible and physically readable — no pixel hunting.",
                    "Cause and effect appear immediately (light moves, water flows, plants answer).",
                    "3–4 steps with a clear through-line; difficulty grows by combining known verbs.",
                    "Companions gesture toward the next actionable clue before any hint text exists.",
                    "Progressive hints surface only when playtime-without-progress suggests you're stuck.",
                  ].map((t) => (
                    <li key={t} className="flex gap-2.5">
                      <Lightbulb size={13} className="mt-0.5 shrink-0 text-ember/80" /> {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl glass-panel p-6">
                <FlaskConical size={18} className="text-lume" />
                <h3 className="mt-3 font-display text-xl italic text-[#f2ead6]">The puzzle repertoire</h3>
                <ul className="mt-3 grid gap-1.5 text-[13px] text-mist/70">
                  {[
                    "Ricochet sunbeams off grown crystal (prototyped in this build)",
                    "Fuse dew drops into lenses; burn, reveal, refract",
                    "Wake plants with matched chords of sound",
                    "Arrange glowing caps into rising paths",
                    "Ride wind-carried seeds between platforms",
                    "Commission insect logistics — ferries, couriers, drayage",
                    "Repair gear-looms that grow ratios instead of wheels",
                    "Grow root-bridges by watering the right ancestor",
                    "Cast shadows onto symbols only moonlight can read",
                  ].map((t) => (
                    <li key={t} className="flex gap-2.5">
                      <Sparkles size={12} className="mt-0.5 shrink-0 text-lume/80" /> {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="mt-4 grid gap-4 md:grid-cols-3">
              {[
                { icon: MoonStar, t: "Living ecosystem", d: "Day/night cycle, authored weather, rain and wind, growing plants, fireflies; creatures shelter, sing and migrate with conditions — and with what you've repaired." },
                { icon: Droplets, t: "Reactive materials", d: "Wet grass bends and sheds droplets as Milo pushes through (implemented); flowers turn toward him; mud remembers footprints where the budget allows." },
                { icon: AudioLines, t: "Dynamic original score", d: "Generative layers crossfade by state — exploration, mystery, puzzle, celebration, danger — over regional field recordings, all synthesized in-house." },
              ].map(({ icon: Icon, t, d }) => (
                <div key={t} className="rounded-2xl hairline p-5">
                  <Icon size={16} className="text-ember" />
                  <h4 className="mt-2 text-sm font-semibold text-mist">{t}</h4>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-mist/60">{d}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* ------------------------------ TECH ------------------------------ */}
          <Section
            id="tech"
            eyebrow="06 · TECHNOLOGY"
            title="Modular systems architecture"
            lede="Prototype: WebGL2 + Three.js (this build). Production: Godot 4 (Compatibility renderer for Android). Same module boundaries either way — every simulation is independently testable."
          >
            <div className="grid gap-3 md:grid-cols-2">
              {SYSTEMS.map((s) => (
                <div key={s.name} className="rounded-2xl hairline p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm font-semibold text-mist">{s.name}</p>
                    <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[9px] tracking-widest ${STATUS_STYLE[s.status]}`}>
                      {s.status}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-mist/60">{s.desc}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 grid gap-4 lg:grid-cols-2">
              <div className="overflow-hidden rounded-2xl hairline">
                <p className="border-b border-mist/10 bg-white/[0.03] px-5 py-3 font-mono text-[10px] tracking-[0.3em] text-moss/80">
                  REPOSITORY LAYOUT · PROTOTYPE
                </p>
                <pre className="wild-scroll max-h-96 overflow-auto p-5 font-mono text-[11px] leading-relaxed text-mist/75">{FOLDER_TREE}</pre>
              </div>
              <div className="space-y-4">
                <div className="rounded-2xl hairline p-5">
                  <p className="flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-moss/80">
                    <Cpu size={13} /> PERFORMANCE BUDGETS
                  </p>
                  <ul className="mt-3 space-y-2 text-[12px] leading-relaxed text-mist/65">
                    <li>· Low tier: 30fps — half-res particles, no DoF/transmission, 512 shadows, capped DPR.</li>
                    <li>· Mid tier: 60fps on modern phones — 1.6× DPR, 1024 shadows, DoF-lite.</li>
                    <li>· High tier: 60fps PC — 2× DPR, transmission dew, 2048 shadows, full post.</li>
                    <li>· Instancing for all vegetation; analytic terrain shared by art & logic; zero per-frame allocations in hot loops; object pools for particles.</li>
                    <li>· Production: region streaming, LOD chains, occlusion culling, ASTC texture compression, baked probe lighting.</li>
                  </ul>
                </div>
                <div className="rounded-2xl hairline p-5">
                  <p className="flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-moss/80">
                    <ShieldCheck size={13} /> AI-ASSISTED, HUMAN-GOVERNED
                  </p>
                  <ul className="mt-3 space-y-2 text-[12px] leading-relaxed text-mist/65">
                    {AI_NOTES.map((a) => (
                      <li key={a.area}>
                        <span className="text-ember/90">{a.area}:</span> {a.use}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </Section>

          {/* ------------------------------ ROADMAP ------------------------------ */}
          <Section id="roadmap" eyebrow="07 · DEVELOPMENT" title="Nine-phase roadmap" lede="Incrementally playable at every phase — the garden is never broken, only unfinished.">
            <div className="grid gap-3 md:grid-cols-3">
              {ROADMAP.map((p) => (
                <div
                  key={p.n}
                  className={`rounded-2xl p-5 ${p.live ? "glass-panel border-ember/40" : "hairline"}`}
                >
                  <p className="font-mono text-[10px] tracking-[0.3em] text-ember">
                    PHASE {p.n} {p.live && <span className="ml-2 rounded-full bg-ember px-2 py-0.5 text-[8px] font-bold text-[#241708]">LIVE</span>}
                  </p>
                  <h4 className="mt-1.5 font-display text-lg italic text-[#f2ead6]">{p.title}</h4>
                  <ul className="mt-2.5 space-y-1.5 text-[12px] leading-relaxed text-mist/65">
                    {p.items.map((it) => (
                      <li key={it} className="flex gap-2">
                        <Leaf size={10} className="mt-1 shrink-0 text-moss" /> {it}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </Section>

          {/* ------------------------------ PROTOTYPE ------------------------------ */}
          <Section
            id="prototype"
            eyebrow="08 · PHASE 1"
            title="What you're holding"
            lede="This web build is Phase 1 made playable: one region, one creature, one full puzzle loop, and the verbs every later phase builds upon."
          >
            <div className="grid gap-4 rounded-3xl glass-panel p-6 md:grid-cols-[3fr_2fr] md:p-8">
              <div>
                <h3 className="font-display text-2xl italic text-[#f2ead6]">The Fallen Garden — acceptance checklist</h3>
                <ul className="mt-4 grid gap-2 text-[13px] text-mist/75 md:grid-cols-2">
                  {[
                    "Walk, run, analog speed, slope-aware body",
                    "Cinematic camera: orbit, zoom, intro & bloom shots",
                    "Lume: leads, waits, points, celebrates, speaks in chirps",
                    "Interactables: proximity + E / tap with context verbs",
                    "Sunbeam puzzle: 3 shard-stones, fully visible logic",
                    "Bloom cinematic, area transformation, memory reward",
                    "4 collectible memories + creature journal + map",
                    "Idle-aware progressive hints (H)",
                    "Procedural adaptive score, SFX & creature voices",
                    "Touch joystick, drag-orbit, pinch zoom, tap interact",
                    "Quality presets, subtitles, reduced motion, volume",
                    "Persistent save: settings, memories, observations",
                    "Rootway travel: bloom the portal, ride the ring to Region 02",
                    "Hollow Root biome: sap rivers, glowcaps, rib-vault, skylight",
                    "Loamglider: vibration-sense creature that teaches the tune",
                    "Seed-Chord puzzle: echo four bells; Rootheart epilogue",
                  ].map((t) => (
                    <li key={t} className="flex gap-2.5">
                      <span className="mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-ember/20">
                        <span className="h-1.5 w-1.5 rounded-full bg-ember" />
                      </span>
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-col justify-between gap-4">
                <div className="rounded-2xl hairline p-5">
                  <Map size={16} className="text-lume" />
                  <p className="mt-2 text-[12px] leading-relaxed text-mist/65">
                    How to test: follow the moth, then get the beam from the brass arch to the
                    bud. Try walking through wet grass, calling the Lume (E), and standing still —
                    the hint lantern only lights if you truly stall.
                  </p>
                </div>
                <button
                  onClick={onPlay}
                  className="flex items-center justify-center gap-3 rounded-2xl bg-ember px-6 py-4 text-sm font-bold text-[#241708] transition hover:bg-ember-deep"
                >
                  <Play size={16} /> Enter the Fallen Garden
                </button>
              </div>
            </div>
            <p className="mt-8 text-center font-mono text-[10px] tracking-[0.3em] text-mist/30">
              WHISPERS OF THE WILDLAND © 2026 · AN ORIGINAL WORLD · DOCUMENT V0.9
            </p>
          </Section>
        </main>
      </div>
    </div>
  );
}
