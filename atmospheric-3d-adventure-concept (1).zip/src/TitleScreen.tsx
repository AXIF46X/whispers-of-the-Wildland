/**
 * TitleScreen.tsx — the game's front door. Original key art under a slow
 * Ken Burns drift, drifting spores, and a quiet menu. Audio unlocks on the
 * first interaction (browser policy), timed exactly with "Enter".
 */
import { useState } from "react";
import { Play, ScrollText, MousePointerClick, Move3d, Lightbulb } from "lucide-react";
import { audio } from "./game/audio";

export default function TitleScreen({
  onEnter,
  onDoc,
}: {
  onEnter: () => void;
  onDoc: () => void;
}) {
  const [leaving, setLeaving] = useState(false);
  const [artOk, setArtOk] = useState(true);

  const enter = () => {
    audio.init();
    audio.resume();
    setLeaving(true);
    window.setTimeout(onEnter, 650);
  };

  return (
    <div
      className={`absolute inset-0 overflow-hidden bg-[#0b140d] transition-opacity duration-700 ${
        leaving ? "opacity-0" : "opacity-100"
      }`}
    >
      <style>{`
        @keyframes wildKen { from { transform: scale(1.04) translateY(0); } to { transform: scale(1.16) translateY(-1.8%); } }
        @keyframes wildRise { from { opacity:0; transform: translateY(34px); filter: blur(8px);} to { opacity:1; transform:none; filter:none;} }
      `}</style>

      {/* key art */}
      <div className="absolute inset-0" style={{ animation: "wildKen 36s ease-in-out infinite alternate" }}>
        {artOk ? (
          <img
            src="/images/keyart.jpg"
            alt=""
            onError={() => setArtOk(false)}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full bg-[radial-gradient(120%_90%_at_30%_20%,#2c4a2e_0%,#14261a_55%,#0b140d_100%)]" />
        )}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#0b140d] via-[#0b140d66] to-[#0b140d22]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0b140dcc] via-transparent to-transparent" />
      <div className="noise-veil absolute inset-0" />

      {/* drifting spores */}
      {[...Array(9)].map((_, i) => (
        <div
          key={i}
          className="animate-spore absolute h-1 w-1 rounded-full bg-[#ffe9b0]"
          style={{
            left: `${8 + i * 10}%`,
            bottom: `${6 + (i % 4) * 7}%`,
            animationDelay: `${i * 1.7}s`,
            animationDuration: `${9 + (i % 5) * 2.4}s`,
            opacity: 0,
          }}
        />
      ))}

      {/* content */}
      <div className="relative z-10 flex h-full flex-col justify-between p-6 md:p-12">
        <header
          className="flex items-center justify-between"
          style={{ animation: "wildRise 1s 0.2s both" }}
        >
          <p className="font-mono text-[10px] tracking-[0.5em] text-moss/80">AN ORIGINAL MACRO-FANTASY</p>
          <div className="hidden items-center gap-5 font-mono text-[10px] tracking-[0.3em] text-mist/40 md:flex">
            <span>3D ATMOSPHERIC ADVENTURE</span>
            <span className="h-1 w-1 rounded-full bg-mist/30" />
            <span>ENVIRONMENTAL PUZZLES</span>
          </div>
        </header>

        <main className="max-w-3xl">
          <div style={{ animation: "wildRise 1.1s 0.5s both" }}>
            <p className="font-mono text-[11px] tracking-[0.6em] text-ember">WHISPERS</p>
            <h1 className="mt-2 font-display text-[17vw] font-light italic leading-[0.9] text-[#f6e8cf] text-glow-ember md:text-[7.5rem]">
              of the
              <span className="block not-italic font-normal tracking-tight">Wildland</span>
            </h1>
          </div>
          <p
            className="mt-6 max-w-xl text-sm leading-relaxed text-mist/75 md:text-base"
            style={{ animation: "wildRise 1.1s 0.8s both" }}
          >
            You are Milo — a fallen seed stitched together with fragments of an ancient
            machine. Shrink into a forest that breathes, drinks and dreams; guide its last
            sunbeam home, one garden at a time. The Heartlight is going out, and something
            small must carry it back.
          </p>

          <div
            className="mt-9 flex flex-wrap items-center gap-3"
            style={{ animation: "wildRise 1.1s 1.05s both" }}
          >
            <button
              onClick={enter}
              className="group flex items-center gap-3 rounded-full bg-ember px-7 py-3.5 text-sm font-bold text-[#241708] shadow-[0_10px_40px_rgba(242,177,94,0.35)] transition hover:bg-ember-deep hover:shadow-[0_10px_50px_rgba(242,177,94,0.5)]"
            >
              <Play size={16} className="transition group-hover:scale-125" />
              Enter the Wildland
              <span className="font-mono text-[9px] tracking-widest opacity-60">CH.0 PROTOTYPE</span>
            </button>
            <button
              onClick={onDoc}
              className="flex items-center gap-2.5 rounded-full glass-panel px-6 py-3.5 text-sm text-mist transition hover:border-ember/40 hover:text-ember"
            >
              <ScrollText size={16} />
              Design Document
            </button>
          </div>

          <div
            className="mt-8 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[10px] tracking-wider text-mist/45"
            style={{ animation: "wildRise 1.1s 1.25s both" }}
          >
            <span className="flex items-center gap-2">
              <MousePointerClick size={12} className="text-moss" /> TOUCH · STICK, HOP & TAP
            </span>
            <span className="flex items-center gap-2">
              <Move3d size={12} className="text-moss" /> WASD · SPACE HOP · DRAG ORBIT
            </span>
            <span className="flex items-center gap-2">
              <Lightbulb size={12} className="text-moss" /> CONTROLS NOTE ON ENTRY
            </span>
          </div>
        </main>

        <footer
          className="flex flex-wrap items-center justify-between gap-2 font-mono text-[9px] tracking-[0.25em] text-mist/30"
          style={{ animation: "wildRise 1.1s 1.4s both" }}
        >
          <span>BUILD 0.1 · PHASE 1 PROTOTYPE · WEB / ANDROID-TARGETED CONTROLS</span>
          <span>AN ORIGINAL WORLD — STORY, CREATURES AND ART CREATED FOR THIS GAME</span>
        </footer>
      </div>
    </div>
  );
}
