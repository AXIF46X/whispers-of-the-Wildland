/**
 * store.ts — discrete game state (zustand). Per-frame values live in
 * runtime.ts instead; this store only changes on *events*, so React
 * components re-render rarely and cheaply.
 *
 * Persisted slice: settings + journal (memories / creature observations).
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { RT } from "./runtime";
import { applyRegionSampler } from "./world/sampler";
import { SPAWNS } from "./layout";

export type Quality = "low" | "medium" | "high";
export type Phase = "intro" | "explore" | "solved" | "gather" | "epilogue";
export type Panel = "none" | "map" | "journal" | "settings" | "controls";
export type RegionId = "garden" | "root";

export interface Settings {
  quality: Quality;
  volume: number; // 0..1
  muted: boolean;
  subtitles: boolean;
  reducedMotion: boolean;
  textSize: 0 | 1 | 2;
  colorblindSub: boolean;
  /* ---- controls ---- */
  camSensitivity: number; // 0.5 .. 2
  invertY: boolean;
  leftHanded: boolean; // mirrors the touch layout
  runToggle: boolean; // touch: run button latches instead of push-to-run
  seenControls: boolean; // has the intro note been acknowledged
}

export interface MemoryEntry {
  id: string;
  title: string;
  text: string;
  at: number;
}

export interface Toast {
  id: number;
  title: string;
  text: string;
}

export interface Subtitle {
  who: string;
  text: string;
  key: number;
}

export interface Interactable {
  id: string;
  label: string;
  radius: number;
  enabled: boolean;
  getPos: () => { x: number; y: number; z: number };
  action: () => void;
}

interface GameState {
  runId: number;
  phase: Phase;
  objective: string;
  region: RegionId;
  unlocked: RegionId[];
  completed: string[];
  travelingTo: RegionId | null;
  prisms: number[]; // quarter-turn states 0..3
  beamReached: number; // how many prisms the beam currently traverses (0..3)
  bloomAt: number; // epoch ms of the bloom event (0 = not yet)
  vaultAt: number; // epoch ms of the Rootheart ignition (Hollow Root)
  lastProgress: number; // epoch ms — hint system watches this
  hintIndex: number;
  hintText: string | null;
  memories: MemoryEntry[];
  creatures: string[];
  toast: Toast | null;
  subtitle: Subtitle | null;
  panel: Panel;
  interactables: Record<string, Interactable>;
  interactTargetId: string | null;
  touchMode: boolean;
  settings: Settings;

  setPhase: (p: Phase) => void;
  setObjective: (o: string) => void;
  setPrism: (i: number, state: number) => void;
  setBeamReached: (n: number) => void;
  markProgress: () => void;
  triggerBloom: () => void;
  triggerVault: () => void;
  setRegion: (r: RegionId) => void;
  completeRegion: (id: string) => void;
  setTravelingTo: (r: RegionId | null) => void;
  advanceHint: (text: string | null) => void;
  say: (who: string, text: string) => void;
  pushToast: (title: string, text: string) => void;
  clearToast: () => void;
  addMemory: (m: Omit<MemoryEntry, "at">) => void;
  observeCreature: (name: string) => void;
  setPanel: (p: Panel) => void;
  registerInteractable: (i: Interactable) => void;
  unregisterInteractable: (id: string) => void;
  setInteractTarget: (id: string | null) => void;
  setTouchMode: (b: boolean) => void;
  updateSettings: (s: Partial<Settings>) => void;
  resetRun: () => void;
}

export const DEFAULT_SETTINGS: Settings = {
  quality: "high",
  volume: 0.8,
  muted: false,
  subtitles: true,
  reducedMotion: false,
  textSize: 1,
  colorblindSub: false,
  camSensitivity: 1,
  invertY: false,
  leftHanded: false,
  runToggle: false,
  seenControls: false,
};

export const useGame = create<GameState>()(
  persist(
    (set) => ({
      runId: 0,
      phase: "intro",
      objective: "",
      region: "garden" as RegionId,
      unlocked: ["garden"] as RegionId[],
      completed: [] as string[],
      travelingTo: null as RegionId | null,
      prisms: [0, 1, 0],
      beamReached: 0,
      bloomAt: 0,
      vaultAt: 0,
      lastProgress: Date.now(),
      hintIndex: 0,
      hintText: null,
      memories: [],
      creatures: [],
      toast: null,
      subtitle: null,
      panel: "none",
      interactables: {},
      interactTargetId: null,
      touchMode: false,
      settings: { ...DEFAULT_SETTINGS },
      // note: persisted saves are merged over the defaults, so settings
      // added in later builds always have a sane value.

      setPhase: (phase) => set({ phase }),
      setObjective: (objective) => set({ objective }),
      setPrism: (i, state) =>
        set((s) => {
          const prisms = s.prisms.slice();
          prisms[i] = state;
          return { prisms };
        }),
      setBeamReached: (beamReached) => set({ beamReached }),
      markProgress: () => set({ lastProgress: Date.now(), hintText: null }),
      triggerBloom: () =>
        set({ bloomAt: Date.now(), phase: "solved", lastProgress: Date.now(), hintText: null }),
      triggerVault: () =>
        set({ vaultAt: Date.now(), phase: "solved", lastProgress: Date.now(), hintText: null }),
      setRegion: (region) => {
        applyRegionSampler(region); // world façade swaps before the commit
        return set((s) => ({
          region,
          phase: "explore",
          objective:
            region === "root"
              ? "Listen to the Hollow"
              : s.unlocked.includes("root")
                ? "The garden breathes — the Rootway awaits"
                : "Follow the Lume",
          hintIndex: 0,
          hintText: null,
          subtitle: null,
          interactTargetId: null,
          panel: "none" as Panel,
          lastProgress: Date.now(),
        }));
      },
      completeRegion: (id) =>
        set((s) => ({
          completed: s.completed.includes(id) ? s.completed : [...s.completed, id],
          unlocked:
            id === "garden" && !s.unlocked.includes("root")
              ? ([...s.unlocked, "root"] as RegionId[])
              : s.unlocked,
        })),
      setTravelingTo: (travelingTo) => set({ travelingTo }),
      advanceHint: (hintText) =>
        set((s) => ({ hintText, hintIndex: s.hintIndex + 1, lastProgress: Date.now() })),
      say: (who, text) => set({ subtitle: { who, text, key: Date.now() } }),
      pushToast: (title, text) => set({ toast: { id: Date.now(), title, text } }),
      clearToast: () => set({ toast: null }),
      addMemory: (m) =>
        set((s) =>
          s.memories.some((e) => e.id === m.id)
            ? s
            : { memories: [...s.memories, { ...m, at: Date.now() }] }
        ),
      observeCreature: (name) =>
        set((s) =>
          s.creatures.includes(name) ? s : { creatures: [...s.creatures, name] }
        ),
      setPanel: (panel) => set({ panel }),
      registerInteractable: (i) =>
        set((s) => ({ interactables: { ...s.interactables, [i.id]: i } })),
      unregisterInteractable: (id) =>
        set((s) => {
          const next = { ...s.interactables };
          delete next[id];
          return { interactables: next };
        }),
      setInteractTarget: (interactTargetId) => set({ interactTargetId }),
      setTouchMode: (touchMode) => set({ touchMode }),
      updateSettings: (s) => set((st) => ({ settings: { ...st.settings, ...s } })),
      resetRun: () => {
        RT.cutscene = null;
        set((s) => {
          const spawn = SPAWNS[s.region] ?? SPAWNS.garden;
          RT.playerPos.set(spawn[0], 1.5, spawn[1]);
          return {
            runId: s.runId + 1,
            phase: s.region === "root" ? ("explore" as Phase) : ("intro" as Phase),
            objective: s.region === "root" ? "Listen to the Hollow" : "",
          prisms: [0, 1, 0],
          beamReached: 0,
          bloomAt: 0,
          vaultAt: 0,
          lastProgress: Date.now(),
          hintIndex: 0,
          hintText: null,
          toast: null,
            subtitle: null,
            panel: "none" as Panel,
            interactTargetId: null,
          };
        });
      },
    }),
    {
      name: "wildland-save-v1",
      partialize: (s) => ({
        settings: s.settings,
        memories: s.memories,
        creatures: s.creatures,
        region: s.region,
        unlocked: s.unlocked,
        completed: s.completed,
      }),
      /* saves written by earlier builds must still boot: merge the stored
         settings over the current defaults rather than replacing them. */
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<GameState>;
        return {
          ...current,
          ...p,
          settings: { ...DEFAULT_SETTINGS, ...(p.settings ?? {}) },
        };
      },
    }
  )
);
