/**
 * hints.ts — progressive hint content per region + the reveal helper used
 * by both the idle-time engine (Game.tsx) and the manual hint button (HUD).
 */
import { useGame, type RegionId } from "./store";

export const HINTS: Record<RegionId, string[]> = {
  garden: [
    "Follow the Lume — it flickers toward whatever matters next.",
    "The evening sunbeam must climb the shard-stones to reach the Bloomheart.",
    "Tap a shard-stone (or press E beside one) to turn it. Watch where the light falls.",
    "The beam turns in right angles only. Guide it east, then north, then west, then north — a staircase of light.",
  ],
  root: [
    "Something down here still knows the old tune. Watch the Loamglider work.",
    "Four root-bells, four tones. The Loamglider bumps them in the right order — echo what it plays.",
    "Ask the Loamglider (E) to sing the seed-chord again. The seed-dots above the Rootheart track your progress.",
    "The song climbs, dips, then answers warmly: second bell, fourth bell, first bell, third.",
  ],
};

export function showHint() {
  const s = useGame.getState();
  const list = HINTS[s.region];
  s.advanceHint(list[Math.min(s.hintIndex, list.length - 1)]);
}
