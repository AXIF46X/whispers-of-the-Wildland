/**
 * input.ts — unified input bus. Keyboard, the virtual joystick and the
 * touch action cluster all write into one mutable frame-state object that
 * the player controller and camera read each frame.
 *
 * Movement : WASD (keyboard) or joystick vector
 * Camera   : arrow keys / drag / pinch
 * Actions  : edge-triggered flags (jump, recenter) consumed by their owner
 */
import { useEffect } from "react";

export const input = {
  /** strafe: -1 left .. +1 right */
  x: 0,
  /** forward: -1 back .. +1 forward */
  y: 0,
  run: false,
  touchActive: false,
  anyKey: false,
  /** edge flag — consumed by Milo */
  jump: false,
  /** keyboard camera axes (-1..1) */
  camX: 0,
  camY: 0,
  /** keyboard zoom: -1 in, +1 out */
  zoom: 0,
  /** edge flag — consumed by the camera rig */
  recenter: false,
};

const held = new Set<string>();

const MOVE: Record<string, [number, number]> = {
  KeyW: [0, 1],
  KeyS: [0, -1],
  KeyA: [-1, 0],
  KeyD: [1, 0],
};

const CAM: Record<string, [number, number]> = {
  ArrowLeft: [-1, 0],
  ArrowRight: [1, 0],
  ArrowUp: [0, -1],
  ArrowDown: [0, 1],
};

const ZOOM: Record<string, number> = {
  Minus: 1,
  NumpadSubtract: 1,
  Equal: -1,
  NumpadAdd: -1,
};

const TRACKED = (code: string) =>
  code in MOVE || code in CAM || code in ZOOM || code.startsWith("Shift");

function recompute() {
  // camera axes are keyboard-only
  let cx = 0;
  let cy = 0;
  let z = 0;
  held.forEach((k) => {
    const c = CAM[k];
    if (c) {
      cx += c[0];
      cy += c[1];
    }
    if (ZOOM[k]) z += ZOOM[k];
  });
  input.camX = Math.max(-1, Math.min(1, cx));
  input.camY = Math.max(-1, Math.min(1, cy));
  input.zoom = Math.max(-1, Math.min(1, z));

  if (input.touchActive) return; // joystick owns the move vector while held

  let x = 0;
  let y = 0;
  held.forEach((k) => {
    const m = MOVE[k];
    if (m) {
      x += m[0];
      y += m[1];
    }
  });
  const len = Math.hypot(x, y);
  input.x = len > 0 ? x / len : 0;
  input.y = len > 0 ? y / len : 0;
  input.run = held.has("ShiftLeft") || held.has("ShiftRight");
}

/** called by the touch joystick */
export function setTouchVector(nx: number, ny: number, active: boolean, run: boolean) {
  input.touchActive = active;
  input.x = nx;
  input.y = ny;
  input.run = run;
  if (active) input.anyKey = true;
}

export function queueJump() {
  input.jump = true;
  input.anyKey = true;
}

export function queueRecenter() {
  input.recenter = true;
}

export function useKeyboardInput(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const down = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space" && !e.repeat) {
        queueJump();
        e.preventDefault();
        return;
      }
      if (e.code === "KeyF" && !e.repeat) {
        queueRecenter();
        return;
      }
      if (TRACKED(e.code)) {
        held.add(e.code);
        input.anyKey = true;
        recompute();
        if (MOVE[e.code] || CAM[e.code]) e.preventDefault();
      }
    };
    const up = (e: KeyboardEvent) => {
      if (held.delete(e.code)) recompute();
    };
    const clear = () => {
      held.clear();
      recompute();
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
      clear();
    };
  }, [active]);
}
