/**
 * runtime.ts — mutable, non-reactive channel between the game loop and UI.
 * React state is reserved for discrete game events; per-frame values live
 * here to avoid re-rendering the tree 60 times a second.
 */
import * as THREE from "three";

export interface Cutscene {
  focus: THREE.Vector3;
  camOffset: THREE.Vector3;
  t: number;
  dur: number;
  onDone?: () => void;
}

export const RT = {
  /** world position of Milo (feet on terrain) */
  playerPos: new THREE.Vector3(0, 0, 14),
  playerMoving: false,
  playerSpeed: 0,
  /** Milo's facing (radians) — used by the camera recenter */
  playerYaw: Math.PI,
  /** true while Milo is off the ground (hop) */
  playerAirborne: false,
  /** 0..1 global wind gust envelope, driven by the audio engine's gust scheduler */
  wind: 0.6,
  /** active camera cutscene (bloom moment); null = player-controlled */
  cutscene: null as Cutscene | null,
  /** set by the camera drag handler so tap-to-interact can ignore drags */
  wasDrag: false,
  /** quality-derived knobs, set once from the settings store */
  quality: { transmission: true, shadows: true, grass: 1400, fireflyLight: true },
};
