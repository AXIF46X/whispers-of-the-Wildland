/**
 * sampler.ts — region façade for the height field. World actors (player,
 * camera, portals) query through this mutable slot, so the same controller
 * code runs identically in any region. Region environments install their
 * own sampler on mount.
 */
import { terrainHeight, terrainSlope } from "../terrain";
import { ROOT_CEILING, rootHeight, rootSlope } from "../regions/root/rootTerrain";

export interface SlopeOut {
  fx: number;
  fz: number;
}

export interface WorldSampler {
  height: (x: number, z: number) => number;
  slope: (x: number, z: number, out: SlopeOut) => void;
  /** ceiling clamp for enclosed regions (null = open sky) */
  ceiling: number | null;
  /** gameplay radius for this region */
  bounds: number;
}

export const sampler: WorldSampler = {
  height: terrainHeight,
  slope: terrainSlope,
  ceiling: null,
  bounds: 19.5,
};

export const sampleHeight = (x: number, z: number) => sampler.height(x, z);
export const sampleSlope = (x: number, z: number, out: SlopeOut) => sampler.slope(x, z, out);

/**
 * Installs a region's height field into the world façade. Called from
 * store.setRegion synchronously (before React commits the new region), so
 * every consumer — portals, collectibles, player, camera — always samples
 * the active region, never a stale frame.
 */
export function applyRegionSampler(region: "garden" | "root") {
  if (region === "root") {
    sampler.height = rootHeight;
    sampler.slope = rootSlope;
    sampler.ceiling = ROOT_CEILING;
    sampler.bounds = 11.6;
  } else {
    sampler.height = terrainHeight;
    sampler.slope = terrainSlope;
    sampler.ceiling = null;
    sampler.bounds = 19.5;
  }
}
