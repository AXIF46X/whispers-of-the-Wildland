/**
 * Environment.tsx — "The Fallen Garden", prototype region 01.
 *
 * A macro-scale forest floor: giant grass (instanced, GPU wind + player
 * push-through), clover canopies, mushrooms, dew lenses, moss, falling
 * leaves, fireflies, spores, fake volumetric shafts — and the sleeping
 * Bloomheart, which wakes when the Heartlight beam reaches it.
 *
 * Performance notes: heavy use of instancing, analytic terrain sampling,
 * zero per-frame allocations outside particle updates, quality-tiered
 * particle counts / transmission / shadow resolution.
 */
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { terrainHeight } from "../terrain";
import { FLOWER, PRISMS, SOURCE, WORLD } from "../layout";
import { RT } from "../runtime";
import { useGame } from "../store";
import {
  makeBarkTexture,
  makeGlowTexture,
  makeGroundTexture,
  makeLeafTexture,
  makeShaftTexture,
} from "./textures";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

/** deterministic rng so the garden is the same on every visit */
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const BEAM_SEGMENTS: [number, number, number, number][] = [
  [SOURCE.pos[0], SOURCE.pos[1], PRISMS[0].pos[0], PRISMS[0].pos[1]],
  [PRISMS[0].pos[0], PRISMS[0].pos[1], PRISMS[1].pos[0], PRISMS[1].pos[1]],
  [PRISMS[1].pos[0], PRISMS[1].pos[1], PRISMS[2].pos[0], PRISMS[2].pos[1]],
  [PRISMS[2].pos[0], PRISMS[2].pos[1], FLOWER.pos[0], FLOWER.pos[1]],
];

function distToSeg(x: number, z: number, s: [number, number, number, number]) {
  const [ax, az, bx, bz] = s;
  const dx = bx - ax;
  const dz = bz - az;
  const l2 = dx * dx + dz * dz;
  let t = ((x - ax) * dx + (z - az) * dz) / (l2 || 1);
  t = Math.max(0, Math.min(1, t));
  const px = ax + t * dx;
  const pz = az + t * dz;
  return Math.hypot(x - px, z - pz);
}

function clearOfBeam(x: number, z: number, pad: number) {
  return BEAM_SEGMENTS.every((s) => distToSeg(x, z, s) > pad);
}

/* shared uniforms for the grass shader (mutated per-frame) */
const grassUniforms = {
  uTime: { value: 0 },
  uWind: { value: 0.6 },
  uPlayer: { value: new THREE.Vector3(999, 0, 999) },
};

const glowTex = { current: null as THREE.Texture | null };
function useGlow() {
  return useMemo(() => {
    if (!glowTex.current) glowTex.current = makeGlowTexture();
    return glowTex.current;
  }, []);
}

/* ------------------------------------------------------------------ */
/* lights                                                              */
/* ------------------------------------------------------------------ */

function Lights() {
  const quality = useGame((s) => s.settings.quality);
  const shadowSize = quality === "high" ? 2048 : quality === "medium" ? 1024 : 512;
  return (
    <>
      <hemisphereLight args={["#d8ecd6", "#2a2018", 0.55]} />
      <directionalLight
        position={[14, 22, 9]}
        intensity={2.4}
        color="#ffdfae"
        castShadow={quality !== "low"}
        shadow-mapSize-width={shadowSize}
        shadow-mapSize-height={shadowSize}
        shadow-camera-left={-24}
        shadow-camera-right={24}
        shadow-camera-top={24}
        shadow-camera-bottom={-24}
        shadow-camera-near={2}
        shadow-camera-far={70}
        shadow-bias={-0.0004}
        shadow-normalBias={0.03}
      />
      <directionalLight position={[-12, 8, -14]} intensity={0.35} color="#7fa8c8" />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* terrain                                                             */
/* ------------------------------------------------------------------ */

function Ground() {
  const detail = useMemo(() => makeGroundTexture(), []);
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(WORLD.groundRadius * 2.4, WORLD.groundRadius * 2.4, 110, 110);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const cMoss = new THREE.Color("#44603a");
    const cFern = new THREE.Color("#6d9150");
    const cSoil = new THREE.Color("#6b5b40");
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = terrainHeight(x, z);
      pos.setY(i, h);
      const n =
        0.5 +
        0.5 * Math.sin(x * 0.9 + z * 1.3) * Math.sin(x * 0.23 - z * 0.5 + 2.1) +
        0.25 * Math.sin(x * 2.6 + z * 2.0);
      c.lerpColors(cMoss, cFern, THREE.MathUtils.clamp(n * 0.6 + h * 0.25, 0, 1));
      if (Math.sin(x * 0.5 + 4) * Math.sin(z * 0.4 - 1) > 0.55) c.lerp(cSoil, 0.35);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    g.computeVertexNormals();
    return g;
  }, []);
  return (
    <mesh geometry={geo} receiveShadow>
      <meshStandardMaterial map={detail} vertexColors roughness={0.95} metalness={0} />
    </mesh>
  );
}

/* ------------------------------------------------------------------ */
/* grass — instanced blades with wind + player push in the vertex shader */
/* ------------------------------------------------------------------ */

function buildBladeGeometry() {
  const g = new THREE.PlaneGeometry(0.085, 1, 1, 5);
  g.translate(0, 0.5, 0);
  const pos = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i); // 0..1
    pos.setX(i, pos.getX(i) * (1 - y * 0.9)); // taper
    pos.setZ(i, y * y * 0.38); // natural bow
  }
  g.computeVertexNormals();
  return g;
}

function GrassField() {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = RT.quality.grass;
  const geo = useMemo(buildBladeGeometry, []);
  const mat = useMemo(() => {
    const m = new THREE.MeshStandardMaterial({
      color: "#ffffff",
      roughness: 0.9,
      side: THREE.DoubleSide,
    });
    m.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = grassUniforms.uTime;
      shader.uniforms.uWind = grassUniforms.uWind;
      shader.uniforms.uPlayer = grassUniforms.uPlayer;
      shader.vertexShader =
        "uniform float uTime;\nuniform float uWind;\nuniform vec3 uPlayer;\n" +
        shader.vertexShader.replace(
          "#include <project_vertex>",
          `vec4 mvPosition = vec4( transformed, 1.0 );
          #ifdef USE_INSTANCING
            mvPosition = instanceMatrix * mvPosition;
          #endif
          {
            vec4 wp = modelMatrix * mvPosition;
            float bh = clamp( position.y, 0.0, 1.0 );
            bh *= bh;
            float sway = sin( uTime * 1.6 + wp.x * 0.55 + wp.z * 0.42 )
                       + 0.55 * sin( uTime * 3.1 + wp.z * 0.85 - wp.x * 0.3 );
            vec2 off = vec2(0.62, 0.38) * sway * 0.05 * uWind * bh;
            vec2 dp = wp.xz - uPlayer.xz;
            float dl = max( length(dp), 0.0001 );
            float push = 1.0 - smoothstep( 0.1, 1.0, dl );
            off += ( dp / dl ) * push * 0.4 * bh;
            mvPosition.xz += off;
            mvPosition.y -= push * 0.12 * bh;
          }
          mvPosition = modelViewMatrix * mvPosition;
          gl_Position = projectionMatrix * mvPosition;`
        );
    };
    return m;
  }, []);

  useLayoutEffect(() => {
    const rand = mulberry32(1337);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const base = new THREE.Color("#55803f");
    const tip = new THREE.Color("#87a85a");
    let placed = 0;
    let guard = 0;
    while (placed < count && guard < count * 30) {
      guard++;
      const r = Math.sqrt(rand()) * 26;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (r < 24 && !clearOfBeam(x, z, 0.8) && rand() < 0.7) continue;
      dummy.position.set(x, terrainHeight(x, z) - 0.02, z);
      dummy.rotation.set((rand() - 0.5) * 0.35, rand() * Math.PI * 2, (rand() - 0.5) * 0.35);
      const s = 0.65 + rand() * 1.05;
      const h = 0.55 + rand() * 1.25;
      dummy.scale.set(s, h, s);
      dummy.updateMatrix();
      ref.current.setMatrixAt(placed, dummy.matrix);
      color.lerpColors(base, tip, rand()).multiplyScalar(0.8 + rand() * 0.4);
      ref.current.setColorAt(placed, color);
      placed++;
    }
    ref.current.count = placed;
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  }, [count]);

  useFrame((state, dt) => {
    grassUniforms.uTime.value += dt * (RT.cutscene ? 0.4 : 1);
    grassUniforms.uWind.value = THREE.MathUtils.lerp(grassUniforms.uWind.value, RT.wind, 0.04);
    grassUniforms.uPlayer.value.copy(RT.playerPos);
    void state;
  });

  return (
    <instancedMesh
      ref={ref}
      args={[geo, mat, count]}
      receiveShadow
      frustumCulled={false}
    />
  );
}

/* moss tufts — small darker sprigs */
function MossTufts() {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = 320;
  const geo = useMemo(() => new THREE.ConeGeometry(0.045, 0.22, 5), []);
  useLayoutEffect(() => {
    const rand = mulberry32(777);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const r = Math.sqrt(rand()) * 24;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      dummy.position.set(x, terrainHeight(x, z) + 0.08, z);
      dummy.rotation.set((rand() - 0.5) * 0.9, rand() * Math.PI * 2, (rand() - 0.5) * 0.9);
      const s = 0.6 + rand() * 1.4;
      dummy.scale.set(s, 0.7 + rand(), s);
      dummy.updateMatrix();
      ref.current.setMatrixAt(i, dummy.matrix);
    }
    ref.current.instanceMatrix.needsUpdate = true;
  }, []);
  return (
    <instancedMesh ref={ref} args={[geo, undefined, count]}>
      <meshStandardMaterial color="#5e8a49" roughness={1} />
    </instancedMesh>
  );
}

/* ------------------------------------------------------------------ */
/* flora set-dressing                                                  */
/* ------------------------------------------------------------------ */

function Clover() {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = 34;
  const geo = useMemo(() => {
    const g = new THREE.SphereGeometry(1, 16, 10, 0, Math.PI * 2, 0, 1.5);
    g.scale(1, 0.22, 1);
    return g;
  }, []);
  useLayoutEffect(() => {
    const rand = mulberry32(4242);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    let placed = 0;
    let guard = 0;
    // two authored "canopy" clovers near memory motes
    const authored: [number, number, number][] = [
      [6.6, 10.4, 2.9],
      [12.2, -6.6, 2.3],
    ];
    for (const [x, z, s] of authored) {
      dummy.position.set(x, terrainHeight(x, z) + s * 0.32, z);
      dummy.rotation.set((rand() - 0.5) * 0.25, rand() * Math.PI * 2, (rand() - 0.5) * 0.25);
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      ref.current.setMatrixAt(placed, dummy.matrix);
      color.set("#4c7f45").offsetHSL(0, 0, (rand() - 0.5) * 0.08);
      ref.current.setColorAt(placed, color);
      placed++;
    }
    while (placed < count && guard < 4000) {
      guard++;
      const r = Math.sqrt(rand()) * 22;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (!clearOfBeam(x, z, 1.5)) continue;
      dummy.position.set(x, terrainHeight(x, z) + 0.3 + rand() * 0.35, z);
      dummy.rotation.set((rand() - 0.5) * 0.5, rand() * Math.PI * 2, (rand() - 0.5) * 0.5);
      dummy.scale.setScalar(0.45 + rand() * 1.5);
      dummy.updateMatrix();
      ref.current.setMatrixAt(placed, dummy.matrix);
      color.set("#4c7f45").offsetHSL(0, 0, (rand() - 0.5) * 0.12);
      ref.current.setColorAt(placed, color);
      placed++;
    }
    ref.current.count = placed;
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  }, [count]);
  return (
    <instancedMesh ref={ref} args={[geo, undefined, count]} castShadow receiveShadow>
      <meshStandardMaterial color="#ffffff" roughness={0.75} />
    </instancedMesh>
  );
}

function Mushroom({
  x,
  z,
  h,
  capR,
  lean = 0,
  tint = "#c9a27d",
}: {
  x: number;
  z: number;
  h: number;
  capR: number;
  lean?: number;
  tint?: string;
}) {
  const y = terrainHeight(x, z);
  return (
    <group position={[x, y, z]} rotation={[0, 0, lean]}>
      <mesh position={[0, h / 2, 0]} castShadow>
        <cylinderGeometry args={[capR * 0.28, capR * 0.42, h, 10]} />
        <meshStandardMaterial color="#e8ddc8" roughness={0.85} />
      </mesh>
      <mesh position={[0, h, 0]} scale={[1, 0.52, 1]} castShadow>
        <sphereGeometry args={[capR, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.52]} />
        <meshStandardMaterial color={tint} roughness={0.6} />
      </mesh>
      <mesh position={[0, h - 0.02, 0]} scale={[0.94, 0.5, 0.94]}>
        <sphereGeometry args={[capR, 16, 10, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.2]} />
        <meshStandardMaterial color="#f3e4cf" roughness={0.9} />
      </mesh>
    </group>
  );
}

function MushroomSet() {
  return (
    <group>
      <Mushroom x={0.5} z={5.8} h={5.2} capR={3.6} lean={0.06} tint="#b98d6b" />
      <Mushroom x={3.2} z={7.2} h={1.8} capR={1.1} tint="#c79368" />
      <Mushroom x={-1.6} z={7.6} h={1.3} capR={0.85} lean={-0.1} tint="#d4b083" />
      <Mushroom x={-2.6} z={-7.4} h={1.1} capR={0.7} tint="#c79368" />
      <Mushroom x={-1.4} z={-8.2} h={0.7} capR={0.45} lean={0.14} tint="#d4b083" />
      <Mushroom x={9.5} z={1.5} h={1.5} capR={0.95} tint="#c79368" />
      <Mushroom x={-14.5} z={8} h={2.4} capR={1.5} lean={-0.08} tint="#b98d6b" />
    </group>
  );
}

function GiantTrunkAndRoots() {
  const bark = useMemo(() => makeBarkTexture(), []);
  return (
    <group>
      <mesh position={[-30, 20, 34]} rotation={[0.1, 0, 0.16]}>
        <cylinderGeometry args={[7.5, 10, 90, 24]} />
        <meshStandardMaterial map={bark} color="#8a715a" roughness={1} />
      </mesh>
      {/* root arches diving into the earth at the rim */}
      <mesh position={[-20, 1.5, 20]} rotation={[0, -0.7, 0]}>
        <torusGeometry args={[16, 1.7, 10, 24, Math.PI * 0.52]} />
        <meshStandardMaterial map={bark} color="#7d654e" roughness={1} />
      </mesh>
      <mesh position={[16, 0.5, -22]} rotation={[0, 2.4, 0]}>
        <torusGeometry args={[13, 1.4, 10, 24, Math.PI * 0.48]} />
        <meshStandardMaterial map={bark} color="#75604a" roughness={1} />
      </mesh>
    </group>
  );
}

function PebblesAndTwigs({ glow }: { glow: THREE.Texture }) {
  const peb = useRef<THREE.InstancedMesh>(null!);
  const count = 26;
  useLayoutEffect(() => {
    const rand = mulberry32(99);
    const dummy = new THREE.Object3D();
    let placed = 0;
    let guard = 0;
    while (placed < count && guard < 2000) {
      guard++;
      const r = 2 + Math.sqrt(rand()) * 20;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (!clearOfBeam(x, z, 1.2)) continue;
      const s = 0.16 + rand() * 0.5;
      dummy.position.set(x, terrainHeight(x, z) + s * 0.25, z);
      dummy.rotation.set(rand() * 3, rand() * 3, rand() * 3);
      dummy.scale.set(s, s * (0.6 + rand() * 0.5), s);
      dummy.updateMatrix();
      peb.current.setMatrixAt(placed, dummy.matrix);
      placed++;
    }
    peb.current.count = placed;
    peb.current.instanceMatrix.needsUpdate = true;
  }, []);
  void glow;
  return (
    <group>
      <instancedMesh ref={peb} args={[undefined, undefined, count]} castShadow receiveShadow>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#8d8577" roughness={0.9} />
      </instancedMesh>
      {[
        [4, -3.5, 0.6],
        [-6, 8, -0.4],
        [10.5, 6.5, 1.2],
        [-13, -1, 0.2],
      ].map(([x, z, ry], i) => (
        <mesh
          key={i}
          position={[x, terrainHeight(x, z) + 0.06, z]}
          rotation={[0, ry, Math.PI / 2 - 0.05]}
          castShadow
        >
          <capsuleGeometry args={[0.05, 1.6 + i * 0.3, 4, 8]} />
          <meshStandardMaterial color="#5c4632" roughness={1} />
        </mesh>
      ))}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* dew + puddle                                                        */
/* ------------------------------------------------------------------ */

function DewDrops() {
  const quality = useGame((s) => s.settings.quality);
  const drops: [number, number, number][] = useMemo(
    () => [
      [6.1, 10.9, 0.22],
      [2.3, 7.1, 0.16],
      [4.2, -3.6, 0.3],
      [-3.2, -8.4, 0.18],
      [9.2, 3.2, 0.24],
      [12.9, -5.9, 0.15],
      [-7.9, 6.9, 0.2],
    ],
    []
  );
  return (
    <group>
      {drops.map(([x, z, r], i) => (
        <mesh key={i} position={[x, terrainHeight(x, z) + r * 0.85, z]} scale={[1, 0.92, 1]}>
          <sphereGeometry args={[r, 24, 18]} />
          {quality === "high" && RT.quality.transmission ? (
            <meshPhysicalMaterial
              transmission={1}
              thickness={0.5}
              roughness={0.04}
              ior={1.33}
              color="#eaf6ff"
              envMapIntensity={1.5}
              clearcoat={1}
            />
          ) : (
            <meshPhongMaterial color="#cfe8ef" transparent opacity={0.6} shininess={140} specular="#ffffff" />
          )}
        </mesh>
      ))}
    </group>
  );
}

function Puddle({ glow }: { glow: THREE.Texture }) {
  const ring1 = useRef<THREE.Mesh>(null!);
  const ring2 = useRef<THREE.Mesh>(null!);
  const [x, z] = [-1.2, -10.2];
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const s1 = 0.5 + ((t * 0.35) % 1);
    const s2 = 0.5 + ((t * 0.35 + 0.5) % 1);
    ring1.current.scale.setScalar(s1);
    ring2.current.scale.setScalar(s2);
    (ring1.current.material as THREE.MeshBasicMaterial).opacity = 0.28 * (1.5 - s1);
    (ring2.current.material as THREE.MeshBasicMaterial).opacity = 0.28 * (1.5 - s2);
  });
  return (
    <group position={[x, terrainHeight(x, z) + 0.035, z]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.6, 40]} />
        <meshPhysicalMaterial
          color="#23382c"
          roughness={0.05}
          metalness={0.1}
          transparent
          opacity={0.94}
          envMapIntensity={1.7}
          clearcoat={1}
        />
      </mesh>
      {[ring1, ring2].map((r, i) => (
        <mesh key={i} ref={r} rotation={[-Math.PI / 2, 0, 0]} position={[0.2, 0.004 + i * 0.002, -0.1]}>
          <ringGeometry args={[0.95, 1, 32]} />
          <meshBasicMaterial color="#cfe8d8" transparent opacity={0.2} depthWrite={false} />
        </mesh>
      ))}
      <sprite position={[0.3, 0.06, -0.2]} scale={[0.7, 0.7, 1]}>
        <spriteMaterial map={glow} color="#fff7dd" transparent opacity={0.25} depthWrite={false} />
      </sprite>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* the Bloomheart                                                      */
/* ------------------------------------------------------------------ */

function Bloomheart({ glow }: { glow: THREE.Texture }) {
  const bloomAt = useGame((s) => s.bloomAt);
  const quality = useGame((s) => s.settings.quality);
  const [fx, fz] = FLOWER.pos;
  const fy = terrainHeight(fx, fz);
  const petals = useRef<THREE.Group[]>([]);
  const core = useRef<THREE.Mesh>(null!);
  const halo = useRef<THREE.Sprite>(null!);
  const light = useRef<THREE.PointLight>(null!);
  const stem = useRef<THREE.Group>(null!);
  const progress = useRef(0);

  const petalGeo = useMemo(() => {
    const g = new THREE.SphereGeometry(0.62, 14, 12);
    g.scale(0.52, 1.05, 0.16);
    g.translate(0, 0.5, 0);
    return g;
  }, []);

  const stemCurve = useMemo(
    () =>
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0.35, 1.1, 0.12),
        new THREE.Vector3(-0.18, 2.1, 0.02),
        new THREE.Vector3(0, FLOWER.budHeight, 0),
      ]),
    []
  );

  useFrame((state, dt) => {
    const target = bloomAt > 0 ? Math.min(1, (Date.now() - bloomAt) / 2800) : 0;
    progress.current = THREE.MathUtils.damp(progress.current, target, 3, dt);
    // ease with a soft overshoot
    const p = progress.current;
    const e = 1 + 2.2 * Math.pow(p - 1, 3) + 2.2 * 1 * Math.pow(p - 1, 2) * 0 + Math.pow(p - 1, 2) * 1.2 * (p - 1);
    const open = THREE.MathUtils.lerp(-0.2, 1.28, THREE.MathUtils.clamp(p < 1 ? 1 - Math.pow(1 - p, 3) : 1, 0, 1));
    void e;
    const t = state.clock.elapsedTime;
    petals.current.forEach((g, i) => {
      if (!g) return;
      const sway = Math.sin(t * 1.4 + i) * 0.03 * (1 - p * 0.5);
      g.rotation.set(open + sway, (i / 7) * Math.PI * 2, 0, "YXZ");
    });
    const em = p * 3.4 + 0.15 + Math.sin(t * 2.2) * 0.08;
    (core.current.material as THREE.MeshStandardMaterial).emissiveIntensity = em;
    halo.current.material.opacity = 0.18 + p * 0.55 + Math.sin(t * 2.2) * 0.05;
    halo.current.scale.setScalar(1.6 + p * 3.2);
    if (light.current) light.current.intensity = p * 16;
    stem.current.rotation.z = Math.sin(t * 0.8) * 0.02 * RT.wind;
    stem.current.rotation.x = Math.cos(t * 0.63) * 0.015 * RT.wind;
    void dt;
  });

  return (
    <group position={[fx, fy, fz]}>
      <group ref={stem}>
        <mesh castShadow>
          <tubeGeometry args={[stemCurve, 20, 0.13, 8, false]} />
          <meshStandardMaterial color="#4e7a45" roughness={0.8} />
        </mesh>
        {/* sepals */}
        {[0, 1, 2, 3, 4].map((i) => (
          <mesh
            key={i}
            position={[0, FLOWER.budHeight - 0.05, 0]}
            rotation={[0.8, (i / 5) * Math.PI * 2, 0, "YXZ"]}
          >
            <coneGeometry args={[0.1, 0.5, 6]} />
            <meshStandardMaterial color="#43693c" roughness={0.9} />
          </mesh>
        ))}
        {/* petals */}
        <group position={[0, FLOWER.budHeight, 0]}>
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <group
              key={i}
              ref={(el) => {
                if (el) petals.current[i] = el;
              }}
              rotation={[-0.2, (i / 7) * Math.PI * 2, 0, "YXZ"]}
            >
              <mesh geometry={petalGeo} castShadow>
                <meshStandardMaterial
                  color={i % 2 ? "#e8879b" : "#f0a4ae"}
                  roughness={0.55}
                  emissive="#ff9d7a"
                  emissiveIntensity={0.06}
                />
              </mesh>
            </group>
          ))}
          {/* glowing heart */}
          <mesh ref={core} position={[0, 0.28, 0]}>
            <sphereGeometry args={[0.3, 20, 16]} />
            <meshStandardMaterial color="#ffd9a0" emissive="#ffb45e" emissiveIntensity={0.2} roughness={0.4} />
          </mesh>
          <sprite ref={halo} position={[0, 0.4, 0]} scale={[1.6, 1.6, 1]}>
            <spriteMaterial map={glow} color="#ffcf8a" transparent opacity={0.2} depthWrite={false} />
          </sprite>
          {quality !== "low" && (
            <pointLight ref={light} position={[0, 0.6, 0]} color="#ffb45e" intensity={0} distance={11} decay={2} />
          )}
        </group>
      </group>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* particles                                                           */
/* ------------------------------------------------------------------ */

function Fireflies({ glow }: { glow: THREE.Texture }) {
  const quality = useGame((s) => s.settings.quality);
  const count = quality === "low" ? 22 : 44;
  const ref = useRef<THREE.Points>(null!);
  const lightRef = useRef<THREE.PointLight>(null!);
  const data = useMemo(() => {
    const rand = mulberry32(31);
    return Array.from({ length: count }, () => ({
      bx: (rand() - 0.5) * 36,
      bz: (rand() - 0.5) * 36,
      by: 1 + rand() * 2.6,
      sp: 0.4 + rand() * 0.8,
      ph: rand() * Math.PI * 2,
      orb: 1.4 + rand() * 2,
    }));
  }, [count]);
  const positions = useMemo(() => new Float32Array(count * 3), [count]);
  const [fx, fz] = FLOWER.pos;

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const bloomAt = useGame.getState().bloomAt;
    const bloomPull = bloomAt > 0 ? Math.min(1, (Date.now() - bloomAt) / 5000) : 0;
    for (let i = 0; i < count; i++) {
      const d = data[i];
      // half the swarm drifts toward the woken Bloomheart
      const tx = i % 2 === 0 ? fx + Math.cos(d.ph) * (1.5 + d.orb) : d.bx;
      const tz = i % 2 === 0 ? fz + Math.sin(d.ph) * (1.5 + d.orb) : d.bz;
      const ty = i % 2 === 0 ? 3.4 + d.orb * 0.6 : d.by;
      const bx = THREE.MathUtils.lerp(d.bx, tx, bloomPull);
      const bz = THREE.MathUtils.lerp(d.bz, tz, bloomPull);
      const by = THREE.MathUtils.lerp(d.by, ty, bloomPull);
      positions[i * 3] = bx + Math.sin(t * d.sp + d.ph) * 0.9;
      positions[i * 3 + 1] = by + Math.sin(t * d.sp * 0.7 + d.ph * 2) * 0.5;
      positions[i * 3 + 2] = bz + Math.cos(t * d.sp * 0.9 + d.ph) * 0.9;
    }
    const attr = ref.current.geometry.attributes.position as THREE.BufferAttribute;
    attr.needsUpdate = true;
    const mat = ref.current.material as THREE.PointsMaterial;
    mat.opacity = 0.75 + Math.sin(t * 5) * 0.2;
    if (lightRef.current) {
      lightRef.current.position.set(positions[0], positions[1], positions[2]);
      lightRef.current.intensity = 0.9 + Math.sin(t * 5) * 0.5 + bloomPull * 2;
    }
  });

  return (
    <group>
      <points ref={ref} frustumCulled={false}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        </bufferGeometry>
        <pointsMaterial
          size={0.3}
          map={glow}
          transparent
          opacity={0.9}
          color="#ffd27a"
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          sizeAttenuation
        />
      </points>
      {quality === "high" && <pointLight ref={lightRef} color="#ffce7a" distance={5} decay={2} />}
    </group>
  );
}

function Spores({ glow }: { glow: THREE.Texture }) {
  const count = 130;
  const ref = useRef<THREE.Points>(null!);
  const positions = useMemo(() => {
    const rand = mulberry32(7);
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = Math.sqrt(rand()) * 22;
      const a = rand() * Math.PI * 2;
      arr[i * 3] = Math.cos(a) * r;
      arr[i * 3 + 1] = 0.3 + rand() * 7;
      arr[i * 3 + 2] = Math.sin(a) * r;
    }
    return arr;
  }, []);
  useFrame((state, dt) => {
    ref.current.rotation.y += dt * 0.01;
    ref.current.position.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.3;
  });
  return (
    <points ref={ref} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.09}
        map={glow}
        transparent
        opacity={0.3}
        color="#eef3da"
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}

function FallingLeaves() {
  const tex = useMemo(() => makeLeafTexture(), []);
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = 12;
  const leaves = useMemo(() => {
    const rand = mulberry32(55);
    return Array.from({ length: count }, () => ({
      x: (rand() - 0.5) * 34,
      z: (rand() - 0.5) * 34,
      y: 6 + rand() * 6,
      vy: 0.25 + rand() * 0.3,
      ph: rand() * Math.PI * 2,
      spin: (rand() - 0.5) * 1.4,
      s: 0.28 + rand() * 0.3,
    }));
  }, []);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    leaves.forEach((l, i) => {
      l.y -= l.vy * dt * (0.8 + RT.wind * 0.4);
      l.x += Math.sin(t * 1.2 + l.ph) * dt * (0.5 + RT.wind * 0.8);
      l.z += Math.cos(t * 0.9 + l.ph) * dt * 0.3;
      const ground = terrainHeight(l.x, l.z) + 0.05;
      if (l.y < ground) {
        l.y = 7 + Math.random() * 6;
        l.x = (Math.random() - 0.5) * 34;
        l.z = (Math.random() - 0.5) * 34;
      }
      dummy.position.set(l.x, l.y, l.z);
      dummy.rotation.set(t * l.spin + l.ph, l.ph, Math.sin(t + l.ph) * 0.6);
      dummy.scale.setScalar(l.s);
      dummy.updateMatrix();
      ref.current.setMatrixAt(i, dummy.matrix);
    });
    ref.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]} frustumCulled={false}>
      <planeGeometry args={[1, 1]} />
      <meshStandardMaterial map={tex} transparent alphaTest={0.35} side={THREE.DoubleSide} roughness={0.9} />
    </instancedMesh>
  );
}

function LightShafts() {
  const tex = useMemo(() => makeShaftTexture(), []);
  const group = useRef<THREE.Group>(null!);
  const shafts: [number, number, number, number][] = [
    [-5, 4, 5.4, 0.13],
    [3, -3, 6.2, 0.1],
    [-12, -6, 5.8, 0.11],
    [7, 11, 6.4, 0.12],
    [-14, 14, 6.8, 0.15],
  ];
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    group.current.children.forEach((c, i) => {
      const m = (c as THREE.Mesh).material as THREE.MeshBasicMaterial;
      m.opacity = shafts[i][3] * (0.8 + 0.3 * Math.sin(t * 0.4 + i * 2));
    });
    group.current.rotation.y = Math.sin(t * 0.05) * 0.01;
  });
  return (
    <group ref={group}>
      {shafts.map(([x, z, y], i) => (
        <mesh key={i} position={[x, y, z]} rotation={[-0.45, 0.2, 0.42]}>
          <planeGeometry args={[2.8, 15]} />
          <meshBasicMaterial
            map={tex}
            transparent
            opacity={0.12}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}

/* ------------------------------------------------------------------ */

export default function Environment() {
  const glow = useGlow();
  return (
    <group>
      <Lights />
      <Ground />
      <GrassField />
      <MossTufts />
      <Clover />
      <MushroomSet />
      <GiantTrunkAndRoots />
      <PebblesAndTwigs glow={glow} />
      <DewDrops />
      <Puddle glow={glow} />
      <Bloomheart glow={glow} />
      <Fireflies glow={glow} />
      <Spores glow={glow} />
      <FallingLeaves />
      <LightShafts />
    </group>
  );
}
