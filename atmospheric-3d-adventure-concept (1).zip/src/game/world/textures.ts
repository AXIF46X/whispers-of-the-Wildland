/**
 * textures.ts — every texture in the prototype is generated at runtime on a
 * 2D canvas (no external files). This keeps the build light and perfectly
 * tileable where needed.
 */
import * as THREE from "three";

function canvas(size: number) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  return { c, g: c.getContext("2d")! };
}

function toTexture(c: HTMLCanvasElement, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

/** soft radial glow — sprites for fireflies, halo, motes */
export function makeGlowTexture(): THREE.Texture {
  const { c, g } = canvas(128);
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.28, "rgba(255,255,255,0.55)");
  grd.addColorStop(0.62, "rgba(255,255,255,0.12)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  return toTexture(c, false);
}

/** vertical gradient streak — fake volumetric light shafts */
export function makeShaftTexture(): THREE.Texture {
  const { c, g } = canvas(128);
  const grd = g.createLinearGradient(0, 0, 0, 128);
  grd.addColorStop(0, "rgba(255,240,214,0.75)");
  grd.addColorStop(0.55, "rgba(255,236,200,0.2)");
  grd.addColorStop(1, "rgba(255,236,200,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  // soften sides
  const side = g.createLinearGradient(0, 0, 128, 0);
  side.addColorStop(0, "rgba(0,0,0,1)");
  side.addColorStop(0.25, "rgba(0,0,0,0)");
  side.addColorStop(0.75, "rgba(0,0,0,0)");
  side.addColorStop(1, "rgba(0,0,0,1)");
  g.globalCompositeOperation = "destination-out";
  g.fillStyle = side;
  g.fillRect(0, 0, 128, 128);
  return toTexture(c, false);
}

/** simple leaf alpha card */
export function makeLeafTexture(): THREE.Texture {
  const { c, g } = canvas(128);
  g.clearRect(0, 0, 128, 128);
  g.translate(64, 66);
  const grad = g.createLinearGradient(0, -52, 0, 52);
  grad.addColorStop(0, "#7fb069");
  grad.addColorStop(0.55, "#5d9153");
  grad.addColorStop(1, "#3f6b3c");
  g.fillStyle = grad;
  g.beginPath();
  g.moveTo(0, -54);
  g.bezierCurveTo(34, -30, 30, 22, 0, 56);
  g.bezierCurveTo(-30, 22, -34, -30, 0, -54);
  g.fill();
  // vein
  g.strokeStyle = "rgba(230,245,220,0.55)";
  g.lineWidth = 2.4;
  g.beginPath();
  g.moveTo(0, -50);
  g.lineTo(0, 50);
  g.stroke();
  g.lineWidth = 1.2;
  for (let i = -3; i <= 3; i++) {
    g.beginPath();
    g.moveTo(0, i * 13);
    g.quadraticCurveTo(12 * Math.sign(i || 1), i * 13 - 6, 20, i * 13 - 14);
    g.stroke();
  }
  return toTexture(c);
}

/** mossy ground detail — pale speckle multiplied by vertex colours */
export function makeGroundTexture(): THREE.Texture {
  const { c, g } = canvas(256);
  g.fillStyle = "#cfdbb4";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 5200; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = Math.random() * 1.9 + 0.3;
    const shade = 150 + Math.random() * 105;
    g.fillStyle = `rgba(${shade * 0.82},${shade},${shade * 0.62},${0.16 + Math.random() * 0.22})`;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  // tiny soil flecks
  for (let i = 0; i < 380; i++) {
    g.fillStyle = `rgba(96,78,54,${0.1 + Math.random() * 0.25})`;
    g.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5);
  }
  const t = toTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(16, 16);
  return t;
}

/** bark — vertical furrows for the giant trunk & root arches */
export function makeBarkTexture(): THREE.Texture {
  const { c, g } = canvas(256);
  g.fillStyle = "#4a3a2a";
  g.fillRect(0, 0, 256, 256);
  for (let x = 0; x < 256; x += 4) {
    const w = 2 + Math.random() * 6;
    const lum = 42 + Math.random() * 42;
    g.fillStyle = `rgba(${lum + 18},${lum},${lum * 0.62},0.6)`;
    g.fillRect(x + Math.sin(x) * 2, 0, w, 256);
  }
  // cracks
  g.strokeStyle = "rgba(18,12,8,0.8)";
  for (let i = 0; i < 26; i++) {
    g.lineWidth = 1 + Math.random() * 2.2;
    g.beginPath();
    let x = Math.random() * 256;
    g.moveTo(x, 0);
    for (let y = 0; y < 256; y += 16) {
      x += (Math.random() - 0.5) * 14;
      g.lineTo(x, y);
    }
    g.stroke();
  }
  // moss patches
  for (let i = 0; i < 22; i++) {
    g.fillStyle = `rgba(90,${120 + Math.random() * 40},70,0.28)`;
    g.beginPath();
    g.ellipse(Math.random() * 256, Math.random() * 256, 6 + Math.random() * 16, 4 + Math.random() * 10, Math.random() * 3, 0, Math.PI * 2);
    g.fill();
  }
  const t = toTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(3, 3);
  return t;
}

/** flowing sap ribbon — warm striped bands, scrolled in-game */
export function makeSapTexture(): THREE.Texture {
  const { c, g } = canvas(128);
  const grd = g.createLinearGradient(0, 0, 128, 0);
  grd.addColorStop(0, "#7a4a16");
  grd.addColorStop(0.42, "#c8862e");
  grd.addColorStop(0.5, "#ffdf9e");
  grd.addColorStop(0.58, "#c8862e");
  grd.addColorStop(1, "#7a4a16");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  // brighter travelling pulses
  for (let i = 0; i < 5; i++) {
    const x = (i * 31 + 11) % 128;
    const pulse = g.createLinearGradient(x, 0, x + 14, 0);
    pulse.addColorStop(0, "rgba(255,240,200,0)");
    pulse.addColorStop(0.5, "rgba(255,240,200,0.9)");
    pulse.addColorStop(1, "rgba(255,240,200,0)");
    g.fillStyle = pulse;
    g.fillRect(x, 0, 14, 128);
  }
  const t = toTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(6, 1);
  return t;
}

/** Rootway portal membrane — a spiraling wheel of twilight */
export function makePortalTexture(): THREE.Texture {
  const { c, g } = canvas(256);
  g.translate(128, 128);
  for (let arm = 0; arm < 3; arm++) {
    for (let i = 0; i < 90; i++) {
      const t = i / 90;
      const a = t * Math.PI * 3.2 + (arm * Math.PI * 2) / 3;
      const r = 8 + t * 112;
      const alpha = 0.55 * (1 - t) + 0.06;
      g.fillStyle = `rgba(${190 + Math.floor(60 * t)},${220 - Math.floor(60 * t)},255,${alpha})`;
      g.beginPath();
      g.arc(Math.cos(a) * r, Math.sin(a) * r, 5.5 * (1 - t) + 1.2, 0, Math.PI * 2);
      g.fill();
    }
  }
  const core = g.createRadialGradient(0, 0, 0, 0, 0, 34);
  core.addColorStop(0, "rgba(240,250,255,0.95)");
  core.addColorStop(1, "rgba(160,200,255,0)");
  g.fillStyle = core;
  g.beginPath();
  g.arc(0, 0, 34, 0, Math.PI * 2);
  g.fill();
  return toTexture(c, false);
}

/** translucent insect wing */
export function makeWingTexture(): THREE.Texture {
  const { c, g } = canvas(128);
  g.clearRect(0, 0, 128, 128);
  const grd = g.createLinearGradient(0, 0, 128, 128);
  grd.addColorStop(0, "rgba(190,225,255,0.85)");
  grd.addColorStop(0.6, "rgba(160,215,255,0.4)");
  grd.addColorStop(1, "rgba(140,200,255,0.05)");
  g.translate(64, 80);
  g.fillStyle = grd;
  g.beginPath();
  g.ellipse(0, -18, 26, 52, -0.25, 0, Math.PI * 2);
  g.fill();
  g.strokeStyle = "rgba(255,255,255,0.5)";
  g.lineWidth = 1.4;
  for (let i = 0; i < 4; i++) {
    g.beginPath();
    g.moveTo(-6, 22);
    g.quadraticCurveTo(8 + i * 5, -10 - i * 10, 12 + i * 3, -34 - i * 8);
    g.stroke();
  }
  return toTexture(c);
}
