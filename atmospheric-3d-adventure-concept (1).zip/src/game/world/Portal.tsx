/**
 * Portal.tsx — "Rootway" gates. Ancient ring-vaults grown from braided
 * roots that stitch the twelve regions together. Unlocked portals show a
 * swirling twilight membrane with orbiting seed-motes; dormant ones are
 * sealed with a stone plug and softly refuse.
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useGame, type RegionId } from "../store";
import { audio } from "../audio";
import { sampleHeight } from "./sampler";
import { makeGlowTexture, makePortalTexture, makeBarkTexture } from "./textures";

export default function Portal({
  id,
  pos,
  to,
  label,
  tint = "#9fd8ff",
  locked = false,
  lockedNote,
}: {
  id: string;
  pos: [number, number];
  to: RegionId | null;
  label: string;
  tint?: string;
  locked?: boolean;
  lockedNote?: string;
}) {
  const group = useRef<THREE.Group>(null!);
  const membrane = useRef<THREE.Mesh>(null!);
  const motes = useRef<THREE.Group>(null!);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const bark = useMemo(() => makeBarkTexture(), []);
  const swirl = useMemo(() => {
    const t = makePortalTexture();
    t.center.set(0.5, 0.5);
    return t;
  }, []);
  const y = useMemo(() => sampleHeight(pos[0], pos[1]), [pos]);

  /* register as an interactable */
  useEffect(() => {
    useGame.getState().registerInteractable({
      id,
      label: locked ? (lockedNote ?? "A dormant Rootway") : label,
      radius: 2.8,
      enabled: true,
      getPos: () => ({ x: pos[0], y: y + 1.7, z: pos[1] }),
      action: () => {
        const s = useGame.getState();
        if (locked || !to) {
          audio.denied();
          s.say("The Rootway", "*(sealed — this way still sleeps)*");
          return;
        }
        if (s.travelingTo) return;
        s.say("The Rootway", "*the ring drinks the light, and turns…*");
        s.setTravelingTo(to);
      },
    });
    return () => useGame.getState().unregisterInteractable(id);
  }, [id, label, locked, lockedNote, pos, to, y]);

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    swirl.rotation -= dt * (locked ? 0.05 : 0.22);
    group.current.position.y = y + 1.7 + Math.sin(t * 1.1) * 0.06;
    const m = membrane.current.material as THREE.MeshBasicMaterial;
    m.opacity = locked ? 0.16 : 0.72 + Math.sin(t * 2.1) * 0.14;
    motes.current.children.forEach((child, i) => {
      const a = t * 0.9 + (i / motes.current.children.length) * Math.PI * 2;
      child.position.set(Math.cos(a) * 1.55, Math.sin(t * 1.7 + i) * 0.5, Math.sin(a) * 1.55);
    });
  });

  return (
    <group
      ref={group}
      position={[pos[0], y + 1.7, pos[1]]}
      onClick={(e) => {
        e.stopPropagation();
        const s = useGame.getState();
        if (locked || !to || s.travelingTo) return;
        s.say("The Rootway", "*the ring drinks the light, and turns…*");
        s.setTravelingTo(to);
      }}
    >
      {/* braided root ring */}
      <mesh rotation={[0, 0, 0]} castShadow>
        <torusGeometry args={[1.35, 0.16, 10, 36]} />
        <meshStandardMaterial map={bark} color="#5d4a35" roughness={0.95} />
      </mesh>
      <mesh rotation={[0, 0, 0.5]}>
        <torusGeometry args={[1.35, 0.07, 8, 36]} />
        <meshStandardMaterial map={bark} color="#4a3a2a" roughness={1} />
      </mesh>
      {/* twilight membrane */}
      <mesh ref={membrane}>
        <circleGeometry args={[1.22, 40]} />
        <meshBasicMaterial
          map={swirl}
          color={tint}
          transparent
          opacity={locked ? 0.15 : 0.8}
          side={THREE.DoubleSide}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
      {/* sealed plug */}
      {locked && (
        <mesh position={[0, -0.4, 0.05]}>
          <dodecahedronGeometry args={[0.7, 0]} />
          <meshStandardMaterial color="#57504a" roughness={0.9} />
        </mesh>
      )}
      <sprite scale={[4.4, 4.4, 1]} position={[0, 0, -0.2]}>
        <spriteMaterial
          map={glowTex}
          color={tint}
          transparent
          opacity={locked ? 0.06 : 0.32}
          depthWrite={false}
        />
      </sprite>
      {/* orbiting seed-motes */}
      <group ref={motes}>
        {[...Array(locked ? 0 : 8)].map((_, i) => (
          <sprite key={i} scale={[0.22, 0.22, 1]}>
            <spriteMaterial map={glowTex} color={tint} transparent opacity={0.85} depthWrite={false} />
          </sprite>
        ))}
      </group>
      {!locked && <pointLight color={tint} intensity={2.6} distance={6} decay={2} />}
    </group>
  );
}
