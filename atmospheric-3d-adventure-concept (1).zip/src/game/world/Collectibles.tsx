/**
 * Collectibles.tsx — memory motes. Optional discoveries that reveal
 * world-building (no grinding: every one carries a story fragment).
 * Region-driven: the active region supplies its mote table, its rite
 * memory and its completion epilogue.
 */
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { RT } from "../runtime";
import { audio } from "../audio";
import { useGame } from "../store";
import { makeGlowTexture } from "./textures";

export interface MoteData {
  id: string;
  title: string;
  text: string;
  pos: [number, number];
}

function Mote({
  id,
  title,
  text,
  pos,
  baseY,
  onCollect,
}: MoteData & { baseY: number; onCollect: (id: string, title: string, text: string) => void }) {
  const group = useRef<THREE.Group>(null!);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const collected = useGame((s) => s.memories.some((m) => m.id === id));

  useFrame((state) => {
    if (collected) return;
    const t = state.clock.elapsedTime;
    group.current.position.y = baseY + Math.sin(t * 1.6 + pos[0]) * 0.14;
    group.current.rotation.y = t * 0.8;
    const d = RT.playerPos.distanceTo(group.current.position);
    if (d < 1.15) onCollect(id, title, text);
    const pulse = 0.85 + Math.sin(t * 3) * 0.15;
    group.current.scale.setScalar(pulse);
  });

  if (collected) return null;
  return (
    <group ref={group} position={[pos[0], baseY, pos[1]]}>
      <mesh
        onClick={(e) => {
          e.stopPropagation();
          if (RT.wasDrag) return;
          const s = useGame.getState();
          if (RT.playerPos.distanceTo(group.current.position) < 4.5) {
            onCollect(id, title, text);
          } else {
            audio.denied();
            s.say("Milo", "*(too far — follow your feet first)*");
          }
        }}
      >
        <icosahedronGeometry args={[0.13, 0]} />
        <meshStandardMaterial color="#cfeeff" emissive="#8fd4ff" emissiveIntensity={1.8} roughness={0.2} />
      </mesh>
      <sprite scale={[0.9, 0.9, 1]}>
        <spriteMaterial map={glowTex} color="#9fd8ff" transparent opacity={0.55} depthWrite={false} />
      </sprite>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.28, 0.008, 6, 32]} />
        <meshBasicMaterial color="#9fd8ff" transparent opacity={0.35} depthWrite={false} />
      </mesh>
    </group>
  );
}

export default function Collectibles({
  motes,
  bloom,
  bloomPos,
  bloomVisible,
  regionId,
  epilogueObjective,
}: {
  motes: MoteData[];
  bloom: { id: string; title: string; text: string };
  bloomPos: [number, number];
  bloomVisible: boolean;
  regionId: string;
  epilogueObjective: string;
}) {
  const collect = (id: string, title: string, text: string) => {
    const s = useGame.getState();
    if (s.memories.some((m) => m.id === id)) return;
    audio.collect();
    s.addMemory({ id, title, text });
    s.markProgress();
    s.pushToast(title, "A memory settles into your journal");
    if (id === bloom.id) {
      s.completeRegion(regionId);
      window.setTimeout(() => {
        const st = useGame.getState();
        st.setPhase("epilogue");
        st.setObjective(epilogueObjective);
      }, 600);
    }
  };

  const heightOf = (pos: [number, number]) => {
    // sampled lazily from the active region's sampler
    return posY(pos);
  };

  return (
    <group>
      {motes.map((m) => (
        <Mote key={m.id} {...m} baseY={heightOf(m.pos) + 1.05} onCollect={collect} />
      ))}
      {bloomVisible && (
        <Mote
          id={bloom.id}
          title={bloom.title}
          text={bloom.text}
          pos={bloomPos}
          baseY={heightOf(bloomPos) + 1.15}
          onCollect={collect}
        />
      )}
    </group>
  );
}

/* indirection so motes track whichever region is active */
import { sampleHeight as posYRaw } from "./sampler";
function posY(pos: [number, number]) {
  return posYRaw(pos[0], pos[1]);
}
