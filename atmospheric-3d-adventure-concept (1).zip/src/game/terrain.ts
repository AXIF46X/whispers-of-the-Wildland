/**
 * terrain.ts — analytic height field for the Fallen Garden.
 *
 * The ground mesh is displaced with this exact function, and every gameplay
 * system (player, creature, beam, droplets) samples it directly, so visuals
 * and logic can never disagree. Cheap, allocation-free, mobile-friendly.
 */
import { MOUNDS } from "./layout";

const smooth = (t: number) => t * t * (3 - 2 * t);

export function terrainHeight(x: number, z: number): number {
  // Large, soft swells — reads as gentle mossy undulation at macro scale.
  let h =
    0.45 * Math.sin(x * 0.16 + 0.8) * Math.cos(z * 0.14 - 0.4) +
    0.22 * Math.sin(x * 0.42 + 1.9) * Math.sin(z * 0.37 + 0.6) +
    0.08 * Math.sin(x * 1.05 - z * 0.8);

  // Authored moss mounds (gaussian bumps).
  for (const [mx, mz, r, amp] of MOUNDS) {
    const dx = x - mx;
    const dz = z - mz;
    const d2 = (dx * dx + dz * dz) / (r * r);
    if (d2 < 4) h += amp * Math.exp(-d2 * 1.6);
  }

  // Rim rise — the garden sits in a shallow bowl; edges climb past the fog
  // so the horizon always reads as dense forest floor, never empty void.
  const r = Math.sqrt(x * x + z * z);
  if (r > 22) {
    const t = smooth(Math.min(1, (r - 22) / 16));
    h += t * t * 6.5;
  }
  return h;
}

/** Approximate surface normal via central differences (for slope tilt). */
export function terrainSlope(
  x: number,
  z: number,
  out: { fx: number; fz: number }
) {
  const e = 0.35;
  out.fx = (terrainHeight(x + e, z) - terrainHeight(x - e, z)) / (2 * e);
  out.fz = (terrainHeight(x, z + e) - terrainHeight(x, z - e)) / (2 * e);
}
