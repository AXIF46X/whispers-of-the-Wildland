/**
 * audio.ts — fully procedural WebAudio engine ("Symbiotic Sound" prototype).
 *
 * No audio files: the soundscape is *grown* from oscillators, filtered noise
 * and scheduled randomness, which also makes it adaptive by construction —
 * wind gusts couple into the grass shader (via RT.wind), and the harmonic
 * content shifts when the Heartlight is restored.
 *
 * Everything is created lazily on the first user gesture (browser policy).
 */
import { RT } from "./runtime";

// D-minor pentatonic ladder — the musical identity of the garden.
const SCALE = [146.83, 174.61, 196.0, 220.0, 261.63, 293.66, 349.23];

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private music!: GainNode;
  private sfx!: GainNode;
  private windGain!: GainNode;
  private beamGain!: GainNode;
  private started = false;
  private volume = 0.8;
  private muted = false;
  private timers: number[] = [];

  get ready() {
    return this.started;
  }

  init() {
    if (this.started) return;
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new Ctx();
    } catch {
      return;
    }
    const ctx = this.ctx!;
    this.started = true;

    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : this.volume;
    this.master.connect(ctx.destination);

    this.music = ctx.createGain();
    this.music.gain.value = 0.5;
    this.music.connect(this.master);
    this.sfx = ctx.createGain();
    this.sfx.gain.value = 0.9;
    this.sfx.connect(this.master);

    this.buildWind();
    this.buildPad();
    this.buildBeamDrone();
    this.schedulePlucks();
    this.scheduleGusts();
    this.scheduleShimmer();
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.ctx && !this.muted) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.1);
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : this.volume, this.ctx.currentTime, 0.08);
  }

  /* ---------------- ambience: wind ---------------- */
  private buildWind() {
    const ctx = this.ctx!;
    const len = 4 * ctx.sampleRate;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let b = 0;
    for (let i = 0; i < len; i++) {
      // pinkish noise via leaky integrator
      b = 0.985 * b + 0.015 * (Math.random() * 2 - 1);
      data[i] = b * 3.2;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 420;
    lp.Q.value = 0.4;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0.05;
    src.connect(lp).connect(this.windGain).connect(this.master);
    src.start();
  }

  /* ---------------- ambience: breathing pad ---------------- */
  private buildPad() {
    const ctx = this.ctx!;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 520;
    const padGain = ctx.createGain();
    padGain.gain.value = 0.045;
    lp.connect(padGain).connect(this.music);

    const roots = [73.42, 110.0, 146.83];
    const oscs = roots.map((f, i) => {
      const o = ctx.createOscillator();
      o.type = i === 1 ? "triangle" : "sine";
      o.frequency.value = f;
      o.detune.value = i * 4 - 4;
      const g = ctx.createGain();
      g.gain.value = i === 0 ? 0.9 : 0.5;
      // slow breathing on each voice
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.05 + i * 0.023;
      const lfoG = ctx.createGain();
      lfoG.gain.value = 0.22;
      lfo.connect(lfoG).connect(g.gain);
      o.connect(g).connect(lp);
      o.start();
      lfo.start();
      return o;
    });

    // glacial chord drift — the garden slowly re-harmonizes itself
    const drift = () => {
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      oscs.forEach((o, i) => {
        const target = roots[i] * (Math.random() < 0.4 ? 1.5 : Math.random() < 0.5 ? 1.189 : 1);
        o.frequency.setTargetAtTime(target, t, 6);
      });
      this.timers.push(window.setTimeout(drift, 14000 + Math.random() * 9000));
    };
    this.timers.push(window.setTimeout(drift, 9000));
  }

  /* ---------------- the Heartlight beam drone ---------------- */
  private buildBeamDrone() {
    const ctx = this.ctx!;
    this.beamGain = ctx.createGain();
    this.beamGain.gain.value = 0;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 1200;
    this.beamGain.connect(lp).connect(this.master);
    [440, 554.37, 659.25].forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = f;
      o.detune.value = i * 6 - 6;
      const g = ctx.createGain();
      g.gain.value = 0.05;
      o.connect(g).connect(this.beamGain!);
      o.start();
    });
  }

  setBeamGlow(on: number) {
    // 0..1 — swells as the beam climbs the shard-stones
    if (this.ctx) this.beamGain.gain.setTargetAtTime(on * 0.5, this.ctx.currentTime, 0.6);
  }

  /* ---------------- generative pluck melody ---------------- */
  private pluck(freq: number, when: number, dur = 1.9) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = "triangle";
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(0.14, when + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0008, when + dur);
    const dly = ctx.createDelay(1);
    dly.delayTime.value = 0.42;
    const fb = ctx.createGain();
    fb.gain.value = 0.32;
    dly.connect(fb).connect(dly);
    const wet = ctx.createGain();
    wet.gain.value = 0.25;
    o.connect(g);
    g.connect(this.music);
    g.connect(dly);
    dly.connect(wet).connect(this.music);
    o.start(when);
    o.stop(when + dur + 0.1);
  }

  private schedulePlucks() {
    const step = () => {
      if (!this.ctx) return;
      const t = this.ctx.currentTime + 0.05;
      const n = SCALE[Math.floor(Math.random() * SCALE.length)];
      this.pluck(n * (Math.random() < 0.3 ? 2 : 1), t);
      if (Math.random() < 0.35) {
        this.pluck(n * 0.5, t + 0.28, 2.6); // soft root answer
      }
      this.timers.push(window.setTimeout(step, 2600 + Math.random() * 4200));
    };
    this.timers.push(window.setTimeout(step, 2500));
  }

  /* ---------------- gusts — drive audio AND grass ---------------- */
  private scheduleGusts() {
    const gust = () => {
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const peak = 0.09 + Math.random() * 0.1;
      this.windGain.gain.cancelScheduledValues(t);
      this.windGain.gain.setTargetAtTime(peak, t, 1.4);
      this.windGain.gain.setTargetAtTime(0.045, t + 3, 2.2);
      // couple into the vegetation shader
      RT.wind = 0.6 + peak * 6;
      window.setTimeout(() => (RT.wind = 0.6), 3400);
      this.timers.push(window.setTimeout(gust, 7000 + Math.random() * 12000));
    };
    this.timers.push(window.setTimeout(gust, 4000));
  }

  /* ---------------- distant shimmer (unseen insects) ---------------- */
  private scheduleShimmer() {
    const step = () => {
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const o = this.ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = 1800 + Math.random() * 2600;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.02 + Math.random() * 0.02, t + 0.08);
      g.gain.exponentialRampToValueAtTime(0.0005, t + 0.9);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 1);
      this.timers.push(window.setTimeout(step, 5000 + Math.random() * 10000));
    };
    this.timers.push(window.setTimeout(step, 6000));
  }

  /* ================= SFX ================= */

  private blip(freqA: number, freqB: number, dur: number, type: OscillatorType, vol: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freqA, t);
    o.frequency.exponentialRampToValueAtTime(freqB, t + dur * 0.8);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0006, t + dur);
    o.connect(g).connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  /** Lume's voice — three invented chirp dialects. */
  chirp(kind: "call" | "point" | "joy" = "call") {
    if (!this.ctx) return;
    if (kind === "call") {
      this.blip(1250, 1900, 0.16, "sine", 0.1);
      window.setTimeout(() => this.blip(1600, 1100, 0.14, "sine", 0.08), 140);
    } else if (kind === "point") {
      this.blip(900, 2200, 0.3, "sine", 0.11);
      window.setTimeout(() => this.blip(2200, 2600, 0.12, "sine", 0.07), 240);
    } else {
      [0, 90, 190, 320].forEach((d, i) =>
        window.setTimeout(() => this.blip(1400 + i * 320, 1900 + i * 380, 0.14, "sine", 0.09), d)
      );
    }
  }

  /** shard-stone rotation — stone + crystal tick */
  tick() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    // stone scrape
    const noise = ctx.createBufferSource();
    const len = 0.18 * ctx.sampleRate;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    noise.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 300;
    bp.Q.value = 1.2;
    const g = ctx.createGain();
    g.gain.value = 0.5;
    noise.connect(bp).connect(g).connect(this.sfx);
    noise.start(t);
    // crystal clink
    this.blip(2480, 2300, 0.5, "sine", 0.1);
  }

  step() {
    this.blip(190 + Math.random() * 60, 120, 0.09, "sine", 0.05);
  }

  /** Milo's hop — a soft spring with a seed-rattle top */
  hop() {
    this.blip(260, 620, 0.16, "sine", 0.07);
    window.setTimeout(() => this.blip(1400, 1900, 0.06, "triangle", 0.03), 40);
  }

  ui() {
    this.blip(660, 880, 0.09, "sine", 0.06);
  }

  denied() {
    this.blip(220, 180, 0.2, "triangle", 0.08);
  }

  collect() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [293.66, 369.99, 440, 587.33].forEach((f, i) =>
      this.pluckAt(f, t + i * 0.09)
    );
  }

  private pluckAt(freq: number, when: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = "sine";
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(0.16, when + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0007, when + 1.6);
    o.connect(g).connect(this.sfx);
    o.start(when);
    o.stop(when + 1.7);
  }

  /** hanging root-bell — a struck chime with a metallic partial */
  bell(freq: number, good = true) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (!good) {
      // gentle discord: two close tones beating — never punishing
      this.blip(freq * 0.94, freq * 0.9, 0.5, "triangle", 0.09);
      window.setTimeout(() => this.blip(freq * 1.06, freq * 1.02, 0.4, "triangle", 0.06), 60);
      return;
    }
    [1, 2.76, 5.4].forEach((mul, i) => {
      const o = this.ctx!.createOscillator();
      o.type = "sine";
      o.frequency.value = freq * mul;
      const g = this.ctx!.createGain();
      const vol = [0.16, 0.05, 0.025][i];
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.012 + i * 0.004);
      g.gain.exponentialRampToValueAtTime(0.0006, t + 2.1 - i * 0.4);
      o.connect(g).connect(this.sfx);
      o.start(t);
      o.stop(t + 2.2);
    });
  }

  /** Rootheart ignition — the deep counterpart of the garden bloom */
  vaultChord() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [110, 146.83, 220, 293.66, 369.99, 440].forEach((f, i) =>
      this.pluckAt(f, t + 0.15 + i * 0.18)
    );
    const o = this.ctx.createOscillator();
    o.type = "sine";
    o.frequency.value = 55;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.26, t + 2);
    g.gain.exponentialRampToValueAtTime(0.001, t + 8);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + 8.2);
  }

  /** portal whoosh for the Rootway */
  whoosh() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const noise = ctx.createBufferSource();
    const len = 1.1 * ctx.sampleRate;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.sin((i / len) * Math.PI);
    noise.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.setValueAtTime(300, t);
    bp.frequency.exponentialRampToValueAtTime(2400, t + 0.8);
    bp.Q.value = 1.6;
    const g = ctx.createGain();
    g.gain.value = 0.7;
    noise.connect(bp).connect(g).connect(this.sfx);
    noise.start(t);
  }

  /** the Bloomheart wakes — four-note rising answer + pad swell */
  bloom() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [146.83, 220, 293.66, 440, 587.33, 880].forEach((f, i) =>
      this.pluckAt(f, t + 0.15 + i * 0.16)
    );
    this.setBeamGlow(0);
    // low warm swell
    const o = this.ctx.createOscillator();
    o.type = "sine";
    o.frequency.value = 73.42;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.22, t + 1.6);
    g.gain.exponentialRampToValueAtTime(0.001, t + 7);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + 7.2);
  }
}

export const audio = new AudioEngine();
