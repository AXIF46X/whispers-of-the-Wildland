/**
 * layout.ts — single source of truth for world-space placement in
 * "The Fallen Garden" (prototype region). Units: meters (Milo is ~0.5m tall —
 * the garden is authored at insect scale).
 *
 * Beam puzzle geometry is designed on 90° turns so crystal mirrors only ever
 * need diagonal orientations (45° / 135°), which keeps the interaction
 * readable: each tap rotates a shard by 45°, and the light either finds its
 * way onward or dies out — clear, visual, no pixel hunting.
 */

export const WORLD = {
  /** soft gameplay bounds (visual barriers continue past this) */
  playRadius: 19.5,
  groundRadius: 55,
  /** height of the sunbeam above each node's ground sample */
  beamLift: 1.55,
};

export const SPAWN: [number, number] = [0, 14];

/** The ancient broken arch that catches the last sunbeam. Emits +X. */
export const SOURCE = {
  pos: [-10, -2] as [number, number],
  dir: [1, 0] as [number, number],
};

/**
 * Three shard-stones. `state` = quarter-turn index (0..3) → mirror plane
 * angle = state * 45°. Correct states bend the beam N, W, N onto the bud.
 */
export const PRISMS = [
  { id: "prism-0", pos: [-4, -2] as [number, number], correct: 1, initial: 0 },
  { id: "prism-1", pos: [-4, 4] as [number, number], correct: 3, initial: 1 },
  { id: "prism-2", pos: [-10, 4] as [number, number], correct: 3, initial: 0 },
];

/** The sleeping Bloomheart — puzzle target & emotional beat of phase 1. */
export const FLOWER = { pos: [-10, 11] as [number, number], budHeight: 2.7 };

/** Lume's guided-tour waypoints (movement goal-posts for the companion AI). */
export const MOTH_WAYPOINTS: [number, number][] = [
  [-1, 9],
  [-3.5, 4.5],
  [-6.5, 0.5],
  [-5.2, -2.6],
];

/** Ambient memory motes (optional collectibles) + the bloom memory. */
export const MEMORY_MOTES = [
  {
    id: "mote-dew",
    pos: [7, 10] as [number, number],
    title: "Memory — First Rain",
    text: "Drops the size of houses. The garden drank, and something beneath the roots drank with it.",
  },
  {
    id: "mote-stone",
    pos: [12.5, -7] as [number, number],
    title: "Memory — The Builders",
    text: "Hands of bark and brass planted this garden twice: once as seed, once as machine.",
  },
  {
    id: "mote-south",
    pos: [3, -11.5] as [number, number],
    title: "Memory — A Warm Voice",
    text: "\u2018Grow toward the light, little engine. The rest we will teach the rain.\u2019",
  },
];

export const BLOOM_MEMORY = {
  id: "mote-bloom",
  title: "Memory — The Heartlight",
  text: "The Bloomheart was never a flower. It is a lamp the forest lit to remember the sun by — and its light is going out, one garden at a time.",
};

/** Per-region spawn points (player arrives facing -Z / north). */
export const SPAWNS: Record<string, [number, number]> = {
  garden: [0, 14],
  root: [0, -9.8],
};

/** The Rootway portal in the Fallen Garden — blooms open after the rite. */
export const GARDEN_PORTAL_POS: [number, number] = [-7.5, 16.2];

/** Moss mound bumps fed into the terrain height field. [x, z, radius, height] */
export const MOUNDS: [number, number, number, number][] = [
  [5.5, 3, 3.4, 0.55],
  [-0.5, -5.5, 3.0, 0.42],
  [8.5, -2.5, 2.6, 0.36],
  [-7.5, 8.5, 2.2, 0.3],
  [13, 6, 3.2, 0.5],
  [-14, -6, 3.6, 0.6],
];
