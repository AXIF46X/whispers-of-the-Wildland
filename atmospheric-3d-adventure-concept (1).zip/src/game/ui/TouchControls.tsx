/**
 * TouchControls.tsx — the mobile control layer: movement stick on one
 * thumb, an action cluster on the other. Layout mirrors for left-handed
 * players. Everything writes into the shared input bus, so touch and
 * keyboard are indistinguishable to the game systems.
 */
import { useEffect } from "react";
import { ChevronsUp, Crosshair, Footprints, Hand, Minus, Plus } from "lucide-react";
import { input, queueJump, queueRecenter, setTouchVector } from "../input";
import { audio } from "../audio";
import { useGame } from "../store";
import Joystick from "./Joystick";

function RoundButton({
  label,
  onPress,
  children,
  size = "md",
  active = false,
  highlight = false,
}: {
  label: string;
  onPress: () => void;
  children: React.ReactNode;
  size?: "sm" | "md" | "lg";
  active?: boolean;
  highlight?: boolean;
}) {
  const dim = size === "lg" ? "h-[4.5rem] w-[4.5rem]" : size === "md" ? "h-14 w-14" : "h-11 w-11";
  return (
    <button
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onPress();
      }}
      className={`pointer-events-auto grid ${dim} touch-none place-items-center rounded-full glass-panel transition active:scale-90 ${
        highlight
          ? "border-ember/60 text-ember shadow-[0_0_28px_rgba(242,177,94,0.35)]"
          : active
            ? "border-ember/50 text-ember"
            : "text-mist/85"
      }`}
    >
      {children}
    </button>
  );
}

export default function TouchControls() {
  const touchMode = useGame((s) => s.touchMode);
  const panel = useGame((s) => s.panel);
  const phase = useGame((s) => s.phase);
  const traveling = useGame((s) => s.travelingTo);
  const target = useGame((s) => (s.interactTargetId ? s.interactables[s.interactTargetId] : null));
  const settings = useGame((s) => s.settings);

  const hidden = !touchMode || panel !== "none" || !!traveling || phase === "intro";

  /* if the controls vanish mid-drag (panel opened, portal fired), release
     the stick — otherwise Milo would keep walking into the fade. */
  useEffect(() => {
    if (hidden) setTouchVector(0, 0, false, false);
  }, [hidden]);

  if (hidden) return null;

  const stickSide = settings.leftHanded ? "right" : "left";
  const actionSide = settings.leftHanded ? "left-5" : "right-5";

  return (
    <>
      <Joystick side={stickSide} runLatched={settings.runToggle} />

      {/* action cluster */}
      <div className={`pointer-events-none absolute bottom-[13vh] z-30 flex flex-col items-center gap-3 ${actionSide}`}>
        {/* zoom pair */}
        <div className="pointer-events-none flex gap-2">
          <RoundButton
            label="Zoom out"
            size="sm"
            onPress={() => {
              input.zoom = 1;
              window.setTimeout(() => (input.zoom = 0), 190);
            }}
          >
            <Minus size={16} />
          </RoundButton>
          <RoundButton
            label="Zoom in"
            size="sm"
            onPress={() => {
              input.zoom = -1;
              window.setTimeout(() => (input.zoom = 0), 190);
            }}
          >
            <Plus size={16} />
          </RoundButton>
        </div>

        <div className="flex items-end gap-3">
          <div className="flex flex-col gap-3">
            <RoundButton
              label="Recenter camera"
              size="sm"
              onPress={() => {
                queueRecenter();
                audio.ui();
              }}
            >
              <Crosshair size={16} />
            </RoundButton>
            <RoundButton
              label={settings.runToggle ? "Run: on" : "Run: off"}
              size="sm"
              active={settings.runToggle}
              onPress={() => {
                useGame.getState().updateSettings({ runToggle: !settings.runToggle });
                audio.ui();
              }}
            >
              <Footprints size={16} />
            </RoundButton>
          </div>

          <div className="flex flex-col gap-3">
            <RoundButton label="Hop" onPress={() => queueJump()}>
              <ChevronsUp size={22} />
            </RoundButton>
            <RoundButton
              label={target ? target.label : "Interact"}
              size="lg"
              highlight={!!target}
              onPress={() => {
                const s = useGame.getState();
                const t = s.interactTargetId ? s.interactables[s.interactTargetId] : null;
                if (t?.enabled) t.action();
                else audio.denied();
              }}
            >
              <Hand size={26} />
            </RoundButton>
          </div>
        </div>
      </div>
    </>
  );
}
