/**
 * HUD.tsx — minimal cinematic interface. The chrome is intentionally quiet:
 * an objective chip, five small verbs (hint / journal / map / sound /
 * settings), a subtitle rail with accessibility-aware styling, a context-
 * sensitive interaction prompt, and letterboxed title cards for scripted
 * moments. Nothing competes with the garden.
 */
import { useEffect, useState } from "react";
import {
  BookOpenText,
  Compass,
  Gamepad2,
  Lightbulb,
  Map as MapIcon,
  RotateCcw,
  ScrollText,
  Settings,
  Sparkles,
  Sprout,
  Volume2,
  VolumeX,
} from "lucide-react";
import { RT } from "../runtime";
import { useGame } from "../store";
import { showHint } from "../hints";
import { CONTROL_TIPS, DESKTOP_CONTROLS, MOBILE_CONTROLS } from "../controls";

const SUB_SIZE = ["text-sm", "text-base", "text-lg"] as const;

function IconButton({
  label,
  onClick,
  children,
  pulse = false,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  pulse?: boolean;
}) {
  return (
    <button
      aria-label={label}
      title={label}
      onClick={onClick}
      className={`relative grid h-10 w-10 place-items-center rounded-full glass-panel text-mist/90 transition hover:text-ember hover:border-ember/40 ${
        pulse ? "animate-pulse-soft" : ""
      }`}
    >
      {children}
    </button>
  );
}

export default function HUD({ onOpenDoc }: { onOpenDoc: () => void }) {
  const objective = useGame((s) => s.objective);
  const subtitle = useGame((s) => s.subtitle);
  const toast = useGame((s) => s.toast);
  const hintText = useGame((s) => s.hintText);
  const phase = useGame((s) => s.phase);
  const panel = useGame((s) => s.panel);
  const target = useGame((s) => (s.interactTargetId ? s.interactables[s.interactTargetId] : null));
  const settings = useGame((s) => s.settings);
  const touchMode = useGame((s) => s.touchMode);
  const memories = useGame((s) => s.memories);
  const creatures = useGame((s) => s.creatures);
  const region = useGame((s) => s.region);
  const travelingTo = useGame((s) => s.travelingTo);
  const rootUnlocked = useGame((s) => s.unlocked.includes("root"));

  const [cinematic, setCinematic] = useState(true);
  const [epilogueDismissed, setEpilogueDismissed] = useState(false);

  /* a restarted chapter gives the card a fresh chance to appear */
  useEffect(() => {
    if (phase === "intro" || phase === "explore") setEpilogueDismissed(false);
  }, [phase]);

  /* poll the (non-reactive) cutscene channel for letterboxing */
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = useGame.getState();
      setCinematic(!!RT.cutscene || s.phase === "intro" || s.phase === "solved");
    }, 120);
    return () => window.clearInterval(id);
  }, []);

  /* auto-dismiss hint */
  useEffect(() => {
    if (!hintText) return;
    const id = window.setTimeout(() => useGame.setState({ hintText: null }), 9000);
    return () => window.clearTimeout(id);
  }, [hintText]);

  /* auto-dismiss toast */
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => useGame.getState().clearToast(), 5200);
    return () => window.clearTimeout(id);
  }, [toast]);

  /* subtitle lifetime */
  useEffect(() => {
    if (!subtitle) return;
    const key = subtitle.key;
    const id = window.setTimeout(() => {
      const s = useGame.getState();
      if (s.subtitle?.key === key) useGame.setState({ subtitle: null });
    }, 4200);
    return () => window.clearTimeout(id);
  }, [subtitle]);

  const showNote = !settings.seenControls;
  const showChrome = panel === "none" && phase !== "intro" && !showNote;
  const rows = touchMode ? MOBILE_CONTROLS : DESKTOP_CONTROLS;

  return (
    <div className="pointer-events-none absolute inset-0 select-none font-body">
      {/* ---------- first-run controls note ---------- */}
      {showNote && (
        <div className="pointer-events-auto absolute inset-0 z-[55] grid place-items-center bg-black/70 p-4 backdrop-blur-sm animate-fade-soft">
          <div className="wild-scroll relative max-h-[88vh] w-[min(94vw,34rem)] overflow-y-auto rounded-3xl glass-panel p-7 noise-veil md:p-9">
            <p className="font-mono text-[10px] tracking-[0.45em] text-ember">BEFORE YOU GO SMALL</p>
            <h2 className="mt-3 font-display text-3xl font-light italic text-[#f6e8cf]">
              How to move through the Wildland
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-mist/70">
              You are Milo — about the height of a grass seed. Nothing here can hurt you, so
              wander, touch things, and let the forest answer.
            </p>

            <div className="mt-5 flex items-center gap-2">
              <span className="rounded-full bg-ember/15 px-3 py-1 font-mono text-[9px] tracking-[0.2em] text-ember">
                {touchMode ? "TOUCH DETECTED" : "KEYBOARD & MOUSE"}
              </span>
              <span className="font-mono text-[9px] tracking-[0.2em] text-mist/35">
                BOTH SCHEMES WORK AT ANY TIME
              </span>
            </div>

            <div className="mt-4 grid gap-1.5">
              {rows.map((r) => (
                <div
                  key={r.action}
                  className="flex items-center gap-3 rounded-xl hairline px-3 py-2"
                >
                  <div className="flex w-32 shrink-0 flex-wrap gap-1">
                    {r.keys.map((k) => (
                      <span key={k} className="key-chip">
                        {k}
                      </span>
                    ))}
                  </div>
                  <div className="min-w-0">
                    <p className="text-[13px] font-medium leading-tight text-mist">{r.action}</p>
                    {r.note && <p className="text-[11px] leading-tight text-mist/45">{r.note}</p>}
                  </div>
                </div>
              ))}
            </div>

            <ul className="mt-4 space-y-1">
              {CONTROL_TIPS.map((t) => (
                <li key={t} className="flex gap-2 text-[11.5px] leading-relaxed text-mist/55">
                  <Sparkles size={11} className="mt-1 shrink-0 text-moss" />
                  {t}
                </li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              <button
                onClick={() => useGame.getState().updateSettings({ seenControls: true })}
                className="rounded-full bg-ember px-6 py-2.5 text-sm font-bold text-[#241708] transition hover:bg-ember-deep"
              >
                Begin the descent
              </button>
              <span className="font-mono text-[10px] tracking-[0.2em] text-mist/35">
                REOPEN ANYTIME — {touchMode ? "GAMEPAD ICON" : "PRESS C"}
              </span>
            </div>
          </div>
        </div>
      )}
      {/* letterbox */}
      <div
        className={`absolute inset-x-0 top-0 z-20 bg-black transition-transform duration-700 ${cinematic ? "h-[7vh]" : "h-0"}`}
      />
      <div
        className={`absolute inset-x-0 bottom-0 z-20 bg-black transition-transform duration-700 ${cinematic || subtitle ? "h-[7vh]" : "h-0"}`}
      />

      {/* intro title card */}
      {phase === "intro" && (
        <div className="absolute inset-0 z-30 grid place-items-center">
          <div className="animate-rise text-center">
            <p className="font-mono text-[11px] tracking-[0.5em] text-moss/80">
              CHAPTER 0 · THE AWAKENING
            </p>
            <h1 className="mt-4 font-display text-4xl font-light italic text-glow-ember text-[#f6e8cf] md:text-6xl">
              Whispers of the Wildland
            </h1>
            <p className="mt-3 text-sm text-mist/70">the garden is very quiet tonight</p>
            {!settings.reducedMotion && (
              <p className="mt-10 animate-pulse-soft font-mono text-[10px] tracking-[0.3em] text-mist/40">
                {touchMode ? "DRAG TO LOOK · JOYSTICK TO WALK" : "WASD WALK · DRAG ORBIT · ANY KEY SKIPS"}
              </p>
            )}
          </div>
        </div>
      )}

      {/* objective */}
      {showChrome && objective && (
        <div className="absolute left-4 top-4 z-30 flex max-w-[70vw] items-center gap-3 rounded-2xl glass-panel px-4 py-2.5">
          <Compass size={16} className="shrink-0 text-ember" />
          <div>
            <p className="font-mono text-[9px] tracking-[0.3em] text-moss/70">
              {region === "root" ? "02 · THE HOLLOW ROOT" : "01 · THE FALLEN GARDEN"}
            </p>
            <p className="text-[13px] font-medium text-mist">{objective}</p>
          </div>
        </div>
      )}

      {/* verbs */}
      {showChrome && (
        <div className="absolute right-4 top-4 z-30 flex items-center gap-2 pointer-events-auto">
          <IconButton
            label="Hint (H)"
            pulse={!!hintText}
            onClick={() => showHint()}
          >
            <Lightbulb size={17} />
          </IconButton>
          <IconButton label="Controls (C)" onClick={() => useGame.getState().setPanel("controls")}>
            <Gamepad2 size={17} />
          </IconButton>
          <IconButton label="Journal (J)" onClick={() => useGame.getState().setPanel("journal")}>
            <BookOpenText size={17} />
          </IconButton>
          <IconButton label="Map (M)" onClick={() => useGame.getState().setPanel("map")}>
            <MapIcon size={17} />
          </IconButton>
          <IconButton
            label={settings.muted ? "Unmute" : "Mute"}
            onClick={() => useGame.getState().updateSettings({ muted: !settings.muted })}
          >
            {settings.muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
          </IconButton>
          <IconButton label="Settings (Esc)" onClick={() => useGame.getState().setPanel("settings")}>
            <Settings size={17} />
          </IconButton>
        </div>
      )}

      {/* hint pill */}
      {hintText && showChrome && (
        <div className="absolute bottom-24 left-4 z-30 flex max-w-sm items-start gap-3 rounded-2xl rounded-bl-sm glass-panel px-4 py-3 animate-rise">
          <Lightbulb size={16} className="mt-0.5 shrink-0 text-ember" />
          <p className="text-[13px] leading-relaxed text-mist/95">{hintText}</p>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div
          key={toast.id}
          className="absolute left-1/2 top-16 z-40 w-[min(92vw,26rem)] -translate-x-1/2 rounded-2xl glass-panel px-5 py-4 text-center animate-rise"
        >
          <div className="flex items-center justify-center gap-2 text-ember">
            <Sparkles size={15} />
            <p className="font-display text-lg italic text-[#f6e8cf]">{toast.title}</p>
          </div>
          <p className="mt-1 text-xs text-mist/75">{toast.text}</p>
        </div>
      )}

      {/* interact prompt */}
      {showChrome && target && (
        <div className="absolute bottom-[9vh] left-1/2 z-30 -translate-x-1/2 animate-rise">
          <div className="flex items-center gap-3 rounded-full glass-panel py-2 pl-3 pr-5">
            {!touchMode && <span className="key-chip">E</span>}
            <span className="text-sm text-mist">{target.label}</span>
          </div>
        </div>
      )}

      {/* (touch interaction lives in TouchControls' action cluster) */}

      {/* subtitle rail */}
      {settings.subtitles && subtitle && (
        <div className="absolute bottom-[2.2vh] left-1/2 z-30 w-[min(92vw,40rem)] -translate-x-1/2 text-center">
          <p
            className={`inline-block rounded-xl px-5 py-2 italic leading-snug ${SUB_SIZE[settings.textSize]} ${
              settings.colorblindSub
                ? "bg-black/90 text-white"
                : "bg-black/45 text-[#eaf4e6] backdrop-blur-sm"
            }`}
          >
            <span className="not-italic font-mono text-[10px] tracking-[0.25em] text-moss/80 uppercase">
              {subtitle.who}{"   "}
            </span>
            {subtitle.text}
          </p>
        </div>
      )}

      {/* movement legend */}
      {showChrome && !touchMode && (
        <div className="absolute bottom-4 left-4 z-30 hidden flex-wrap gap-x-3 gap-y-1 font-mono text-[10px] tracking-wider text-mist/35 md:flex">
          <span>WASD move</span>
          <span>⇧ run</span>
          <span>SPACE hop</span>
          <span>E interact</span>
          <span>↔ arrows camera</span>
          <span>F recenter</span>
          <span>C controls</span>
        </div>
      )}

      {/* epilogue card */}
      {phase === "epilogue" && !epilogueDismissed && (
        <div className="absolute inset-0 z-40 grid place-items-center bg-black/40 p-4 pointer-events-auto">
          <div className="w-[min(94vw,30rem)] rounded-3xl glass-panel p-8 text-center animate-rise noise-veil relative overflow-hidden">
            <Sprout size={26} className="mx-auto text-ember" />
            <h2 className="mt-4 font-display text-3xl font-light italic text-[#f6e8cf]">
              {region === "root" ? "The Rootway Breathes Back" : "The First Light Returns"}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-mist/80">
              {region === "root"
                ? "The Rootheart burns in the dark — two lamps of twelve, humming in harmony now. Home is one turn of the ring behind you."
                : "The Bloomheart burns again — one lamp of twelve. In the northwest, a Rootway ring has woken, thirsty for the dark below."}
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3 text-left">
              <div className="rounded-xl hairline px-4 py-3">
                <p className="font-mono text-[10px] tracking-widest text-moss/70">MEMORIES</p>
                <p className="mt-1 font-display text-2xl text-ember">{memories.length} / 7</p>
              </div>
              <div className="rounded-xl hairline px-4 py-3">
                <p className="font-mono text-[10px] tracking-widest text-moss/70">CREATURES MET</p>
                <p className="mt-1 font-display text-2xl text-ember">{creatures.length} / 22</p>
              </div>
            </div>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              {region === "garden" && rootUnlocked && (
                <button
                  onClick={() => {
                    setEpilogueDismissed(true);
                    useGame.getState().setTravelingTo("root");
                  }}
                  className="rounded-full bg-ember px-5 py-2 text-sm font-bold text-[#241708] transition hover:bg-ember-deep"
                >
                  Enter the Hollow Root →
                </button>
              )}
              {region === "root" && (
                <button
                  onClick={() => {
                    setEpilogueDismissed(true);
                    useGame.getState().setTravelingTo("garden");
                  }}
                  className="rounded-full bg-ember px-5 py-2 text-sm font-bold text-[#241708] transition hover:bg-ember-deep"
                >
                  Return to the Fallen Garden →
                </button>
              )}
              <button
                onClick={() => setEpilogueDismissed(true)}
                className="rounded-full hairline px-4 py-2 text-sm text-mist/85 transition hover:border-ember/40"
              >
                Keep exploring
              </button>
              <button
                onClick={() => useGame.getState().resetRun()}
                className="flex items-center gap-2 rounded-full hairline px-4 py-2 text-sm text-mist/85 transition hover:border-ember/40"
              >
                <RotateCcw size={14} /> Restart chapter
              </button>
              <button
                onClick={onOpenDoc}
                className="flex items-center gap-2 rounded-full hairline px-4 py-2 text-sm text-mist/85 transition hover:border-ember/40"
              >
                <ScrollText size={14} /> Design document
              </button>
            </div>
            <p className="mt-5 font-mono text-[10px] tracking-[0.25em] text-mist/35">
              PHASE 2 PROTOTYPE · BUILD 0.2 · ROOTWAY NETWORK ONLINE
            </p>
          </div>
        </div>
      )}

      {/* Rootway travel fade */}
      <div
        className={`pointer-events-none absolute inset-0 z-[60] grid place-items-center bg-black transition-opacity duration-500 ${
          travelingTo ? "opacity-100" : "opacity-0"
        }`}
      >
        {travelingTo && (
          <p className="animate-pulse-soft font-mono text-[11px] tracking-[0.5em] text-moss/80">
            THE ROOTWAY TURNS…
          </p>
        )}
      </div>
    </div>
  );
}
