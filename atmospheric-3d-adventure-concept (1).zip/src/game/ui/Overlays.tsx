/**
 * Overlays.tsx — pause-layer panels: Settings (graphics + accessibility),
 * Map (the 12-region Wildland, with the prototype region live) and the
 * Journal (memories + creature observations). All read/write the persisted
 * store, so choices survive reloads.
 */
import { useState } from "react";
import {
  BookOpenText,
  Bug,
  Gem,
  Keyboard,
  Leaf,
  Lock,
  MapPin,
  Smartphone,
  Sparkles,
  Volume2,
  X,
} from "lucide-react";
import { useGame, type Settings } from "../store";
import { CREATURES, REGIONS } from "../../data/gdd";
import { CONTROL_TIPS, DESKTOP_CONTROLS, MOBILE_CONTROLS } from "../controls";

function Shell({
  title,
  children,
  wide = false,
}: {
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="pointer-events-auto absolute inset-0 z-50 grid place-items-center bg-black/55 p-4 backdrop-blur-sm animate-fade-soft">
      <div
        className={`wild-scroll relative max-h-[86vh] overflow-y-auto rounded-3xl glass-panel p-6 md:p-8 ${
          wide ? "w-[min(94vw,44rem)]" : "w-[min(94vw,26rem)]"
        }`}
      >
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-2xl font-light italic text-[#f6e8cf]">{title}</h2>
          <button
            onClick={() => useGame.getState().setPanel("none")}
            aria-label="Close"
            className="grid h-9 w-9 place-items-center rounded-full hairline text-mist/80 transition hover:border-ember/50 hover:text-ember"
          >
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Toggle({
  label,
  hint,
  value,
  onChange,
}: {
  label: string;
  hint: string;
  value: boolean;
  onChange: (b: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="flex w-full items-center justify-between gap-4 rounded-xl hairline px-4 py-3 text-left transition hover:border-moss/40"
    >
      <span>
        <span className="block text-sm text-mist">{label}</span>
        <span className="block text-[11px] text-mist/50">{hint}</span>
      </span>
      <span
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${value ? "bg-ember/80" : "bg-white/10"}`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${value ? "left-[1.4rem]" : "left-0.5"}`}
        />
      </span>
    </button>
  );
}

function SettingsPanel() {
  const settings = useGame((s) => s.settings);
  const update = useGame((s) => s.updateSettings);
  const patch = (p: Partial<Settings>) => update(p);

  return (
    <Shell title="Settings">
      <p className="mb-2 font-mono text-[10px] tracking-[0.3em] text-moss/70">GRAPHICS QUALITY</p>
      <div className="mb-6 grid grid-cols-3 gap-2">
        {(
          [
            { q: "low", label: "Sprout", icon: Leaf, hint: "30 fps · battery" },
            { q: "medium", label: "Fern", icon: Gem, hint: "balanced" },
            { q: "high", label: "Bloom", icon: Sparkles, hint: "60 fps · PC" },
          ] as const
        ).map(({ q, label, icon: Icon, hint }) => (
          <button
            key={q}
            onClick={() => patch({ quality: q })}
            className={`rounded-xl px-3 py-3 text-center transition ${
              settings.quality === q
                ? "bg-ember/15 border border-ember/50 text-ember"
                : "hairline text-mist/70 hover:border-moss/40"
            }`}
          >
            <Icon size={17} className="mx-auto" />
            <span className="mt-1 block text-xs font-semibold">{label}</span>
            <span className="block text-[10px] opacity-60">{hint}</span>
          </button>
        ))}
      </div>

      <p className="mb-2 font-mono text-[10px] tracking-[0.3em] text-moss/70">AUDIO</p>
      <div className="mb-6 flex items-center gap-3 rounded-xl hairline px-4 py-3">
        <Volume2 size={16} className="text-mist/70" />
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={settings.volume}
          onChange={(e) => patch({ volume: Number(e.target.value), muted: Number(e.target.value) === 0 ? true : false })}
          className="w-full accent-[#f2b15e]"
          aria-label="Master volume"
        />
        <span className="w-10 text-right font-mono text-xs text-mist/60">
          {Math.round(settings.volume * 100)}%
        </span>
      </div>

      <p className="mb-2 font-mono text-[10px] tracking-[0.3em] text-moss/70">ACCESSIBILITY</p>
      <div className="space-y-2">
        <Toggle
          label="Subtitles"
          hint="Creature sounds and whispers as text"
          value={settings.subtitles}
          onChange={(b) => patch({ subtitles: b })}
        />
        <Toggle
          label="High-contrast subtitles"
          hint="Solid background, bright text (colorblind-safe)"
          value={settings.colorblindSub}
          onChange={(b) => patch({ colorblindSub: b })}
        />
        <Toggle
          label="Reduced motion"
          hint="Skips camera swoops, sway and shake"
          value={settings.reducedMotion}
          onChange={(b) => patch({ reducedMotion: b })}
        />
      </div>

      <p className="mb-2 mt-6 font-mono text-[10px] tracking-[0.3em] text-moss/70">SUBTITLE SIZE</p>
      <div className="grid grid-cols-3 gap-2">
        {([0, 1, 2] as const).map((v) => (
          <button
            key={v}
            onClick={() => patch({ textSize: v })}
            className={`rounded-xl py-2.5 transition ${
              settings.textSize === v ? "bg-ember/15 border border-ember/50 text-ember" : "hairline text-mist/70"
            } ${v === 0 ? "text-xs" : v === 1 ? "text-sm" : "text-base"}`}
          >
            {v === 0 ? "Small" : v === 1 ? "Medium" : "Large"}
          </button>
        ))}
      </div>
      <button
        onClick={() => useGame.getState().setPanel("controls")}
        className="mt-6 w-full rounded-xl hairline py-2.5 text-[12px] text-mist/75 transition hover:border-ember/40 hover:text-ember"
      >
        Controls & camera options →
      </button>
      <p className="mt-4 text-center text-[11px] text-mist/40">
        Every setting is saved to this device automatically.
      </p>
    </Shell>
  );
}

function ControlsPanel() {
  const settings = useGame((s) => s.settings);
  const touchMode = useGame((s) => s.touchMode);
  const update = useGame((s) => s.updateSettings);
  const [tab, setTab] = useState<"desktop" | "mobile">(touchMode ? "mobile" : "desktop");
  const rows = tab === "mobile" ? MOBILE_CONTROLS : DESKTOP_CONTROLS;

  return (
    <Shell title="Controls" wide>
      <div className="mb-4 grid grid-cols-2 gap-2">
        {(
          [
            { id: "desktop", label: "Keyboard & Mouse", icon: Keyboard },
            { id: "mobile", label: "Touch", icon: Smartphone },
          ] as const
        ).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm transition ${
              tab === id ? "bg-ember/15 border border-ember/50 text-ember" : "hairline text-mist/70"
            }`}
          >
            <Icon size={15} />
            {label}
          </button>
        ))}
      </div>

      <div className="grid gap-1.5 md:grid-cols-2">
        {rows.map((r) => (
          <div key={r.action} className="flex items-center gap-3 rounded-xl hairline px-3 py-2">
            <div className="flex w-28 shrink-0 flex-wrap gap-1">
              {r.keys.map((k) => (
                <span key={k} className="key-chip">
                  {k}
                </span>
              ))}
            </div>
            <div className="min-w-0">
              <p className="text-[13px] font-medium leading-tight text-mist">{r.action}</p>
              {r.note && <p className="text-[11px] leading-tight text-mist/45">{r.note}</p>}
            </div>
          </div>
        ))}
      </div>

      <p className="mb-2 mt-6 font-mono text-[10px] tracking-[0.3em] text-moss/70">CAMERA</p>
      <div className="mb-2 flex items-center gap-3 rounded-xl hairline px-4 py-3">
        <span className="w-24 shrink-0 text-[12px] text-mist/70">Sensitivity</span>
        <input
          type="range"
          min={0.5}
          max={2}
          step={0.05}
          value={settings.camSensitivity}
          onChange={(e) => update({ camSensitivity: Number(e.target.value) })}
          className="w-full accent-[#f2b15e]"
          aria-label="Camera sensitivity"
        />
        <span className="w-10 text-right font-mono text-xs text-mist/60">
          {settings.camSensitivity.toFixed(2)}×
        </span>
      </div>
      <div className="space-y-2">
        <Toggle
          label="Invert vertical look"
          hint="Drag or arrow-key pitch is flipped"
          value={settings.invertY}
          onChange={(b) => update({ invertY: b })}
        />
        <Toggle
          label="Left-handed touch layout"
          hint="Swaps the stick and the action buttons"
          value={settings.leftHanded}
          onChange={(b) => update({ leftHanded: b })}
        />
        <Toggle
          label="Run latch (touch)"
          hint="Run without pushing the stick to its edge"
          value={settings.runToggle}
          onChange={(b) => update({ runToggle: b })}
        />
      </div>

      <ul className="mt-5 space-y-1">
        {CONTROL_TIPS.map((t) => (
          <li key={t} className="flex gap-2 text-[11.5px] leading-relaxed text-mist/55">
            <Sparkles size={11} className="mt-1 shrink-0 text-moss" />
            {t}
          </li>
        ))}
      </ul>

      <button
        onClick={() => {
          useGame.getState().updateSettings({ seenControls: false });
          useGame.getState().setPanel("none");
        }}
        className="mt-5 w-full rounded-xl hairline py-2.5 text-[12px] text-mist/70 transition hover:border-ember/40 hover:text-ember"
      >
        Show the intro note again
      </button>
    </Shell>
  );
}

function MapPanel() {
  const region = useGame((s) => s.region);
  const unlocked = useGame((s) => s.unlocked);
  const completed = useGame((s) => s.completed);
  const order = [
    "fallen-garden", "hollow-root", "rain-chamber", "mushroom-valley",
    "forgotten-workshop", "glass-stream", "sleeping-tree", "insect-cathedral",
    "underground-nest", "mirror-pond", "storm-canopy", "the-heartwood",
  ];
  const pts = order.map((id) => REGIONS.find((r) => r.id === id)!);
  const path = pts.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`).join(" ");
  // gdd region id → prototype region id
  const toStoreId: Record<string, string> = {
    "fallen-garden": "garden",
    "hollow-root": "root",
  };
  const here = region === "root" ? REGIONS.find((r) => r.id === "hollow-root")! : REGIONS[0];
  return (
    <Shell title="The Wildland" wide>
      <svg viewBox="0 0 100 96" className="w-full">
        <defs>
          <radialGradient id="mapglow" cx="50%" cy="50%" r="60%">
            <stop offset="0%" stopColor="#22381f" />
            <stop offset="100%" stopColor="#0b140d" />
          </radialGradient>
        </defs>
        <rect x="0" y="0" width="100" height="96" rx="6" fill="url(#mapglow)" />
        <path d={path} fill="none" stroke="#6f9a6d" strokeOpacity="0.25" strokeWidth="0.5" strokeDasharray="1.4 1.6" />
        {pts.map((r) => {
          const sid = toStoreId[r.id];
          const isCurrent = sid === region;
          const isUnlocked = sid ? unlocked.includes(sid as never) || completed.includes(sid) : false;
          const isComplete = sid ? completed.includes(sid) : false;
          const lit = isCurrent || isUnlocked || isComplete;
          return (
            <g key={r.id}>
              <circle
                cx={r.x}
                cy={r.y}
                r={isCurrent ? 3 : 1.7}
                fill={isCurrent ? "#f2b15e" : isComplete ? "#6f9a6d" : isUnlocked ? "#16281a" : "#0b140d"}
                stroke={isCurrent ? "#ffdf9e" : "#6f9a6d"}
                strokeWidth="0.5"
                opacity={lit ? 1 : 0.7}
              />
              {isCurrent && (
                <circle cx={r.x} cy={r.y} r="5" fill="none" stroke="#f2b15e" strokeWidth="0.35" opacity="0.6">
                  <animate attributeName="r" values="3.4;6;3.4" dur="2.4s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.7;0;0.7" dur="2.4s" repeatCount="indefinite" />
                </circle>
              )}
              <text
                x={r.x}
                y={r.y + (isCurrent ? -4.6 : 4.4)}
                textAnchor="middle"
                fontSize={isCurrent ? 3 : 2.4}
                fill={isCurrent ? "#ffdf9e" : "#a8c69a"}
                opacity={lit ? 0.95 : 0.5}
                fontFamily="IBM Plex Mono, monospace"
                letterSpacing="0.08em"
              >
                {r.name.toUpperCase()}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-4 flex items-center gap-3 rounded-xl hairline px-4 py-3">
        <MapPin size={15} className="shrink-0 text-ember" />
        <p className="text-xs leading-relaxed text-mist/75">
          <span className="text-ember">You are here</span> — {here.name}.
          {unlocked.includes("root")
            ? " The Rootway hums between the Fallen Garden and the Hollow Root. Ten regions remain dim."
            : " Eleven regions of the Wildland remain dim, waiting for their share of Heartlight."}
        </p>
      </div>
      <div className="mt-3 flex items-center gap-3 px-1 text-[11px] text-mist/45">
        <Lock size={12} />
        <span>Regions unlock as their lamps are re-lit — travel is by Rootway ring.</span>
      </div>
    </Shell>
  );
}

function JournalPanel() {
  const memories = useGame((s) => s.memories);
  const creatures = useGame((s) => s.creatures);
  const [tab, setTab] = useState<"memories" | "creatures">("memories");
  return (
    <Shell title="Journal" wide>
      <div className="mb-4 grid grid-cols-2 gap-2">
        {(
          [
            { id: "memories", label: `Memories · ${memories.length}`, icon: BookOpenText },
            { id: "creatures", label: `Creatures · ${creatures.length}`, icon: Bug },
          ] as const
        ).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm transition ${
              tab === id ? "bg-ember/15 border border-ember/50 text-ember" : "hairline text-mist/70"
            }`}
          >
            <Icon size={15} />
            {label}
          </button>
        ))}
      </div>

      {tab === "memories" &&
        (memories.length === 0 ? (
          <Empty text="No memories yet — glowing motes hold them. Wander gently." />
        ) : (
          <div className="space-y-3">
            {memories.map((m) => (
              <div key={m.id} className="rounded-2xl hairline px-5 py-4">
                <p className="font-display text-lg italic text-ember">{m.title}</p>
                <p className="mt-1.5 text-sm leading-relaxed text-mist/85">{m.text}</p>
              </div>
            ))}
          </div>
        ))}

      {tab === "creatures" &&
        (creatures.length === 0 ? (
          <Empty text="No creatures observed yet. Approach slowly; watch before touching." />
        ) : (
          <div className="space-y-3">
            {creatures.map((name) => {
              const c = CREATURES.find((k) => k.name === name);
              return (
                <div key={name} className="rounded-2xl hairline px-5 py-4">
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="font-display text-lg italic text-lume">{name}</p>
                    {c && <p className="font-mono text-[10px] tracking-widest text-moss/70">{c.kind.toUpperCase()}</p>}
                  </div>
                  {c && (
                    <p className="mt-1.5 text-sm leading-relaxed text-mist/85">
                      {c.personality}. Speaks in {c.sound}.{" "}
                      <span className="text-mist/60">{c.signature}.</span>
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        ))}
    </Shell>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-mist/15 px-5 py-8 text-center">
      <p className="text-sm italic text-mist/45">{text}</p>
    </div>
  );
}

export default function Overlays() {
  const panel = useGame((s) => s.panel);
  if (panel === "none") return null;
  if (panel === "settings") return <SettingsPanel />;
  if (panel === "controls") return <ControlsPanel />;
  if (panel === "map") return <MapPanel />;
  return <JournalPanel />;
}
