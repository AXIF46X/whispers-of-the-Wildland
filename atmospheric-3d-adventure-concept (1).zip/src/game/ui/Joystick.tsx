/**
 * Joystick.tsx — virtual movement stick. Writes into the shared input bus,
 * so the player controller treats it exactly like keyboard input.
 * Magnitude is analog: a gentle tilt tiptoes, a full push runs (unless the
 * run latch is engaged, in which case the stick always runs).
 */
import { useRef, useState } from "react";
import { setTouchVector } from "../input";
import { useGame } from "../store";

const RADIUS = 46;

export default function Joystick({ side, runLatched }: { side: "left" | "right"; runLatched: boolean }) {
  const [knob, setKnob] = useState({ x: 0, y: 0, active: false });
  const origin = useRef<{ x: number; y: number } | null>(null);
  const pid = useRef<number | null>(null);
  const reduced = useGame((s) => s.settings.reducedMotion);

  const apply = (dx: number, dy: number, active: boolean) => {
    const len = Math.hypot(dx, dy);
    const clamped = Math.min(len, RADIUS);
    const nx = len > 0 ? (dx / len) * (clamped / RADIUS) : 0;
    const ny = len > 0 ? (dy / len) * (clamped / RADIUS) : 0;
    setKnob({ x: nx * RADIUS, y: ny * RADIUS, active });
    setTouchVector(nx, -ny, active, runLatched || Math.hypot(nx, ny) > 0.92);
  };

  return (
    <div
      className={`pointer-events-auto absolute bottom-[13vh] z-30 grid h-32 w-32 touch-none place-items-center rounded-full glass-panel ${
        side === "left" ? "left-5" : "right-5"
      }`}
      onPointerDown={(e) => {
        pid.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        const r = e.currentTarget.getBoundingClientRect();
        origin.current = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
        apply(e.clientX - origin.current.x, e.clientY - origin.current.y, true);
      }}
      onPointerMove={(e) => {
        if (pid.current !== e.pointerId || !origin.current) return;
        apply(e.clientX - origin.current.x, e.clientY - origin.current.y, true);
      }}
      onPointerUp={(e) => {
        if (pid.current !== e.pointerId) return;
        pid.current = null;
        origin.current = null;
        apply(0, 0, false);
      }}
      onPointerCancel={(e) => {
        if (pid.current !== e.pointerId) return;
        pid.current = null;
        origin.current = null;
        apply(0, 0, false);
      }}
    >
      <div className="absolute inset-2.5 rounded-full border border-mist/10" />
      <span className="pointer-events-none absolute top-2.5 font-mono text-[8px] tracking-[0.25em] text-mist/30">
        MOVE
      </span>
      <div
        className={`grid h-14 w-14 place-items-center rounded-full border transition-colors ${
          knob.active
            ? "bg-ember/30 border-ember/60"
            : `bg-moss/20 border-moss/40 ${reduced ? "" : "animate-pulse-soft"}`
        }`}
        style={{ transform: `translate(${knob.x}px, ${knob.y}px)` }}
      >
        <div className="h-2.5 w-2.5 rounded-full bg-mist/80" />
      </div>
    </div>
  );
}
