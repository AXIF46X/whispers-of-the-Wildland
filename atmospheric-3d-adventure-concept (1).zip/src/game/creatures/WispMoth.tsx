/**
 * WispMoth.tsx — "Lume", the player's companion creature (original design).
 *
 * A mote of condensed twilight wrapped in petal-wings. Communicates in an
 * invented three-call dialect (call / point / joy) through synthesized
 * chirps, expanding sound-rings, and body language — it leads, waits,
 * gestures toward the interactive clue, and celebrates discoveries.
 *
 * Behaviour model: tiny adaptive FSM (lead → hover/guide → celebrate) with
 * a player-distance leash, waypoint hand-off, and periodic "pointing darts"
 * at the next actionable object.
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { MOTH_WAYPOINTS, PRISMS, FLOWER, SPAWN } from "../layout";
import { terrainHeight } from "../terrain";
import { RT } from "../runtime";
import { audio } from "../audio";
import { useGame } from "../store";
import { makeGlowTexture, makeWingTexture } from "../world/textures";

type Mode = "lead" | "hover" | "celebrate";

const CALLS = ["*tk-tk… prruu!*", "*chirr-ip! ip!*", "*wheee-tik-tik*", "*prrOO-ka?*"];

export default function WispMoth() {
  const group = useRef<THREE.Group>(null!);
  const wingL = useRef<THREE.Mesh>(null!);
  const wingR = useRef<THREE.Mesh>(null!);
  const rings = useRef<THREE.Mesh[]>([]);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const wingTex = useMemo(() => makeWingTexture(), []);
  const quality = useGame((s) => s.settings.quality);

  const mode = useRef<Mode>("lead");
  const wpIdx = useRef(0);
  const celebrateT = useRef(0);
  const dartT = useRef(4);
  const chirpT = useRef(2.5);
  const yaw = useRef(0);
  const prevBloom = useRef(0);
  const ringAnims = useRef<{ t: number }[]>([{ t: 9 }, { t: 9 }, { t: 9 }]);
  const saidHello = useRef(false);

  const tmp = useMemo(() => ({ target: new THREE.Vector3(), v: new THREE.Vector3(), flower: new THREE.Vector3() }), []);

  /* register as an interactable — Milo can "call" the Lume */
  useEffect(() => {
    const reg = {
      id: "lume",
      label: "Call the Lume",
      radius: 2.4,
      enabled: true,
      getPos: () => ({ x: group.current.position.x, y: group.current.position.y, z: group.current.position.z }),
      action: () => {
        audio.chirp("call");
        emitRing();
        const s = useGame.getState();
        s.say("Lume", CALLS[Math.floor(Math.random() * CALLS.length)]);
        s.observeCreature("Lume, the Gardener-Moth");
      },
    };
    useGame.getState().registerInteractable(reg);
    return () => useGame.getState().unregisterInteractable("lume");
  }, []);

  const emitRing = () => {
    const slot = ringAnims.current.reduce((a, b, i, arr) => (b.t > arr[a].t ? i : a), 0);
    ringAnims.current[slot].t = 0;
  };

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const t = state.clock.elapsedTime;
    const gs = useGame.getState();
    const p = group.current.position;

    /* ---------- mode selection ---------- */
    if (gs.bloomAt > 0 && prevBloom.current === 0) {
      mode.current = "celebrate";
      celebrateT.current = 0;
      audio.chirp("joy");
      emitRing();
      tmp.flower.set(FLOWER.pos[0], terrainHeight(FLOWER.pos[0], FLOWER.pos[1]), FLOWER.pos[1]);
    }
    prevBloom.current = gs.bloomAt;

    const playerDist = Math.hypot(RT.playerPos.x - p.x, RT.playerPos.z - p.z);

    if (mode.current === "lead") {
      const wp = MOTH_WAYPOINTS[wpIdx.current];
      const wpY = terrainHeight(wp[0], wp[1]) + 1.5;
      const playerToWp = Math.hypot(RT.playerPos.x - wp[0], RT.playerPos.z - wp[1]);
      if (playerToWp < 2.6) {
        wpIdx.current++;
        gs.markProgress();
        gs.observeCreature("Lume, the Gardener-Moth");
        audio.chirp("call");
        emitRing();
        gs.say("Lume", CALLS[wpIdx.current % CALLS.length]);
        if (wpIdx.current >= MOTH_WAYPOINTS.length) {
          mode.current = "hover";
          gs.setObjective("Guide the sunbeam to the Bloomheart");
          audio.chirp("point");
        }
      }
      if (playerDist > 6.5) {
        // leash: hurry back to the player
        tmp.target.set(RT.playerPos.x - 1, RT.playerPos.y + 1.4, RT.playerPos.z - 1);
      } else {
        tmp.target.set(wp[0], wpY + Math.sin(t * 1.7) * 0.25, wp[1]);
      }
    } else if (mode.current === "hover") {
      // orbit the shard garden, periodically dart at the next unsolved prism
      dartT.current -= dt;
      const next = PRISMS.findIndex((pr, i) => gs.prisms[i] !== pr.correct);
      if (dartT.current <= 0 && next >= 0) {
        dartT.current = 6 + Math.random() * 4;
        audio.chirp("point");
        emitRing();
        dartTarget.current = next;
      }
      if (dartTarget.current >= 0) {
        const pr = PRISMS[dartTarget.current];
        const py = terrainHeight(pr.pos[0], pr.pos[1]) + 2.2;
        tmp.target.set(pr.pos[0], py + Math.sin(t * 6) * 0.12, pr.pos[1]);
        dartHold.current += dt;
        if (dartHold.current > 1.6) {
          dartTarget.current = -1;
          dartHold.current = 0;
        }
      } else {
        const a = t * 0.5;
        tmp.target.set(-6 + Math.cos(a) * 2.2, terrainHeight(-6, 0) + 2 + Math.sin(t * 1.9) * 0.3, 0.5 + Math.sin(a) * 2.6);
      }
    } else {
      // celebrate
      celebrateT.current += dt;
      const a = t * (celebrateT.current < 7 ? 2.6 : 0.7);
      const r = celebrateT.current < 7 ? 1.8 : 2.6;
      tmp.target.set(
        tmp.flower.x + Math.cos(a) * r,
        tmp.flower.y + 3.6 + Math.sin(t * 2.2) * 0.5,
        tmp.flower.z + Math.sin(a) * r
      );
    }

    /* ---------- steering ---------- */
    const urgency = mode.current === "lead" && playerDist > 6.5 ? 3.2 : 1.9;
    const k = 1 - Math.exp(-urgency * dt);
    p.lerp(tmp.target, k);

    // face travel direction
    tmp.v.copy(tmp.target).sub(p);
    if (tmp.v.lengthSq() > 0.001) {
      const targetYaw = Math.atan2(tmp.v.x, tmp.v.z);
      let diff = targetYaw - yaw.current;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      yaw.current += diff * (1 - Math.exp(-6 * dt));
      group.current.rotation.y = yaw.current;
      group.current.rotation.z = THREE.MathUtils.damp(group.current.rotation.z, -diff * 0.4, 4, dt);
    }

    /* ---------- wings + body ---------- */
    const flap = Math.sin(t * (16 + urgency));
    wingL.current.rotation.y = 0.45 + flap * 0.75;
    wingR.current.rotation.y = -0.45 - flap * 0.75;
    group.current.position.y += Math.sin(t * 7) * 0.004;

    /* ---------- ambient chirping ---------- */
    chirpT.current -= dt;
    if (chirpT.current <= 0) {
      chirpT.current = 7 + Math.random() * 8;
      audio.chirp("call");
      emitRing();
      if (!saidHello.current && gs.phase === "explore") {
        saidHello.current = true;
        gs.say("Lume", "*tk-tk… prruu!*");
        gs.observeCreature("Lume, the Gardener-Moth");
      }
    }

    /* ---------- sound ring animation ---------- */
    ringAnims.current.forEach((ra, i) => {
      const m = rings.current[i];
      if (!m) return;
      ra.t += dt;
      const life = 1.4;
      const s = 1 + ra.t * 2.6;
      m.scale.setScalar(s);
      m.position.copy(p);
      (m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.55 * (1 - ra.t / life));
    });
  });

  const dartTarget = useRef(-1);
  const dartHold = useRef(0);

  return (
    <group>
      <group ref={group} position={[SPAWN[0] + 1.6, terrainHeight(SPAWN[0], SPAWN[1]) + 1.6, SPAWN[1] - 1.2]}>
        {/* body — condensed twilight mote */}
        <mesh>
          <sphereGeometry args={[0.11, 14, 12]} />
          <meshPhongMaterial color="#cfeeff" emissive="#9fd8ff" emissiveIntensity={0.9} transparent opacity={0.9} />
        </mesh>
        <sprite scale={[0.85, 0.85, 1]}>
          <spriteMaterial map={glowTex} color="#a8dcff" transparent opacity={0.75} depthWrite={false} />
        </sprite>
        {quality === "high" && <pointLight color="#9fd8ff" intensity={1.4} distance={3.4} decay={2} />}
        {/* wings */}
        <mesh ref={wingL} position={[0.06, 0.05, 0]}>
          <planeGeometry args={[0.34, 0.4]} />
          <meshPhongMaterial map={wingTex} transparent alphaTest={0.05} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        <mesh ref={wingR} position={[-0.06, 0.05, 0]}>
          <planeGeometry args={[0.34, 0.4]} />
          <meshPhongMaterial map={wingTex} transparent alphaTest={0.05} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        {/* antennae */}
        <mesh position={[0.03, 0.12, 0.06]} rotation={[0.5, 0, -0.3]}>
          <cylinderGeometry args={[0.004, 0.004, 0.14, 4]} />
          <meshBasicMaterial color="#cfeeff" />
        </mesh>
        <mesh position={[-0.03, 0.12, 0.06]} rotation={[0.5, 0, 0.3]}>
          <cylinderGeometry args={[0.004, 0.004, 0.14, 4]} />
          <meshBasicMaterial color="#cfeeff" />
        </mesh>
      </group>
      {/* expanding sound rings */}
      {[0, 1, 2].map((i) => (
        <mesh
          key={i}
          ref={(el) => {
            if (el) rings.current[i] = el;
          }}
          rotation={[Math.PI / 2, 0, 0]}
        >
          <torusGeometry args={[0.3, 0.012, 6, 32]} />
          <meshBasicMaterial color="#a8dcff" transparent opacity={0} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}
