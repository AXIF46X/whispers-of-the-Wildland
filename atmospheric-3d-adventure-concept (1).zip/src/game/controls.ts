/**
 * controls.ts — single source of truth for the control schemes, shared by
 * the intro note, the Controls reference panel and the HUD legend.
 */

export interface ControlRow {
  keys: string[];
  action: string;
  note?: string;
}

export const DESKTOP_CONTROLS: ControlRow[] = [
  { keys: ["W", "A", "S", "D"], action: "Walk", note: "Milo moves relative to the camera" },
  { keys: ["Shift"], action: "Run", note: "Hold while walking" },
  { keys: ["Space"], action: "Hop", note: "Short spring over roots and gaps" },
  { keys: ["E"], action: "Interact", note: "Rings, bells, shards, creatures, portals" },
  { keys: ["Drag"], action: "Orbit camera", note: "Left-drag anywhere in the world" },
  { keys: ["←", "→", "↑", "↓"], action: "Turn camera", note: "Keyboard orbit & pitch" },
  { keys: ["Wheel", "−", "+"], action: "Zoom", note: "Push in for macro close-ups" },
  { keys: ["F"], action: "Recenter camera", note: "Snaps behind Milo" },
  { keys: ["H"], action: "Hint", note: "Only nudges, never solves" },
  { keys: ["J"], action: "Journal" },
  { keys: ["M"], action: "Map" },
  { keys: ["C"], action: "Controls" },
  { keys: ["Esc"], action: "Settings / close" },
];

export const MOBILE_CONTROLS: ControlRow[] = [
  { keys: ["Joystick"], action: "Walk & run", note: "Push further to break into a run" },
  { keys: ["Tap ✋"], action: "Interact", note: "The button appears when something is near" },
  { keys: ["Tap ⤒"], action: "Hop", note: "Short spring" },
  { keys: ["Drag"], action: "Orbit camera", note: "Drag anywhere on the world" },
  { keys: ["Pinch"], action: "Zoom", note: "Or use the ± buttons" },
  { keys: ["Tap ⊙"], action: "Recenter camera" },
  { keys: ["Tap objects"], action: "Direct interact", note: "Bells, shards and motes respond to taps" },
  { keys: ["Top bar"], action: "Hint · Journal · Map · Sound · Settings" },
];

export const CONTROL_TIPS = [
  "Nothing in the Wildland can hurt Milo — explore at your own pace.",
  "Creatures answer to attention: stand near them and interact.",
  "If you stall for a while, the hint lantern lights itself.",
];
