/**
 * SunbeamPuzzle.tsx — "Staircase of Light" (prototype puzzle 01).
 *
 * An ancient brass-arch catches the garden's last sunbeam. Three shard-stones
 * each rotate in 45° steps; correct diagonal orientations ricochet the beam
 * around the garden — east, north, west, north — into the sleeping
 * Bloomheart's bud.
 *
 * Design notes (per GDD): clues are diegetic — the Lume darts at the next
 * unsolved shard, the beam is always visible so cause/effect is immediate,
 * and there are exactly 4^3 states, searchable by observation, not luck.
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { FLOWER, PRISMS, SOURCE, WORLD } from "../layout";
import { terrainHeight } from "../terrain";
import { RT } from "../runtime";
import { audio } from "../audio";
import { useGame } from "../store";
import { makeGlowTexture, makeShaftTexture } from "../world/textures";

const UP = new THREE.Vector3(0, 1, 0);

interface BeamSegment {
  a: THREE.Vector3;
  b: THREE.Vector3;
  dead?: boolean;
}

/** 2D (XZ) reflection of dir across a mirror plane at angle m. */
function reflect(dx: number, dz: number, state: number): [number, number] {
  const m = (state * Math.PI) / 4;
  const ux = Math.cos(m);
  const uz = Math.sin(m);
  const d = dx * ux + dz * uz;
  return [2 * d * ux - dx, 2 * d * uz - dz];
}

export default function SunbeamPuzzle() {
  const prisms = useGame((s) => s.prisms);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const shaftTex = useMemo(() => makeShaftTexture(), []);
  const rotors = useRef<THREE.Group[]>([]);
  const mote = useRef<THREE.Mesh>(null!);
  const solved = useRef(false);
  const moteT = useRef(0);

  /* register prism interactables (proximity + E / tap button) */
  useEffect(() => {
    const regs = PRISMS.map((pr, i) => ({
      id: pr.id,
      label: "Turn the shard-stone",
      radius: 2.6,
      enabled: true,
      getPos: () => ({ x: pr.pos[0], y: terrainHeight(pr.pos[0], pr.pos[1]) + 1.2, z: pr.pos[1] }),
      action: () => {
        const s = useGame.getState();
        if (s.bloomAt > 0) {
          audio.denied();
          return;
        }
        s.setPrism(i, (useGame.getState().prisms[i] + 1) % 4);
        audio.tick();
      },
    }));
    regs.forEach((r) => useGame.getState().registerInteractable(r));
    return () => regs.forEach((r) => useGame.getState().unregisterInteractable(r.id));
  }, []);

  /* ---------------- beam tracing ---------------- */
  const beam = useMemo(() => {
    const lift = WORLD.beamLift;
    const segs: BeamSegment[] = [];
    const [sx, sz] = SOURCE.pos;
    let nx = sx;
    let nz = sz;
    let dx = SOURCE.dir[0];
    let dz = SOURCE.dir[1];
    let reached = 0;
    for (let i = 0; i < PRISMS.length; i++) {
      const [px, pz] = PRISMS[i].pos;
      const node = new THREE.Vector3(nx, terrainHeight(nx, nz) + lift, nz);
      const pPoint = new THREE.Vector3(px, terrainHeight(px, pz) + lift, pz);
      segs.push({ a: node, b: pPoint });
      // does the reflection send us (close enough) to the next node?
      const [rx, rz] = reflect(dx, dz, prisms[i]);
      const goal = i < PRISMS.length - 1 ? PRISMS[i + 1].pos : FLOWER.pos;
      let tx = goal[0] - px;
      let tz = goal[1] - pz;
      const tl = Math.hypot(tx, tz);
      tx /= tl;
      tz /= tl;
      const dot = rx * tx + rz * tz;
      if (dot > 0.995) {
        reached = i + 1;
        dx = tx;
        dz = tz;
        nx = px;
        nz = pz;
        continue;
      }
      // beam dies in the wrong direction
      segs.push({
        a: pPoint,
        b: new THREE.Vector3(px + rx * 2.2, pPoint.y - 0.4, pz + rz * 2.2),
        dead: true,
      });
      return { segs, reached, complete: false, flower: null as THREE.Vector3 | null, total: 0 };
    }
    const flower = new THREE.Vector3(
      FLOWER.pos[0],
      terrainHeight(FLOWER.pos[0], FLOWER.pos[1]) + FLOWER.budHeight + 0.2,
      FLOWER.pos[1]
    );
    segs.push({ a: segs[segs.length - 1].b, b: flower });
    return { segs, reached, complete: true, flower, total: 0 };
  }, [prisms]);

  const totalLen = useMemo(
    () => beam.segs.reduce((acc, s) => acc + s.a.distanceTo(s.b), 0),
    [beam]
  );

  /* beam progress → audio glow + store (drives hints) */
  useEffect(() => {
    useGame.getState().setBeamReached(beam.reached);
    audio.setBeamGlow((beam.reached / 3) * 0.6);
    if (beam.reached > 0) useGame.getState().markProgress();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [beam.reached]);

  /* solve trigger */
  useEffect(() => {
    if (!beam.complete || solved.current) return;
    solved.current = true;
    const s = useGame.getState();
    const flowerFocus = new THREE.Vector3(
      FLOWER.pos[0],
      terrainHeight(FLOWER.pos[0], FLOWER.pos[1]) + 2.6,
      FLOWER.pos[1]
    );
    window.setTimeout(() => {
      audio.bloom();
      s.say("Bloomheart", "*…a chord of four notes. The garden remembers the sun.*");
    }, 900);
    window.setTimeout(() => {
      s.triggerBloom();
      s.setObjective("Gather the memory");
      RT.cutscene = {
        focus: flowerFocus,
        camOffset: new THREE.Vector3(3.6, 1.8, 3.6),
        t: 0,
        dur: s.settings.reducedMotion ? 0.4 : 2.8,
        onDone: () => s.setPhase("gather"),
      };
    }, 1400);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [beam.complete]);

  /* animate rotors + traveling mote */
  const tmp = useMemo(() => ({ v: new THREE.Vector3() }), []);
  useFrame((state, dt) => {
    rotors.current.forEach((r, i) => {
      if (!r) return;
      const target = (prisms[i] * Math.PI) / 4 + Math.PI / 8;
      r.rotation.y = THREE.MathUtils.damp(r.rotation.y, target, 10, dt);
    });
    if (mote.current && totalLen > 0) {
      moteT.current = (moteT.current + dt * 4.2) % totalLen;
      let d = moteT.current;
      for (const s of beam.segs) {
        const l = s.a.distanceTo(s.b);
        if (d <= l) {
          mote.current.position.lerpVectors(s.a, s.b, d / l);
          break;
        }
        d -= l;
      }
      const sc = beam.complete ? 1 : 0.75;
      mote.current.scale.setScalar(sc + Math.sin(state.clock.elapsedTime * 9) * 0.15);
    }
  });

  return (
    <group>
      {/* ------- source arch ------- */}
      <group position={[SOURCE.pos[0], terrainHeight(SOURCE.pos[0], SOURCE.pos[1]), SOURCE.pos[1]]}>
        <mesh position={[0, 0.7, -0.5]} rotation={[0.14, 0, 0.06]} castShadow>
          <boxGeometry args={[0.5, 1.7, 0.42]} />
          <meshStandardMaterial color="#6b6152" roughness={0.95} />
        </mesh>
        <mesh position={[0, 0.7, 0.5]} rotation={[-0.14, 0, -0.06]} castShadow>
          <boxGeometry args={[0.5, 1.7, 0.42]} />
          <meshStandardMaterial color="#6b6152" roughness={0.95} />
        </mesh>
        {/* floating crystal that drinks the evening sun */}
        <mesh position={[0, WORLD.beamLift, 0]} rotation={[0.6, 0.4, 0.2]}>
          <octahedronGeometry args={[0.34, 0]} />
          <meshStandardMaterial
            color="#ffe3ae"
            emissive="#ffca72"
            emissiveIntensity={2.4}
            roughness={0.2}
          />
        </mesh>
        <sprite position={[0, WORLD.beamLift, 0]} scale={[1.5, 1.5, 1]}>
          <spriteMaterial map={glowTex} color="#ffdf9e" transparent opacity={0.75} depthWrite={false} />
        </sprite>
      </group>

      {/* ------- shard-stones ------- */}
      {PRISMS.map((pr, i) => {
        const [px, pz] = pr.pos;
        const py = terrainHeight(px, pz);
        return (
          <group key={pr.id} position={[px, py, pz]}>
            <mesh position={[0, 0.32, 0]} castShadow receiveShadow>
              <dodecahedronGeometry args={[0.55, 0]} />
              <meshStandardMaterial color="#7d7466" roughness={0.95} />
            </mesh>
            <group
              ref={(el) => {
                if (el) rotors.current[i] = el;
              }}
              position={[0, WORLD.beamLift, 0]}
            >
              <mesh
                onClick={(e) => {
                  e.stopPropagation();
                  const s = useGame.getState();
                  if (RT.wasDrag || s.bloomAt > 0) return;
                  s.setPrism(i, (s.prisms[i] + 1) % 4);
                  audio.tick();
                  s.markProgress();
                }}
              >
                <boxGeometry args={[1.05, 1.35, 0.1]} />
                <meshPhysicalMaterial
                  color="#bfe0e8"
                  metalness={0.1}
                  roughness={0.12}
                  transparent
                  opacity={0.85}
                  clearcoat={1}
                  emissive="#9fd8ff"
                  emissiveIntensity={0.25}
                />
              </mesh>
              {/* brass gimbal */}
              <mesh position={[0, -0.85, 0]}>
                <cylinderGeometry args={[0.09, 0.14, 0.5, 8]} />
                <meshStandardMaterial color="#a8824e" metalness={0.85} roughness={0.4} />
              </mesh>
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.68, 0.035, 8, 28]} />
                <meshStandardMaterial color="#a8824e" metalness={0.85} roughness={0.4} />
              </mesh>
            </group>
            {/* base glow when the beam passes through this stone */}
            {beam.reached > i && (
              <sprite position={[0, 0.6, 0]} scale={[1.4, 1.4, 1]}>
                <spriteMaterial map={glowTex} color="#ffe9b8" transparent opacity={0.5} depthWrite={false} />
              </sprite>
            )}
          </group>
        );
      })}

      {/* ------- beam segments ------- */}
      {beam.segs.map((s, i) => {
        const len = s.a.distanceTo(s.b);
        tmp.v.addVectors(s.a, s.b).multiplyScalar(0.5);
        const dir = new THREE.Vector3().subVectors(s.b, s.a).normalize();
        const quat = new THREE.Quaternion().setFromUnitVectors(UP, dir);
        return (
          <group key={i} position={tmp.v.toArray()} quaternion={quat}>
            <mesh>
              <cylinderGeometry args={[0.035, 0.035, len, 6]} />
              <meshBasicMaterial
                color={s.dead ? "#c8b490" : "#ffe9b0"}
                transparent
                opacity={s.dead ? 0.35 : 0.95}
                blending={THREE.AdditiveBlending}
                depthWrite={false}
              />
            </mesh>
            <mesh>
              <cylinderGeometry args={[0.12, 0.12, len, 6]} />
              <meshBasicMaterial
                color="#ffdf9e"
                transparent
                opacity={s.dead ? 0.05 : 0.14}
                blending={THREE.AdditiveBlending}
                depthWrite={false}
              />
            </mesh>
          </group>
        );
      })}

      {/* light mote traveling the path */}
      <mesh ref={mote}>
        <sphereGeometry args={[0.09, 10, 8]} />
        <meshBasicMaterial color="#fff6dd" transparent opacity={0.95} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>

      {/* faint staircase-of-light clue: dust catching the intended path */}
      <ClueDust tex={shaftTex} />
    </group>
  );
}

/** barely-there glints hovering over the intended route (diegetic clue) */
function ClueDust({ tex }: { tex: THREE.Texture }) {
  const path: [number, number][] = [
    [SOURCE.pos[0], SOURCE.pos[1]],
    [PRISMS[0].pos[0], PRISMS[0].pos[1]],
    [PRISMS[1].pos[0], PRISMS[1].pos[1]],
    [PRISMS[2].pos[0], PRISMS[2].pos[1]],
    [FLOWER.pos[0], FLOWER.pos[1]],
  ];
  const pts = useMemo(() => {
    const arr: number[] = [];
    for (let i = 0; i < path.length - 1; i++) {
      const [ax, az] = path[i];
      const [bx, bz] = path[i + 1];
      const steps = 7;
      for (let k = 1; k < steps; k++) {
        const x = ax + ((bx - ax) * k) / steps;
        const z = az + ((bz - az) * k) / steps;
        arr.push(x, terrainHeight(x, z) + WORLD.beamLift + 0.25, z);
      }
    }
    return new Float32Array(arr);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const ref = useRef<THREE.Points>(null!);
  useFrame((state) => {
    (ref.current.material as THREE.PointsMaterial).opacity =
      0.1 + Math.sin(state.clock.elapsedTime * 1.3) * 0.06;
  });
  return (
    <points ref={ref} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[pts, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.35}
        map={tex}
        color="#ffe9b0"
        transparent
        opacity={0.12}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}
