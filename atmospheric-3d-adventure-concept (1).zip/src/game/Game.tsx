/**
 * Game.tsx — composition root of the playable prototype. Assembles the
 * canvas, active region, actors, camera and post stack; owns cross-cutting
 * loops: proximity interaction, progressive hints, global shortcuts, touch
 * detection, settings sync — and Rootway travel orchestration between
 * regions (streamed by conditional mount).
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Bloom, DepthOfField, EffectComposer, Vignette } from "@react-three/postprocessing";
import type { DepthOfFieldEffect } from "postprocessing";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { audio } from "./audio";
import { useKeyboardInput } from "./input";
import { RT } from "./runtime";
import { useGame } from "./store";
import { showHint } from "./hints";
import { SPAWNS } from "./layout";
import GardenRegion from "./regions/GardenRegion";
import RootRegion from "./regions/root/RootRegion";
import Milo from "./player/Milo";
import CameraRig from "./player/CameraRig";
import HUD from "./ui/HUD";
import Overlays from "./ui/Overlays";
import TouchControls from "./ui/TouchControls";

/* ------------------------------------------------------------------ */

function SceneBase() {
  const region = useGame((s) => s.region);
  const gl = useThree((s) => s.gl);
  const scene = useThree((s) => s.scene);
  useEffect(() => {
    const pmrem = new THREE.PMREMGenerator(gl);
    const env = pmrem.fromScene(new RoomEnvironment(), 0.06).texture;
    scene.environment = env;
    return () => {
      scene.environment = null;
      env.dispose();
      pmrem.dispose();
    };
  }, [gl, scene]);
  return (
    <>
      <color attach="background" args={[region === "root" ? "#120b06" : "#0e1a12"]} />
      <fog attach="fog" args={region === "root" ? ["#1d140a", 12, 40] : ["#17281b", 16, 52]} />
    </>
  );
}

/** throttled nearest-interactable scan (10Hz is plenty, saves the GC) */
function ProximityWatcher() {
  const acc = useRef(0);
  const last = useRef<string | null>(null);
  useFrame((_, dt) => {
    acc.current += dt;
    if (acc.current < 0.1) return;
    acc.current = 0;
    const s = useGame.getState();
    if (s.panel !== "none" || s.travelingTo) {
      if (last.current !== null) {
        last.current = null;
        s.setInteractTarget(null);
      }
      return;
    }
    let best: string | null = null;
    let bestD = Infinity;
    for (const id in s.interactables) {
      const it = s.interactables[id];
      if (!it.enabled) continue;
      const p = it.getPos();
      const d = RT.playerPos.distanceTo(new THREE.Vector3(p.x, p.y, p.z));
      if (d < it.radius && d < bestD) {
        bestD = d;
        best = id;
      }
    }
    if (best !== last.current) {
      last.current = best;
      s.setInteractTarget(best);
    }
  });
  return null;
}

function Effects() {
  const quality = useGame((s) => s.settings.quality);
  const dof = useRef<DepthOfFieldEffect | null>(null);
  const vec = useMemo(() => new THREE.Vector3(0, 1, 14), []);
  // The effect reads `target` by reference each frame (auto-focus), so we
  // assign once and simply keep the vector on Milo's head.
  const setDofRef = (e: DepthOfFieldEffect | null) => {
    dof.current = e;
    if (e) e.target = vec;
  };
  useFrame(() => {
    vec.copy(RT.playerPos);
    vec.y += 0.55;
  });
  return (
    <EffectComposer multisampling={quality === "high" ? 4 : 0}>
      <Bloom mipmapBlur intensity={0.72} luminanceThreshold={0.5} luminanceSmoothing={0.32} />
      {quality !== "low" && (
        <DepthOfField
          ref={setDofRef}
          focusRange={2.4}
          bokehScale={quality === "high" ? 2.6 : 1.6}
        />
      )}
      <Vignette offset={0.26} darkness={0.58} />
    </EffectComposer>
  );
}

/* ------------------------------------------------------------------ */

export default function Game({ onOpenDoc }: { onOpenDoc: () => void }) {
  const quality = useGame((s) => s.settings.quality);
  const runId = useGame((s) => s.runId);
  const region = useGame((s) => s.region);
  const travelingTo = useGame((s) => s.travelingTo);
  const volume = useGame((s) => s.settings.volume);
  const muted = useGame((s) => s.settings.muted);
  useKeyboardInput(true);

  // quality knobs consumed by the scene at mount time
  RT.quality =
    quality === "high"
      ? { transmission: true, shadows: true, grass: 2100, fireflyLight: true }
      : quality === "medium"
        ? { transmission: false, shadows: true, grass: 1300, fireflyLight: false }
        : { transmission: false, shadows: false, grass: 750, fireflyLight: false };

  /* post-hydration: a save made in the Hollow Root must never replay the
     garden intro — reinstall its sampler and land the player cleanly */
  useEffect(() => {
    const s = useGame.getState();
    if (s.region !== "garden" && s.phase === "intro") {
      s.setRegion(s.region);
      const [sx, sz] = SPAWNS[s.region];
      RT.playerPos.set(sx, 2, sz);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* touch detection → virtual controls */
  useEffect(() => {
    const fn = (e: PointerEvent) => {
      if (e.pointerType === "touch") useGame.getState().setTouchMode(true);
    };
    window.addEventListener("pointerdown", fn);
    return () => window.removeEventListener("pointerdown", fn);
  }, []);

  /* audio settings sync */
  useEffect(() => audio.setVolume(volume), [volume]);
  useEffect(() => audio.setMuted(muted), [muted]);

  /* Rootway travel: fade → swap region → place Milo → fade back */
  useEffect(() => {
    if (!travelingTo) return;
    audio.whoosh();
    const t1 = window.setTimeout(() => {
      const s = useGame.getState();
      s.setRegion(travelingTo);
      const [sx, sz] = SPAWNS[travelingTo];
      RT.playerPos.set(sx, 2, sz);
      const t2 = window.setTimeout(() => s.setTravelingTo(null), 280);
      return () => window.clearTimeout(t2);
    }, 560);
    return () => window.clearTimeout(t1);
  }, [travelingTo]);

  /* global shortcuts */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = useGame.getState();
      if (e.code === "Escape") {
        s.setPanel(s.panel === "none" ? "settings" : "none");
        return;
      }
      if (s.panel !== "none") return;
      if (e.code === "KeyE") {
        const t = s.interactTargetId;
        if (t && s.interactables[t]?.enabled) s.interactables[t].action();
      } else if (e.code === "KeyH") showHint();
      else if (e.code === "KeyM") s.setPanel("map");
      else if (e.code === "KeyJ") s.setPanel("journal");
      else if (e.code === "KeyC") s.setPanel("controls");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /* progressive hint engine — only surfaces when the player seems stuck */
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = useGame.getState();
      if (s.panel !== "none" || s.travelingTo || s.bloomAt > 0 && s.region === "garden") return;
      if (s.vaultAt > 0 && s.region === "root") return;
      if (s.phase === "intro") return;
      const idle = (Date.now() - s.lastProgress) / 1000;
      if (idle > 28 && !s.hintText) showHint();
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const dpr: [number, number] =
    quality === "high" ? [1, 2] : quality === "medium" ? [1, 1.6] : [1, 1];

  return (
    <div className="absolute inset-0 overflow-hidden bg-[#0b140d]">
      <Canvas
        key={`${quality}-${runId}`}
        shadows
        dpr={dpr}
        gl={{ antialias: true, powerPreference: "high-performance" }}
        camera={{ fov: 44, position: [11, 9, 24], near: 0.1, far: 160 }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.06;
          audio.init();
          audio.resume();
        }}
      >
        <SceneBase />
        {region === "garden" ? <GardenRegion /> : <RootRegion />}
        <Milo key={region} spawn={SPAWNS[region] as [number, number]} />
        <CameraRig />
        <ProximityWatcher />
        <Effects />
      </Canvas>
      <HUD onOpenDoc={onOpenDoc} />
      <Overlays />
      <TouchControls />
    </div>
  );
}
