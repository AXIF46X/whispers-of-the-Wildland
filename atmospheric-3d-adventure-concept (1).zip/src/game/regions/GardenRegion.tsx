/**
 * GardenRegion.tsx — Region 01, "The Fallen Garden". Owns its sampler
 * install, environment, beam puzzle, companion creature, collectibles,
 * and the Rootway gate that blooms in the northwest once the rite is done.
 */
import { useGame } from "../store";
import { BLOOM_MEMORY, FLOWER, GARDEN_PORTAL_POS, MEMORY_MOTES } from "../layout";
import Environment from "../world/Environment";
import SunbeamPuzzle from "../puzzles/SunbeamPuzzle";
import WispMoth from "../creatures/WispMoth";
import Collectibles from "../world/Collectibles";
import Portal from "../world/Portal";

export default function GardenRegion() {
  const phase = useGame((s) => s.phase);
  const rootUnlocked = useGame((s) => s.unlocked.includes("root"));

  return (
    <>
      <Environment />
      <SunbeamPuzzle />
      <WispMoth />
      <Collectibles
        motes={MEMORY_MOTES}
        bloom={BLOOM_MEMORY}
        bloomPos={[FLOWER.pos[0] + 1.4, FLOWER.pos[1] - 0.6]}
        bloomVisible={phase === "gather" || phase === "epilogue"}
        regionId="garden"
        epilogueObjective="The garden breathes — the Rootway sings in the northwest"
      />
      {rootUnlocked && (
        <Portal
          id="portal-garden-root"
          pos={GARDEN_PORTAL_POS}
          to="root"
          label="Enter the Rootway — The Hollow Root"
          tint="#a8e0b8"
        />
      )}
    </>
  );
}
