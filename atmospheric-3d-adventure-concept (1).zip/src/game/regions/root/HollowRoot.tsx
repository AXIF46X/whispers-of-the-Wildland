/**
 * HollowRoot.tsx — environment of Region 02, "The Hollow Root".
 * The interior of a colossal dead root: a rib-vaulted cavern lit by
 * knothole skylight, rivers of luminous sap, bioluminescent glowcaps and
 * amber stalactites. Deliberately darker than the garden — the region's
 * light is a resource, and the Rootheart is its heart.
 */
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { rootHeight } from "./rootTerrain";
import { RT } from "../../runtime";
import { useGame } from "../../store";
import {
  makeBarkTexture,
  makeGlowTexture,
  makeGroundTexture,
  makeSapTexture,
  makeShaftTexture,
} from "../../world/textures";
import { mulberryLite } from "./helpers";

/* ------------------------------------------------------------------ */

function RootLights() {
  const quality = useGame((s) => s.settings.quality);
  return (
    <group>
      <hemisphereLight args={["#33413b", "#170f08", 0.5]} />
      {/* knothole skylight */}
      <spotLight
        position={[1.5, 14, 1]}
        angle={0.42}
        penumbra={0.9}
        intensity={quality === "low" ? 55 : 90}
        color="#ffe6c0"
        distance={30}
        decay={2}
        castShadow={quality !== "low"}
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[2, 12, 1]} intensity={0.4} color="#ffd9a8" />
    </group>
  );
}

function RootGround() {
  const detail = useMemo(() => makeGroundTexture(), []);
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(52, 52, 96, 96);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const cLoam = new THREE.Color("#4a3a28");
    const cMoss = new THREE.Color("#5b5232");
    const cVein = new THREE.Color("#6b4a26");
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      pos.setY(i, rootHeight(x, z));
      const n = 0.5 + 0.5 * Math.sin(x * 1.1 + z * 1.6) * Math.sin(x * 0.4 - z * 0.7 + 2);
      c.lerpColors(cLoam, cMoss, THREE.MathUtils.clamp(n, 0, 1));
      // amber veins radiating from the dais
      const vein = Math.abs(Math.sin(Math.atan2(z, x) * 4 + Math.sqrt(x * x + z * z) * 0.8));
      if (vein > 0.92) c.lerp(cVein, 0.5);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    g.computeVertexNormals();
    return g;
  }, []);
  return (
    <mesh geometry={geo} receiveShadow>
      <meshStandardMaterial map={detail} vertexColors roughness={0.95} />
    </mesh>
  );
}

function CavernShell() {
  const bark = useMemo(() => makeBarkTexture(), []);
  const domeGeo = useMemo(() => {
    const g = new THREE.SphereGeometry(27, 40, 20, 0, Math.PI * 2, 0, Math.PI * 0.55);
    g.scale(1, 0.42, 1);
    return g;
  }, []);
  return (
    <group>
      {/* rib-vaulted ceiling */}
      <mesh geometry={domeGeo} position={[0, -0.8, 0]}>
        <meshStandardMaterial map={bark} color="#3a2c1e" roughness={1} side={THREE.BackSide} />
      </mesh>
      {/* giant root ribs arcing from rim to apex */}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const a = (i / 6) * Math.PI * 2 + 0.4;
        return (
          <mesh
            key={i}
            position={[Math.cos(a) * 1.2, 3.6, Math.sin(a) * 1.2]}
            rotation={[0, -a + Math.PI / 2, 1.12]}
          >
            <torusGeometry args={[11, 0.6, 8, 20, Math.PI * 0.62]} />
            <meshStandardMaterial map={bark} color="#4a3826" roughness={1} />
          </mesh>
        );
      })}
      {/* knothole — the sky wound */}
      <mesh position={[1.5, 10.6, 1]} rotation={[Math.PI / 2, 0, 0.2]}>
        <torusGeometry args={[1.7, 0.5, 10, 24]} />
        <meshStandardMaterial map={bark} color="#54402c" roughness={1} />
      </mesh>
      <LightShaft />
    </group>
  );
}

function LightShaft() {
  const tex = useMemo(() => makeShaftTexture(), []);
  const glow = useMemo(() => makeGlowTexture(), []);
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((state) => {
    (ref.current.material as THREE.MeshBasicMaterial).opacity =
      0.16 + Math.sin(state.clock.elapsedTime * 0.3) * 0.05;
  });
  return (
    <group>
      <mesh ref={ref} position={[1.5, 5.8, 1]} rotation={[0.06, 0, 0.12]}>
        <planeGeometry args={[4.4, 11.5]} />
        <meshBasicMaterial map={tex} transparent blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[1.5, 10.4, 1]} rotation={[Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.5, 24]} />
        <meshBasicMaterial color="#fff3d8" transparent opacity={0.9} />
      </mesh>
      <DustMotes glow={glow} />
    </group>
  );
}

function DustMotes({ glow }: { glow: THREE.Texture }) {
  const count = 46;
  const ref = useRef<THREE.Points>(null!);
  const positions = useMemo(() => {
    const rand = mulberryLite(11);
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = rand() * 2.4;
      const a = rand() * Math.PI * 2;
      arr[i * 3] = 1.5 + Math.cos(a) * r;
      arr[i * 3 + 1] = rand() * 8.5;
      arr[i * 3 + 2] = 1 + Math.sin(a) * r;
    }
    return arr;
  }, []);
  useFrame((state, dt) => {
    ref.current.rotation.y += dt * 0.02;
    ref.current.position.y = Math.sin(state.clock.elapsedTime * 0.16) * 0.4;
  });
  return (
    <points ref={ref} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.1} map={glow} transparent opacity={0.5} color="#ffe9c0" depthWrite={false} sizeAttenuation />
    </points>
  );
}

/** rivers of luminous sap — scrolling emissive ribbons sunk into the floor */
function SapFlows() {
  const sap = useMemo(() => makeSapTexture(), []);
  const glow = useMemo(() => makeGlowTexture(), []);
  useFrame((_, dt) => {
    sap.offset.x -= dt * 0.45;
  });
  const flows: { pos: [number, number, number]; rot: [number, number, number]; major: number; arc: number }[] = [
    { pos: [0, 0.02, 0], rot: [-Math.PI / 2, 0, 0.6], major: 5.4, arc: 2.2 },
    { pos: [1.5, 0.0, -1], rot: [-Math.PI / 2, 0, 2.4], major: 7.8, arc: 1.6 },
    { pos: [-1, 0.02, 0.8], rot: [-Math.PI / 2, 0, 4.2], major: 6.5, arc: 1.9 },
  ];
  return (
    <group>
      {flows.map((f, i) => {
        const [px, py, pz] = f.pos;
        return (
          <group key={i}>
            <mesh position={[px, py + 0.04, pz]} rotation={f.rot}>
              <torusGeometry args={[f.major, 0.13, 6, 40, f.arc]} />
              <meshStandardMaterial
                map={sap}
                emissiveMap={sap}
                emissive="#ff9d3c"
                emissiveIntensity={1.6}
                color="#3a2a18"
                roughness={0.4}
              />
            </mesh>
            {/* glow nodes where the sap pools at arc ends */}
            {[0, f.arc].map((a, k) => {
              const ang = a;
              const gx = px + Math.cos(ang) * f.major * 1;
              const gz = pz - Math.sin(ang) * f.major * 1;
              // approximate endpoint on the rotated arc (good enough for glow placement)
              return (
                <sprite key={k} position={[gx * 0.9, rootHeight(gx * 0.9, gz * 0.9) + 0.24, gz * 0.9]} scale={[0.9, 0.9, 1]}>
                  <spriteMaterial map={glow} color="#ffb45e" transparent opacity={0.5} depthWrite={false} />
                </sprite>
              );
            })}
          </group>
        );
      })}
      {RT.quality.fireflyLight && <pointLight position={[4, rootHeight(4, 2) + 0.7, 2]} color="#ff9d3c" intensity={2.4} distance={5.5} decay={2} />}
    </group>
  );
}

function ResinPool({ glow }: { glow: THREE.Texture }) {
  const ring = useRef<THREE.Mesh>(null!);
  const [x, z] = [-4.6, -8.2];
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const s = 0.6 + ((t * 0.25) % 1);
    ring.current.scale.setScalar(s);
    (ring.current.material as THREE.MeshBasicMaterial).opacity = 0.3 * (1.6 - s);
  });
  return (
    <group position={[x, rootHeight(x, z) + 0.04, z]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.8, 36]} />
        <meshPhysicalMaterial color="#7a4a16" roughness={0.12} transparent opacity={0.92} clearcoat={1} emissive="#6b3a10" emissiveIntensity={0.35} />
      </mesh>
      <mesh ref={ring} rotation={[-Math.PI / 2, 0, 0]} position={[0.2, 0.005, 0]}>
        <ringGeometry args={[0.95, 1, 32]} />
        <meshBasicMaterial color="#ffca72" transparent opacity={0.25} depthWrite={false} />
      </mesh>
      <sprite position={[0.3, 0.06, 0]} scale={[0.8, 0.8, 1]}>
        <spriteMaterial map={glow} color="#ffca72" transparent opacity={0.3} depthWrite={false} />
      </sprite>
    </group>
  );
}

function Glowcaps() {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = 74;
  useLayoutEffect(() => {
    const rand = mulberryLite(23);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    let placed = 0;
    let guard = 0;
    while (placed < count && guard < 3000) {
      guard++;
      const r = 1.5 + Math.sqrt(rand()) * 11;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      dummy.position.set(x, rootHeight(x, z) + 0.05, z);
      const s = 0.1 + rand() * 0.3;
      dummy.scale.set(s, s * (0.7 + rand() * 0.7), s);
      dummy.rotation.set(0, rand() * Math.PI, 0);
      dummy.updateMatrix();
      ref.current.setMatrixAt(placed, dummy.matrix);
      color.set("#8fe0d0").offsetHSL((rand() - 0.5) * 0.06, 0, (rand() - 0.5) * 0.25);
      ref.current.setColorAt(placed, color);
      placed++;
    }
    ref.current.count = placed;
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  }, []);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5]} />
      <meshStandardMaterial color="#ffffff" emissive="#4ec9b0" emissiveIntensity={0.55} roughness={0.5} />
    </instancedMesh>
  );
}

function Stalactites() {
  const items = useMemo(() => {
    const rand = mulberryLite(39);
    return Array.from({ length: 11 }, () => {
      const r = 2 + rand() * 9.5;
      const a = rand() * Math.PI * 2;
      return { x: Math.cos(a) * r, z: Math.sin(a) * r, s: 0.5 + rand() * 1.3, y: 6.2 + rand() * 1.6 };
    });
  }, []);
  return (
    <group>
      {items.map((s, i) => (
        <mesh key={i} position={[s.x, s.y, s.z]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.16 * s.s, 1.1 * s.s, 8]} />
          <meshPhysicalMaterial
            color="#c8862e"
            roughness={0.15}
            transmission={0.5}
            thickness={0.4}
            emissive="#7a4a16"
            emissiveIntensity={0.25}
          />
        </mesh>
      ))}
    </group>
  );
}

function PaleGrass() {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const count = 240;
  useLayoutEffect(() => {
    const rand = mulberryLite(51);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    for (let i = 0; i < count; i++) {
      const r = 1 + Math.sqrt(rand()) * 11;
      const a = rand() * Math.PI * 2;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      dummy.position.set(x, rootHeight(x, z) + 0.09, z);
      dummy.rotation.set((rand() - 0.5) * 0.8, rand() * Math.PI * 2, (rand() - 0.5) * 0.8);
      const s = 0.5 + rand() * 1.2;
      dummy.scale.set(s, 0.6 + rand() * 1.1, s);
      dummy.updateMatrix();
      ref.current.setMatrixAt(i, dummy.matrix);
      color.set("#9aa468").offsetHSL(0, 0, (rand() - 0.5) * 0.16);
      ref.current.setColorAt(i, color);
    }
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  }, []);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]}>
      <coneGeometry args={[0.05, 0.24, 5]} />
      <meshStandardMaterial color="#ffffff" roughness={1} />
    </instancedMesh>
  );
}

export default function HollowRoot() {
  const glow = useMemo(() => makeGlowTexture(), []);
  return (
    <group>
      <RootLights />
      <RootGround />
      <CavernShell />
      <SapFlows />
      <ResinPool glow={glow} />
      <Glowcaps />
      <Stalactites />
      <PaleGrass />
    </group>
  );
}
