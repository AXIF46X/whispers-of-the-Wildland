/**
 * rootLayout.ts — authored constants for Region 02, "The Hollow Root".
 *
 * The "Seed-Chord" puzzle: four hanging chime-bells ring distinct pitches.
 * The correct order — the region's lullaby — is demonstrated by the
 * Loamglider, a blind creature that reads the world through vibration.
 */

export const ROOT_VAULT = { pos: [0, 0] as [number, number], coreHeight: 1.5 };

export interface ChimeDef {
  id: string;
  pos: [number, number];
  hang: number; // cord length above the bell
  freq: number;
  tint: string;
  glow: string;
}

export const CHIMES: ChimeDef[] = [
  { id: "chime-0", pos: [5.6, 1.8], hang: 3.1, freq: 293.66, tint: "#ffca72", glow: "#ffd9a0" },
  { id: "chime-1", pos: [1.6, -5.8], hang: 3.6, freq: 349.23, tint: "#ff9d8a", glow: "#ffb8a8" },
  { id: "chime-2", pos: [-5.8, -1.4], hang: 3.2, freq: 220.0, tint: "#8fd4ff", glow: "#b8e4ff" },
  { id: "chime-3", pos: [-1.6, 5.8], hang: 3.8, freq: 261.63, tint: "#c9a8ff", glow: "#dcc8ff" },
];

/** the seed-chord, as the Loamglider hums it (indices into CHIMES) */
export const SEQUENCE = [1, 3, 0, 2];

export const ROOT_MOTES = [
  {
    id: "mote-root-song",
    pos: [8.2, 6] as [number, number],
    title: "Memory — The Tuning",
    text: "Before the lamps, there were songs. The First Gardeners tuned every root so the forest could hear itself grow.",
  },
  {
    id: "mote-root-keeper",
    pos: [-7.2, -4.4] as [number, number],
    title: "Memory — The Keeper Below",
    text: "\u2018Blind little keeper, who waters the dark?\u2019 — \u2018Nobody, anymore. But I still hum the instructions.\u2019",
  },
];

export const VAULT_MEMORY = {
  id: "mote-vault",
  title: "Memory — The Seed That Waited",
  text: "Wrapped in root and resin, a seed with a metal heart. The forest kept you like a promise it was afraid to break.",
};

export const ROOT_PORTAL_GARDEN: [number, number] = [0, -11.6];
export const ROOT_PORTAL_STREAM: [number, number] = [0, 11.8];

/** the Loamglider's resting circle + demonstration approach points */
export const LOAM_HOME: [number, number] = [-3.2, 3.4];
