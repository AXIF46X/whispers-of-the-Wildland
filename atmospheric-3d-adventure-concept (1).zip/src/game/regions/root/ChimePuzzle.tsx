/**
 * ChimePuzzle.tsx — "The Seed-Chord" (Hollow Root puzzle).
 *
 * Four root-bells hang from the cavern ribs, each ringing its own pitch.
 * The rite: echo the four-tone seed-chord in order. The Loamglider — a
 * blind keeper who reads vibration — periodically demonstrates the tune,
 * and will repeat it on request. Progress is shown as seed-dots kindling
 * above the Rootheart, so state is always readable in the world.
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { CHIMES, ROOT_VAULT, SEQUENCE } from "./rootLayout";
import { rootHeight } from "./rootTerrain";
import { RT } from "../../runtime";
import { audio } from "../../audio";
import { useGame } from "../../store";
import { makeGlowTexture } from "../../world/textures";

/** bridge so the Loamglider can ring the same bells the player rings */
export const chimeBus = {
  ring: (_i: number) => {},
};

export default function ChimePuzzle() {
  const vaultAt = useGame((s) => s.vaultAt);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const bells = useRef<THREE.Group[]>([]);
  const bellSwing = useRef<number[]>([0, 0, 0, 0]);
  const bellVel = useRef<number[]>([0, 0, 0, 0]);
  const dots = useRef<THREE.Mesh[]>([]);
  const core = useRef<THREE.Mesh>(null!);
  const coreLight = useRef<THREE.PointLight>(null!);
  const coreHalo = useRef<THREE.Sprite>(null!);
  const ripples = useRef<THREE.Mesh[]>([]);
  const rippleT = useRef<number[]>([9, 9, 9, 9]);
  const progress = useRef(0);
  const solved = useRef(false);

  const [vx, vz] = ROOT_VAULT.pos;
  const vy = rootHeight(vx, vz);

  /* ---------- the ringing of a bell ---------- */
  const ring = (i: number) => {
    audio.bell(CHIMES[i].freq, true);
    bellVel.current[i] += 3.4;
    rippleT.current[i] = 0;
    const s = useGame.getState();
    if (s.vaultAt > 0 || solved.current) return; // free-play after the rite

    const expected = SEQUENCE[progress.current];
    if (i === expected) {
      progress.current++;
      s.markProgress();
      if (progress.current === 1) s.setObjective("Echo the seed-chord — four tones in order");
      if (progress.current >= SEQUENCE.length) {
        solved.current = true;
        // staggered jubilant re-ring
        SEQUENCE.forEach((idx, k) =>
          window.setTimeout(() => {
            audio.bell(CHIMES[idx].freq * 2, true);
            bellVel.current[idx] += 2.6;
          }, 400 + k * 220)
        );
        window.setTimeout(() => {
          audio.vaultChord();
          s.say("Rootheart", "*the fourth tone settles. Something below answers.*");
        }, 1000);
        window.setTimeout(() => {
          s.triggerVault();
          s.setObjective("Gather the buried memory");
          RT.cutscene = {
            focus: new THREE.Vector3(vx, vy + 1.7, vz),
            camOffset: new THREE.Vector3(3.4, 2.1, 4.2),
            t: 0,
            dur: s.settings.reducedMotion ? 0.4 : 2.6,
            onDone: () => useGame.getState().setPhase("gather"),
          };
        }, 1600);
      }
    } else {
      audio.bell(CHIMES[i].freq, false);
      progress.current = 0;
      s.markProgress();
    }
  };

  useEffect(() => {
    chimeBus.ring = ring;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- interactables ---------- */
  useEffect(() => {
    const regs = CHIMES.map((c, i) => ({
      id: c.id,
      label: "Ring the root-bell",
      radius: 2.6,
      enabled: true,
      getPos: () => ({ x: c.pos[0], y: rootHeight(c.pos[0], c.pos[1]) + 1.4, z: c.pos[1] }),
      action: () => ring(i),
    }));
    regs.forEach((r) => useGame.getState().registerInteractable(r));
    return () => regs.forEach((r) => useGame.getState().unregisterInteractable(r.id));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const t = state.clock.elapsedTime;
    // pendulum springs
    for (let i = 0; i < 4; i++) {
      bellVel.current[i] += (-bellSwing.current[i] * 26 - bellVel.current[i] * 4.5) * dt;
      bellSwing.current[i] += bellVel.current[i] * dt;
      const b = bells.current[i];
      if (b) {
        b.rotation.z = bellSwing.current[i];
        b.rotation.x = Math.sin(t * 0.8 + i * 2) * 0.03;
      }
      // bell ripples
      const rm = ripples.current[i];
      if (rm) {
        rippleT.current[i] += dt;
        const life = 1.1;
        const k = rippleT.current[i];
        rm.scale.setScalar(0.4 + k * 2.6);
        (rm.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.6 * (1 - k / life));
      }
      // seed-dots above the vault
      const d = dots.current[i];
      if (d) {
        const lit = vaultAt > 0 || progress.current > i;
        const mat = d.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = THREE.MathUtils.damp(mat.emissiveIntensity, lit ? 2.6 : 0.12, 5, dt);
        // dots live inside the vault group (already lifted by vy)
        d.position.y = 2.5 + i * 0.28 + Math.sin(t * 2 + i * 1.4) * 0.04;
      }
    }
    // Rootheart core
    const target = vaultAt > 0 ? Math.min(1, (Date.now() - vaultAt) / 2600) : 0;
    (core.current.material as THREE.MeshStandardMaterial).emissiveIntensity =
      0.25 + target * 3.2 + Math.sin(t * 2.4) * (0.06 + target * 0.22);
    if (coreLight.current) coreLight.current.intensity = target * 12 + progress.current * 1.2;
    coreHalo.current.material.opacity = 0.14 + target * 0.5;
    coreHalo.current.scale.setScalar(1.4 + target * 2.6);
  });

  return (
    <group>
      {/* ---------- hanging root-bells ---------- */}
      {CHIMES.map((c, i) => {
        const [cx, cz] = c.pos;
        const cy = rootHeight(cx, cz);
        const anchorY = cy + 1.5 + c.hang;
        return (
          <group key={c.id}>
            {/* cord + knotted root to the ceiling rib */}
            <mesh position={[cx, cy + 1.5 + c.hang / 2 + 0.75, cz]}>
              <cylinderGeometry args={[0.02, 0.03, c.hang + 1.5, 5]} />
              <meshStandardMaterial color="#4a3826" roughness={1} />
            </mesh>
            <mesh position={[cx, anchorY, cz]}>
              <dodecahedronGeometry args={[0.22, 0]} />
              <meshStandardMaterial color="#54402c" roughness={1} />
            </mesh>
            <group
              ref={(el) => {
                if (el) bells.current[i] = el;
              }}
              position={[cx, cy + 1.5, cz]}
            >
              <mesh
                castShadow
                onClick={(e) => {
                  e.stopPropagation();
                  if (RT.wasDrag) return;
                  ring(i);
                }}
              >
                {/* petal-bell: a comet-shaped chime of grown bronze */}
                <sphereGeometry args={[0.3, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
                <meshPhysicalMaterial
                  color={c.tint}
                  metalness={0.75}
                  roughness={0.3}
                  clearcoat={0.6}
                  emissive={c.tint}
                  emissiveIntensity={0.12}
                  side={THREE.DoubleSide}
                />
              </mesh>
              <mesh position={[0, -0.16, 0]}>
                <sphereGeometry args={[0.07, 8, 6]} />
                <meshStandardMaterial color={c.glow} emissive={c.glow} emissiveIntensity={0.9} />
              </mesh>
              <sprite scale={[1.15, 1.15, 1]}>
                <spriteMaterial map={glowTex} color={c.glow} transparent opacity={0.32} depthWrite={false} />
              </sprite>
            </group>
            {/* ground ripple when rung */}
            <mesh
              ref={(el) => {
                if (el) ripples.current[i] = el;
              }}
              position={[cx, cy + 0.05, cz]}
              rotation={[-Math.PI / 2, 0, 0]}
            >
              <ringGeometry args={[0.5, 0.56, 28]} />
              <meshBasicMaterial color={c.glow} transparent opacity={0} depthWrite={false} />
            </mesh>
          </group>
        );
      })}

      {/* ---------- the Rootheart ---------- */}
      <group position={[vx, vy, vz]}>
        {/* stone nest */}
        <mesh position={[0, 0.18, 0]} receiveShadow>
          <dodecahedronGeometry args={[0.9, 0]} />
          <meshStandardMaterial color="#5c5244" roughness={1} />
        </mesh>
        {/* crystal prongs */}
        {[0, 1, 2, 3].map((i) => {
          const a = (i / 4) * Math.PI * 2 + 0.4;
          return (
            <mesh key={i} position={[Math.cos(a) * 0.72, 0.75, Math.sin(a) * 0.72]} rotation={[0.3 * Math.cos(a), 0, -0.3 * Math.sin(a)]} castShadow>
              <octahedronGeometry args={[0.32, 0]} />
              <meshStandardMaterial
                color="#c9b8ff"
                emissive="#8a6ae0"
                emissiveIntensity={vaultAt > 0 ? 1.4 : 0.18}
                roughness={0.15}
                transparent
                opacity={0.92}
              />
            </mesh>
          );
        })}
        {/* heart */}
        <mesh ref={core} position={[0, 1.05, 0]}>
          <icosahedronGeometry args={[0.36, 1]} />
          <meshStandardMaterial color="#2a1f14" emissive="#ff9d3c" emissiveIntensity={0.25} roughness={0.4} />
        </mesh>
        <sprite ref={coreHalo} position={[0, 1.1, 0]} scale={[1.4, 1.4, 1]}>
          <spriteMaterial map={glowTex} color="#ffb45e" transparent opacity={0.15} depthWrite={false} />
        </sprite>
        <pointLight ref={coreLight} position={[0, 1.3, 0]} color="#ff9d3c" intensity={0} distance={9} decay={2} />
        {/* seed-dots: visible progress for the seed-chord */}
        {[0, 1, 2, 3].map((i) => (
          <mesh
            key={i}
            ref={(el) => {
              if (el) dots.current[i] = el;
            }}
            position={[0, vy * 0 + 2.5 + i * 0.28, 0]}
          >
            <sphereGeometry args={[0.085, 10, 8]} />
            <meshStandardMaterial color="#3a2e1c" emissive="#ffd9a0" emissiveIntensity={0.12} />
          </mesh>
        ))}
      </group>
    </group>
  );
}
