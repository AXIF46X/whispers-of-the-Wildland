/**
 * Loamglider.tsx — the Hollow Root's keeper creature (original design).
 *
 * A blind pangolin-glider that reads the world through vibration: sweeping
 * translucent ears, whisker-tuned footsteps, and a memory of the seed-chord
 * in its muscles. It patrols the cavern, periodically hums the tune by
 * bumping the root-bells in order — and will gladly repeat the lesson if
 * asked.
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { CHIMES, LOAM_HOME, SEQUENCE } from "./rootLayout";
import { rootHeight } from "./rootTerrain";
import { RT } from "../../runtime";
import { useGame } from "../../store";
import { audio } from "../../audio";
import { chimeBus } from "./ChimePuzzle";
import { makeGlowTexture } from "../../world/textures";

type Mode = "patrol" | "demo" | "returning";

export default function Loamglider() {
  const group = useRef<THREE.Group>(null!);
  const body = useRef<THREE.Group>(null!);
  const earL = useRef<THREE.Mesh>(null!);
  const earR = useRef<THREE.Mesh>(null!);
  const glowTex = useMemo(() => makeGlowTexture(), []);
  const ripples = useRef<THREE.Mesh[]>([]);
  const rippleT = useRef([9, 9]);

  const mode = useRef<Mode>("patrol");
  const patrolAngle = useRef(0);
  const demoStep = useRef(-1);
  const hasBumped = useRef(false);
  const demoClock = useRef(9); // first demo comes early — it's the region's tutorial
  const stepClock = useRef(0);
  const vibr = useRef(0);
  const yaw = useRef(0);
  const saidHello = useRef(false);

  const tmp = useMemo(() => ({ target: new THREE.Vector3(), v: new THREE.Vector3() }), []);

  /* interactable: ask for the song */
  useEffect(() => {
    useGame.getState().registerInteractable({
      id: "loamglider",
      label: "Ask for the seed-chord",
      radius: 2.4,
      enabled: true,
      getPos: () => ({ x: group.current.position.x, y: group.current.position.y + 0.4, z: group.current.position.z }),
      action: () => {
        const s = useGame.getState();
        s.observeCreature("Loamglider");
        s.say("Loamglider", "*hmm-mm… it presses an ear to the earth, then hurries off*");
        vibr.current = 1;
        if (mode.current !== "demo") {
          mode.current = "demo";
          demoStep.current = -1;
          stepClock.current = 0.4;
        }
      },
    });
    return () => useGame.getState().unregisterInteractable("loamglider");
  }, []);

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const t = state.clock.elapsedTime;
    const gs = useGame.getState();
    const p = group.current.position;

    const playerDist = Math.hypot(RT.playerPos.x - p.x, RT.playerPos.z - p.z);

    /* greet the player once */
    if (!saidHello.current && playerDist < 3.4 && gs.phase === "explore") {
      saidHello.current = true;
      gs.observeCreature("Loamglider");
      gs.say("Loamglider", "*vrmmm… hmm-mm-MM-mm?* — it noticed your footsteps");
      vibr.current = 1.4;
      audio.chirp("call");
    }

    /* autonomous demonstration on a cadence */
    if (mode.current === "patrol" && gs.vaultAt === 0) {
      demoClock.current -= dt;
      if (demoClock.current <= 0) {
        mode.current = "demo";
        demoStep.current = -1;
        stepClock.current = 0.6;
      }
    }

    /* ---------- steering targets ---------- */
    const speedRef = { speed: 1.1 };
    if (mode.current === "patrol") {
      patrolAngle.current += dt * 0.22;
      const r = 2.2;
      tmp.target.set(
        LOAM_HOME[0] + Math.cos(patrolAngle.current) * r,
        0,
        LOAM_HOME[1] + Math.sin(patrolAngle.current) * r
      );
    } else if (mode.current === "demo") {
      speedRef.speed = 2.4;
      stepClock.current -= dt;
      if (demoStep.current === -1 || stepClock.current <= 0) {
        // advance to the next bell in the chord
        demoStep.current++;
        hasBumped.current = false;
        if (demoStep.current >= SEQUENCE.length) {
          mode.current = "returning";
        } else {
          stepClock.current = 999; // wait until arrival
        }
      }
      if (mode.current === "demo") {
        const c = CHIMES[SEQUENCE[demoStep.current]];
        tmp.target.set(c.pos[0], 0, c.pos[1] - 1.1);
        const d = Math.hypot(tmp.target.x - p.x, tmp.target.z - p.z);
        if (d < 0.5 && !hasBumped.current) {
          hasBumped.current = true;
          // bump the bell — vibration spike + ripples
          chimeBus.ring(SEQUENCE[demoStep.current]);
          vibr.current = 1.6;
          rippleT.current[0] = 0;
          if (demoStep.current === 0 && gs.vaultAt === 0) {
            gs.say("Loamglider", "*it hums the old tune — bell by bell…*");
            gs.markProgress();
          }
          stepClock.current = 1.05;
        }
      }
    } else {
      tmp.target.set(LOAM_HOME[0], 0, LOAM_HOME[1]);
      if (Math.hypot(tmp.target.x - p.x, tmp.target.z - p.z) < 0.6) {
        mode.current = "patrol";
        demoClock.current = 17 + Math.random() * 9;
      }
    }

    /* ---------- locomotion (damped, terrain-hugging) ---------- */
    const k = 1 - Math.exp(-speedRef.speed * 2.2 * dt);
    p.x = THREE.MathUtils.lerp(p.x, tmp.target.x, k);
    p.z = THREE.MathUtils.lerp(p.z, tmp.target.z, k);
    p.y = rootHeight(p.x, p.z) + 0.3;

    tmp.v.set(tmp.target.x - p.x, 0, tmp.target.z - p.z);
    if (tmp.v.lengthSq() > 0.004) {
      const targetYaw = Math.atan2(tmp.v.x, tmp.v.z);
      let diff = targetYaw - yaw.current;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      yaw.current += diff * (1 - Math.exp(-6 * dt));
    }
    group.current.rotation.y = yaw.current;

    /* ---------- body language ---------- */
    speedRef.speed = Math.min(2.6, tmp.v.length());
    body.current.position.y = Math.abs(Math.sin(t * 9)) * 0.03 * speedRef.speed;
    body.current.rotation.z = Math.sin(t * 7) * 0.04 * speedRef.speed;

    // ears comically over-perform every vibration
    vibr.current = Math.max(0, vibr.current - dt * 1.4);
    const wob = Math.sin(t * 26) * 0.28 * vibr.current + Math.sin(t * 5) * 0.1;
    earL.current.rotation.z = -0.5 + wob;
    earR.current.rotation.z = 0.5 - wob;

    // ground ripples from footfalls — they follow the keeper
    rippleT.current.forEach((rt, i) => {
      rippleT.current[i] = rt + dt;
      const m = ripples.current[i];
      if (!m) return;
      m.position.set(p.x, rootHeight(p.x, p.z) + 0.03, p.z);
      const life = 1.3;
      m.scale.setScalar(0.3 + rt * 2);
      (m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.4 * (1 - rt / life));
      if (mode.current === "demo" && rt > 0.7 && speedRef.speed > 0.05) rippleT.current[i] = 0;
    });
  });

  return (
    <group>
      <group ref={group} position={[LOAM_HOME[0], rootHeight(LOAM_HOME[0], LOAM_HOME[1]) + 0.3, LOAM_HOME[1]]}>
        <group ref={body}>
          {/* humped plated body */}
          <mesh castShadow scale={[1.15, 0.72, 0.9]}>
            <sphereGeometry args={[0.34, 18, 14]} />
            <meshStandardMaterial color="#7a6a50" roughness={0.85} />
          </mesh>
          {[0.14, 0.3, 0.45].map((o, i) => (
            <mesh key={i} position={[o - 0.28, 0.16, 0]} rotation={[0, 0, -0.5 + i * -0.14]} scale={[1, 0.5, 1.15]}>
              <torusGeometry args={[0.24, 0.07, 6, 14, Math.PI]} />
              <meshStandardMaterial color="#5c4c38" roughness={0.9} />
            </mesh>
          ))}
          {/* snout */}
          <mesh position={[0.38, 0.02, 0]} rotation={[0, 0, -Math.PI / 2.2]}>
            <coneGeometry args={[0.09, 0.24, 8]} />
            <meshStandardMaterial color="#8a7a5c" roughness={0.9} />
          </mesh>
          {/* whiskers */}
          <mesh position={[0.46, 0.06, 0.05]} rotation={[0.9, 0, -1.2]}>
            <cylinderGeometry args={[0.004, 0.004, 0.17, 3]} />
            <meshBasicMaterial color="#d9cbb0" />
          </mesh>
          <mesh position={[0.46, 0.06, -0.05]} rotation={[-0.9, 0, -1.2]}>
            <cylinderGeometry args={[0.004, 0.004, 0.17, 3]} />
            <meshBasicMaterial color="#d9cbb0" />
          </mesh>
          {/* vibration-reading ears — large, veined, translucent */}
          <mesh ref={earL} position={[-0.08, 0.3, 0.16]} rotation={[0.5, 0, -0.5]}>
            <coneGeometry args={[0.13, 0.34, 8]} />
            <meshPhongMaterial color="#c9a8a0" transparent opacity={0.75} shininess={60} emissive="#5a4038" side={THREE.DoubleSide} />
          </mesh>
          <mesh ref={earR} position={[-0.08, 0.3, -0.16]} rotation={[-0.5, 0, 0.5]}>
            <coneGeometry args={[0.13, 0.34, 8]} />
            <meshPhongMaterial color="#c9a8a0" transparent opacity={0.75} shininess={60} emissive="#5a4038" side={THREE.DoubleSide} />
          </mesh>
          {/* stub tail */}
          <mesh position={[-0.4, 0.02, 0]} rotation={[0, 0, 1.2]}>
            <coneGeometry args={[0.06, 0.22, 6]} />
            <meshStandardMaterial color="#6a5a44" roughness={0.9} />
          </mesh>
        </group>
        <sprite scale={[0.7, 0.7, 1]} position={[0, 0.25, 0]}>
          <spriteMaterial map={glowTex} color="#ffca90" transparent opacity={0.14} depthWrite={false} />
        </sprite>
      </group>
      {/* footfall ripples — the Loamglider's way of seeing */}
      {[0, 1].map((i) => (
        <mesh
          key={i}
          ref={(el) => {
            if (el) ripples.current[i] = el;
          }}
          position={[LOAM_HOME[0], rootHeight(LOAM_HOME[0], LOAM_HOME[1]) + 0.03, LOAM_HOME[1]]}
          rotation={[-Math.PI / 2, 0, 0]}
        >
          <ringGeometry args={[0.4, 0.45, 24]} />
          <meshBasicMaterial color="#ffca90" transparent opacity={0} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}
