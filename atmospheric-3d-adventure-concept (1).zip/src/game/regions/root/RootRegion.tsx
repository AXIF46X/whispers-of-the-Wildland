/**
 * RootRegion.tsx — Region 02, "The Hollow Root". Composition root for the
 * region: installs its sampler into the world façade, lights the cavern,
 * and hosts the Seed-Chord puzzle, the Loamglider keeper, region
 * collectibles, and the Rootway gates (home ⇆ garden / onward, sealed).
 */
import { useGame } from "../../store";
import {
  ROOT_MOTES,
  ROOT_PORTAL_GARDEN,
  ROOT_PORTAL_STREAM,
  ROOT_VAULT,
  VAULT_MEMORY,
} from "./rootLayout";
import HollowRoot from "./HollowRoot";
import ChimePuzzle from "./ChimePuzzle";
import Loamglider from "./Loamglider";
import Collectibles from "../../world/Collectibles";
import Portal from "../../world/Portal";

export default function RootRegion() {
  const phase = useGame((s) => s.phase);

  return (
    <>
      <HollowRoot />
      <ChimePuzzle />
      <Loamglider />
      <Collectibles
        motes={ROOT_MOTES}
        bloom={VAULT_MEMORY}
        bloomPos={[ROOT_VAULT.pos[0] + 1.3, ROOT_VAULT.pos[1] + 1.1]}
        bloomVisible={phase === "gather" || phase === "epilogue"}
        regionId="root"
        epilogueObjective="The Hollow hums — the Rootway home is open"
      />
      <Portal
        id="portal-root-garden"
        pos={ROOT_PORTAL_GARDEN}
        to="garden"
        label="Enter the Rootway — The Fallen Garden"
        tint="#a8e0b8"
      />
      <Portal
        id="portal-root-stream"
        pos={ROOT_PORTAL_STREAM}
        to={null}
        locked
        label="Rootway — The Glass Stream"
        tint="#8fd4ff"
        lockedNote="Rootway — The Glass Stream (dormant)"
      />
    </>
  );
}
