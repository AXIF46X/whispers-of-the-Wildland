/**
 * rootTerrain.ts — height field for Region 02, "The Hollow Root".
 * An enclosed cavern inside a dead root: a raised central dais for the
 * Rootheart, gentle hummocky floor, and a steep rim that climbs into the
 * rib-cage ceiling (pairs with the dome mesh in HollowRoot.tsx).
 */
const smooth = (t: number) => t * t * (3 - 2 * t);

export const ROOT_CEILING = 7.4;

export function rootHeight(x: number, z: number): number {
  let h =
    0.32 * Math.sin(x * 0.34 + 1.1) * Math.cos(z * 0.29 - 0.6) +
    0.16 * Math.sin(x * 0.85) * Math.sin(z * 0.72 + 2.1) +
    0.05 * Math.sin(x * 1.7 - z * 1.3);

  // central dais where the Rootheart nests
  const dc = Math.sqrt(x * x + z * z);
  if (dc < 3.6) h += 0.28 * smooth(1 - dc / 3.6);

  // cavern walls — steep rise into the root's ribcage
  const r = Math.sqrt(x * x + z * z);
  if (r > 12) {
    const t = smooth(Math.min(1, (r - 12) / 7));
    h += t * t * 11;
  }
  return h;
}

export function rootSlope(x: number, z: number, out: { fx: number; fz: number }) {
  const e = 0.35;
  out.fx = (rootHeight(x + e, z) - rootHeight(x - e, z)) / (2 * e);
  out.fz = (rootHeight(x, z + e) - rootHeight(x, z - e)) / (2 * e);
}
