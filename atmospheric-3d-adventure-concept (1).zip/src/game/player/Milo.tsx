/**
 * Milo.tsx — player character & controller.
 *
 * "A seed that remembered it was a machine." Fully procedural: glossy seed
 * body with heartlight seams, one big cinematic eye (looks at nearby points
 * of interest), four brass-twig legs with a parametric walk cycle, and a
 * sprout antenna with springy secondary motion. Movement is camera-relative
 * with acceleration damping, slope-aware tilting and world-bounds sliding.
 */
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { input } from "../input";
import { audio } from "../audio";
import { RT } from "../runtime";
import { useGame } from "../store";
import { sampler, sampleHeight, sampleSlope } from "../world/sampler";
import { makeLeafTexture } from "../world/textures";

const UP = new THREE.Vector3(0, 1, 0);

export default function Milo({ spawn }: { spawn: [number, number] }) {
  const group = useRef<THREE.Group>(null!);
  const inner = useRef<THREE.Group>(null!);
  const body = useRef<THREE.Mesh>(null!);
  const eye = useRef<THREE.Group>(null!);
  const legs = useRef<THREE.Group[]>([]);
  const sprout = useRef<THREE.Group>(null!);
  const coreLight = useRef<THREE.PointLight>(null!);
  const coreMesh = useRef<THREE.Mesh>(null!);
  const leafTex = useMemo(() => makeLeafTexture(), []);
  const quality = useGame((s) => s.settings.quality);

  const vel = useRef(new THREE.Vector3());
  const hopY = useRef(0);
  const hopVel = useRef(0);
  const landSquash = useRef(0);
  const walkPhase = useRef(0);
  const prevStepSign = useRef(1);
  const yaw = useRef(Math.PI);
  const lookTimer = useRef(2);
  const lookTarget = useRef(new THREE.Vector3(0, 0, -1));
  const slope = useRef({ fx: 0, fz: 0 });
  const tmp = useMemo(
    () => ({ fwd: new THREE.Vector3(), right: new THREE.Vector3(), move: new THREE.Vector3(), v: new THREE.Vector3() }),
    []
  );

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const t = state.clock.elapsedTime;
    const gs = useGame.getState();
    const controlsFree = !RT.cutscene && gs.panel === "none" && gs.phase !== "intro";

    // --- desired velocity (camera relative, analog-aware) ---
    tmp.fwd.set(0, 0, -1).applyQuaternion(state.camera.quaternion);
    tmp.fwd.y = 0;
    tmp.fwd.normalize();
    tmp.right.crossVectors(tmp.fwd, UP); // camera-right on XZ

    const mag = Math.min(1, Math.hypot(input.x, input.y));
    let targetSpeed = 0;
    if (controlsFree && mag > 0.01) {
      targetSpeed = (input.run || mag > 0.92 ? 4.4 : 2.3) * Math.max(mag, 0.35);
    }
    tmp.move.set(0, 0, 0);
    if (targetSpeed > 0) {
      tmp.move.addScaledVector(tmp.fwd, input.y).addScaledVector(tmp.right, input.x);
      if (tmp.move.lengthSq() > 0) tmp.move.normalize();
    }
    tmp.v.copy(tmp.move).multiplyScalar(targetSpeed);
    vel.current.lerp(tmp.v, 1 - Math.exp(-8 * dt));

    // --- integrate + bounds ---
    const p = group.current.position;
    p.addScaledVector(vel.current, dt);
    const rr = Math.hypot(p.x, p.z);
    if (rr > sampler.bounds) {
      const s = sampler.bounds / rr;
      p.x *= s;
      p.z *= s;
      vel.current.multiplyScalar(0.6);
    }
    if (Number.isNaN(p.x) || Number.isNaN(p.z)) p.set(spawn[0], 0, spawn[1]);
    const ground = sampleHeight(p.x, p.z);

    // --- hop: a short, springy arc (no double jumps) ---
    const grounded = hopY.current <= 0.0001 && hopVel.current <= 0;
    if (input.jump) {
      input.jump = false;
      if (grounded && controlsFree) {
        hopVel.current = 3.5;
        audio.hop();
      }
    }
    if (!grounded || hopVel.current > 0) {
      hopVel.current -= 11 * dt; // gravity
      hopY.current += hopVel.current * dt;
      if (hopY.current <= 0) {
        if (hopVel.current < -1.5) {
          landSquash.current = 1;
          audio.step();
        }
        hopY.current = 0;
        hopVel.current = 0;
      }
    }
    landSquash.current = Math.max(0, landSquash.current - dt * 4);
    p.y = ground + hopY.current;

    RT.playerPos.copy(p);
    RT.playerAirborne = hopY.current > 0.02;
    const speed = vel.current.length();
    RT.playerSpeed = speed;
    RT.playerMoving = speed > 0.25;
    RT.playerYaw = yaw.current;

    // --- facing ---
    if (speed > 0.3) {
      const targetYaw = Math.atan2(vel.current.x, vel.current.z);
      let diff = targetYaw - yaw.current;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      yaw.current += diff * (1 - Math.exp(-10 * dt));
    }
    group.current.rotation.y = yaw.current;

    // --- walk cycle / idle life ---
    const moveAmt = THREE.MathUtils.clamp(speed / 2.3, 0, 1.6);
    const air = RT.playerAirborne;
    walkPhase.current += dt * (4 + speed * 2.6);
    const ph = walkPhase.current;
    legs.current.forEach((leg, i) => {
      if (!leg) return;
      const phaseOff = (i % 2) * Math.PI + (i < 2 ? 0 : 0.6);
      if (air) {
        // tuck the legs mid-hop, splay them to land
        const tuck = hopVel.current > 0 ? 0.8 : -0.45;
        leg.rotation.x = THREE.MathUtils.damp(leg.rotation.x, tuck, 9, dt);
        leg.position.y = THREE.MathUtils.damp(leg.position.y, 0.14, 9, dt);
      } else {
        leg.rotation.x = Math.sin(ph + phaseOff) * 0.75 * moveAmt;
        leg.position.y = 0.1 + Math.max(0, Math.sin(ph + phaseOff + Math.PI / 2)) * 0.05 * moveAmt;
      }
    });
    // footsteps on stride zero-crossing
    const stepSign = Math.sign(Math.sin(ph));
    if (stepSign !== prevStepSign.current && moveAmt > 0.3 && RT.playerMoving && !air) {
      audio.step();
    }
    prevStepSign.current = stepSign;

    const breath = Math.sin(t * 2.1) * 0.02;
    const bob = air ? 0 : Math.abs(Math.sin(ph)) * 0.045 * moveAmt;
    inner.current.position.y = bob + (gs.settings.reducedMotion ? 0 : breath * 0.5);
    // squash & stretch: stretch on the way up, squash on landing
    const stretch = air ? THREE.MathUtils.clamp(hopVel.current * 0.05, -0.1, 0.12) : 0;
    const squash = landSquash.current * 0.16;
    body.current.scale.set(
      1 + breath - stretch + squash,
      1.06 - breath * 0.6 + bob * 0.4 + stretch - squash,
      0.94 + breath - stretch + squash
    );

    // slope alignment
    sampleSlope(p.x, p.z, slope.current);
    const fwdX = Math.sin(yaw.current);
    const fwdZ = Math.cos(yaw.current);
    const along = -(slope.current.fx * fwdX + slope.current.fz * fwdZ);
    inner.current.rotation.x = THREE.MathUtils.damp(inner.current.rotation.x, along * 0.5 + moveAmt * 0.06, 6, dt);
    inner.current.rotation.z = THREE.MathUtils.damp(inner.current.rotation.z, -(slope.current.fx * fwdZ - slope.current.fz * fwdX) * 0.35, 6, dt);

    // --- sprout secondary motion ---
    sprout.current.rotation.x = THREE.MathUtils.damp(sprout.current.rotation.x, -moveAmt * 0.28 + Math.sin(t * 3.2) * 0.05 * RT.wind, 5, dt);
    sprout.current.rotation.z = THREE.MathUtils.damp(sprout.current.rotation.z, Math.sin(t * 2.6) * 0.08 * RT.wind, 5, dt);

    // --- eye behaviour: focus interaction target, else wander ---
    lookTimer.current -= dt;
    const target = gs.interactTargetId ? gs.interactables[gs.interactTargetId] : null;
    if (target) {
      const tp = target.getPos();
      lookTarget.current.set(tp.x, tp.y, tp.z);
    } else if (lookTimer.current <= 0) {
      lookTimer.current = 2.5 + Math.random() * 3;
      const a = Math.random() * Math.PI * 2;
      lookTarget.current.set(p.x + Math.cos(a) * 3, p.y + 0.5 + Math.random(), p.z + Math.sin(a) * 3);
    }
    tmp.v.copy(lookTarget.current);
    eye.current.lookAt(tmp.v);

    // --- heartlight pulse ---
    const pulse = 0.5 + Math.sin(t * 2.4) * 0.18 + (gs.bloomAt ? 0.35 : 0);
    (coreMesh.current.material as THREE.MeshStandardMaterial).emissiveIntensity = pulse * 2;
    if (coreLight.current) coreLight.current.intensity = pulse * 0.9;
  });

  return (
    <group ref={group} position={[spawn[0], sampleHeight(spawn[0], spawn[1]), spawn[1]]}>
      <group ref={inner}>
        {/* seed body */}
        <mesh ref={body} position={[0, 0.42, 0]} castShadow>
          <sphereGeometry args={[0.26, 24, 18]} />
          <meshPhysicalMaterial color="#4a3626" roughness={0.35} metalness={0.15} clearcoat={0.6} />
        </mesh>
        {/* heartlight core visible through the cracked shell */}
        <mesh ref={coreMesh} position={[0, 0.4, 0.19]}>
          <sphereGeometry args={[0.075, 14, 12]} />
          <meshStandardMaterial color="#ffcf8a" emissive="#ffb45e" emissiveIntensity={1} roughness={0.3} />
        </mesh>
        {quality === "high" && (
          <pointLight ref={coreLight} position={[0, 0.45, 0.3]} color="#ffbf70" distance={2.4} decay={2} intensity={0.5} />
        )}
        {/* gear-fragment belt */}
        <mesh position={[0, 0.33, 0]} rotation={[Math.PI / 2 - 0.35, 0, 0.4]} castShadow>
          <torusGeometry args={[0.24, 0.035, 8, 20, Math.PI * 1.55]} />
          <meshStandardMaterial color="#b58a4a" metalness={0.9} roughness={0.35} />
        </mesh>
        {/* eye */}
        <group ref={eye} position={[0, 0.52, 0.2]}>
          <mesh>
            <sphereGeometry args={[0.105, 18, 14]} />
            <meshPhysicalMaterial color="#14100c" roughness={0.08} metalness={0.2} clearcoat={1} />
          </mesh>
          <mesh position={[0.032, 0.038, 0.088]}>
            <sphereGeometry args={[0.022, 8, 8]} />
            <meshBasicMaterial color="#fff6e0" />
          </mesh>
        </group>
        {/* sprout antenna */}
        <group ref={sprout} position={[0, 0.64, 0]}>
          <mesh position={[0, 0.09, 0]} rotation={[0.12, 0, -0.1]}>
            <cylinderGeometry args={[0.012, 0.02, 0.2, 6]} />
            <meshStandardMaterial color="#5d8a4a" roughness={0.7} />
          </mesh>
          <mesh position={[0.05, 0.2, 0]} rotation={[0, 0.5, -0.7]}>
            <planeGeometry args={[0.16, 0.22]} />
            <meshStandardMaterial map={leafTex} transparent alphaTest={0.3} side={THREE.DoubleSide} roughness={0.7} />
          </mesh>
          <mesh position={[-0.045, 0.19, 0.01]} rotation={[0, -0.6, 0.75]}>
            <planeGeometry args={[0.13, 0.18]} />
            <meshStandardMaterial map={leafTex} transparent alphaTest={0.3} side={THREE.DoubleSide} roughness={0.7} />
          </mesh>
        </group>
        {/* legs */}
        {[
          [0.15, 0.12],
          [-0.15, 0.12],
          [0.16, -0.12],
          [-0.16, -0.12],
        ].map(([lx, lz], i) => (
          <group
            key={i}
            ref={(el) => {
              if (el) legs.current[i] = el;
            }}
            position={[lx, 0.3, lz]}
          >
            <mesh position={[0, -0.2, 0]} castShadow>
              <capsuleGeometry args={[0.035, 0.3, 4, 8]} />
              <meshStandardMaterial color={i % 2 ? "#8a6a42" : "#7a5a38"} metalness={0.55} roughness={0.5} />
            </mesh>
          </group>
        ))}
      </group>
    </group>
  );
}
