/**
 * CameraRig.tsx — cinematic third-person / isometric hybrid.
 *
 * - smooth damped follow with spherical orbit (drag), wheel/pinch zoom
 * - intro establishing shot that hands control to the player seamlessly
 * - scripted cutscene channel (RT.cutscene) for the bloom moment
 * - terrain-aware minimum height, gentle handheld sway (reduced-motion safe)
 */
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame, useThree } from "@react-three/fiber";
import { RT } from "../runtime";
import { useGame } from "../store";
import { sampler, sampleHeight } from "../world/sampler";
import { SPAWN } from "../layout";
import { input } from "../input";

const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export default function CameraRig() {
  const camera = useThree((s) => s.camera);
  const gl = useThree((s) => s.gl);
  const yaw = useRef(0.1);
  const pitch = useRef(0.42);
  const dist = useRef(7.2);
  const look = useRef(new THREE.Vector3(0, 1, 8));
  const introT = useRef(0);
  const introDone = useRef(false);
  const recenterT = useRef(0);

  const intro = useMemo(() => {
    // the intro establishing shot only ever plays in the Fallen Garden
    const gy = sampleHeight(SPAWN[0], SPAWN[1]);
    return {
      fromPos: new THREE.Vector3(11, gy + 8.5, 24),
      fromLook: new THREE.Vector3(-4, gy + 2.4, 2),
      toPos: new THREE.Vector3(SPAWN[0] + 0.8, gy + 3.1, SPAWN[1] + 7.2),
      toLook: new THREE.Vector3(SPAWN[0], gy + 0.7, SPAWN[1]),
    };
  }, []);

  const tmp = useMemo(
    () => ({ desired: new THREE.Vector3(), target: new THREE.Vector3(), cutPos: new THREE.Vector3() }),
    []
  );

  /* orbit + zoom handlers */
  useEffect(() => {
    const el = gl.domElement;
    const pointers = new Map<number, { x: number; y: number }>();
    let dragged = false;
    let pinchDist = 0;
    let downAt = 0;

    const onDown = (e: PointerEvent) => {
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      dragged = false;
      RT.wasDrag = false;
      downAt = performance.now();
      input.anyKey = true; // a touch also skips the intro pan
      if (pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        pinchDist = Math.hypot(a.x - b.x, a.y - b.y);
      }
      el.setPointerCapture(e.pointerId);
    };
    const onMove = (e: PointerEvent) => {
      const prev = pointers.get(e.pointerId);
      if (!prev) return;
      const dx = e.clientX - prev.x;
      const dy = e.clientY - prev.y;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

      if (pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        const nd = Math.hypot(a.x - b.x, a.y - b.y);
        if (pinchDist > 0) {
          dist.current = THREE.MathUtils.clamp((dist.current * pinchDist) / Math.max(nd, 1), 3, 11.5);
        }
        pinchDist = nd;
        dragged = true;
        RT.wasDrag = true;
        return;
      }
      if (Math.abs(dx) + Math.abs(dy) > 2) dragged = true;
      if (dragged) {
        RT.wasDrag = true;
        recenterT.current = 0; // manual input cancels an auto-recenter
        const st = useGame.getState().settings;
        const sens = st.camSensitivity;
        yaw.current -= dx * 0.0052 * sens;
        pitch.current = THREE.MathUtils.clamp(
          pitch.current + dy * 0.0042 * sens * (st.invertY ? -1 : 1),
          0.06,
          1.25
        );
      }
    };
    const onUp = (e: PointerEvent) => {
      pointers.delete(e.pointerId);
      // a long press + drag shouldn't count as a tap; short quick drags ok
      if (!dragged && performance.now() - downAt > 600) RT.wasDrag = true;
    };
    const onWheel = (e: WheelEvent) => {
      dist.current = THREE.MathUtils.clamp(dist.current * Math.exp(e.deltaY * 0.0011), 3, 11.5);
      e.preventDefault();
    };

    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointercancel", onUp);
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointercancel", onUp);
      el.removeEventListener("wheel", onWheel);
    };
  }, [gl]);

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const gs = useGame.getState();
    const t = state.clock.elapsedTime;

    /* ---------- scripted cutscene channel ---------- */
    if (RT.cutscene) {
      const cs = RT.cutscene;
      cs.t += dt * (gs.settings.reducedMotion ? 4 : 1);
      const k = easeInOut(Math.min(1, cs.t / (cs.dur * 0.5)));
      tmp.cutPos.copy(cs.focus).add(cs.camOffset);
      camera.position.lerp(tmp.cutPos, 1 - Math.exp(-k * 4 * dt));
      look.current.lerp(cs.focus, 1 - Math.exp(-k * 5 * dt));
      camera.lookAt(look.current);
      if (cs.t >= cs.dur) {
        const done = cs.onDone;
        RT.cutscene = null;
        done?.();
      }
      return;
    }

    /* ---------- intro establishing shot ---------- */
    if (gs.phase === "intro" && !introDone.current) {
      const dur = gs.settings.reducedMotion ? 0.01 : 7;
      // hold the establishing frame while the controls note is up
      if (gs.settings.seenControls) introT.current += dt / dur;
      if (input.anyKey) introT.current = 1; // any input skips
      const k = easeInOut(Math.min(1, introT.current));
      camera.position.lerpVectors(intro.fromPos, intro.toPos, k);
      look.current.lerpVectors(intro.fromLook, intro.toLook, k);
      camera.lookAt(look.current);
      if (introT.current >= 1) {
        introDone.current = true;
        gs.setPhase("explore");
        gs.setObjective("Follow the Lume");
        gs.markProgress();
      }
      return;
    }

    /* ---------- keyboard camera + recenter ---------- */
    const set = gs.settings;
    if (input.camX !== 0 || input.camY !== 0) {
      recenterT.current = 0;
      yaw.current -= input.camX * 1.9 * set.camSensitivity * dt;
      pitch.current = THREE.MathUtils.clamp(
        pitch.current + input.camY * 1.3 * set.camSensitivity * (set.invertY ? -1 : 1) * dt,
        0.06,
        1.25
      );
    }
    if (input.zoom !== 0) {
      dist.current = THREE.MathUtils.clamp(dist.current * (1 + input.zoom * 1.4 * dt), 3, 11.5);
    }
    if (input.recenter) {
      input.recenter = false;
      recenterT.current = 1;
    }
    if (recenterT.current > 0) {
      // ease the orbit to sit behind Milo's shoulder
      const goal = RT.playerYaw + Math.PI;
      let diff = goal - yaw.current;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      yaw.current += diff * (1 - Math.exp(-6 * dt));
      pitch.current = THREE.MathUtils.damp(pitch.current, 0.42, 6, dt);
      recenterT.current -= dt;
      if (Math.abs(diff) < 0.01) recenterT.current = 0;
    }

    /* ---------- player follow ---------- */
    const p = RT.playerPos;
    const tr = sampleHeight(p.x, p.z);
    tmp.target.set(p.x, p.y + 0.62, p.z);

    const sp = Math.sin(pitch.current);
    const cp = Math.cos(pitch.current);
    tmp.desired.set(
      p.x + Math.sin(yaw.current) * cp * dist.current,
      tmp.target.y + sp * dist.current,
      p.z + Math.cos(yaw.current) * cp * dist.current
    );
    // never clip under the moss — or through the Hollow Root's ceiling
    tmp.desired.y = Math.max(tmp.desired.y, tr + 0.55);
    if (sampler.ceiling !== null) {
      tmp.desired.y = Math.min(tmp.desired.y, sampler.ceiling);
      // if the clamp would bury us in the wall on steep rims, pull closer
    }

    const posLerp = 1 - Math.exp(-5.2 * dt);
    camera.position.lerp(tmp.desired, posLerp);
    look.current.lerp(tmp.target, 1 - Math.exp(-6.5 * dt));

    // handheld breathing
    if (!gs.settings.reducedMotion) {
      const amp = RT.playerMoving ? 0.012 : 0.03;
      camera.position.y += Math.sin(t * 1.7) * amp;
      camera.position.x += Math.cos(t * 1.3) * amp * 0.6;
    }
    camera.lookAt(look.current);
  });

  return null;
}
