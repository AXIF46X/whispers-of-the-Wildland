/**
 * gdd.ts — content of the "Whispers of the Wildland" Game Design Document.
 * 100% original IP: creatures, regions, lore, mechanics and terminology are
 * written for this project and reference no existing game.
 */

export const PILLARS = [
  {
    title: "The World Is the Character",
    body: "The forest is not a backdrop — it breathes, listens and remembers. Every system (wind, water, vegetation, creatures) reacts to the player's presence and choices, and stays changed.",
  },
  {
    title: "Small Is Epic",
    body: "Authored at insect scale: a dewdrop is a lens, a leaf is a bridge, a puddle is an ocean. Macro-photography framing and shallow focus make the familiar feel monumental.",
  },
  {
    title: "Kindness as Mechanics",
    body: "Progress comes from helping — waking, feeding, guiding, repairing — never from fighting. Puzzles are conversations with an ecosystem.",
  },
  {
    title: "Show, Don't Explain",
    body: "Story is environmental and emotional: broken brass in living roots, drawings under bark, creature behaviour. Dialogue is minimal; meaning accumulates.",
  },
];

export interface Region {
  id: string;
  name: string;
  tagline: string;
  desc: string;
  hazard: string;
  puzzle: string;
  creature: string;
  palette: string;
  x: number; // map coordinates (0..100)
  y: number;
}

export const REGIONS: Region[] = [
  {
    id: "fallen-garden",
    name: "The Fallen Garden",
    tagline: "where Milo wakes",
    desc: "A seedbed clearing ringed by colossal clover and one exhausted sunbeam. Tutorial region — teaches movement, interaction, creature language and the first Heartlight rite.",
    hazard: "None (safe haven)",
    puzzle: "Staircase of Light — ricochet a sunbeam off three shard-stones",
    creature: "Lume, the Gardener-Moth",
    palette: "emerald / amber",
    x: 14, y: 72,
  },
  {
    id: "hollow-root",
    name: "The Hollow Root",
    tagline: "a staircase of veins",
    desc: "A spiraling descent inside a dead root, lit by syrup-channels that still pump faint light. Teaches climbing, crawling and pushing dislodged resin plugs.",
    hazard: "Slippery sap slides",
    puzzle: "Raise the sap elevators by redistributing weight",
    creature: "The Nibbly Brotherhood (seed collectors)",
    palette: "ochre / umber",
    x: 26, y: 60,
  },
  {
    id: "rain-chamber",
    name: "The Rain Chamber",
    tagline: "a storm held in a leaf",
    desc: "One curled leaf cups an entire weather system. Droplet physics region: redirect flow, fuse droplets into lenses, and time waterfalls to carry Milo upward.",
    hazard: "Flash rain bursts",
    puzzle: "Lens a sunbeam through fused droplets to etch a root-door",
    creature: "Quillfin the Damp (a very dignified puddle-skater)",
    palette: "teal / silver",
    x: 40, y: 70,
  },
  {
    id: "mushroom-valley",
    name: "The Mushroom Valley",
    tagline: "skyscrapers with gills",
    desc: "Bioluminescent towers of fungus. Cap platforms spring, tilt and release stored spores. Night-first region where light is a resource Milo carries.",
    hazard: "Spore gusts (visibility)",
    puzzle: "Arrange glowing caps into a rising path of echoes",
    creature: "The Underchime — a bell that learned to walk",
    palette: "violet / cyan",
    x: 52, y: 58,
  },
  {
    id: "forgotten-workshop",
    name: "The Forgotten Workshop",
    tagline: "brass inside bark",
    desc: "A hollow trunk converted into a laboratory by the First Gardeners. Broken bio-machines, seed looms, jars of sleeping light. The lore engine of the game.",
    hazard: "Unstable mechanisms",
    puzzle: "Repair a seed-loom: gear ratios grown, not built",
    creature: "Mosswright (a mechanical beetle gone feral-gardener)",
    palette: "brass / moss",
    x: 64, y: 66,
  },
  {
    id: "glass-stream",
    name: "The Glass Stream",
    tagline: "liquid light, moving",
    desc: "A stream so clear it reads as solid glass. Surface tension is walkable until startled. Skater insects offer ferries in exchange for gossip.",
    hazard: "Current surges after rain",
    puzzle: "Dam and release pools to float a leaf-ferry upstream",
    creature: "The Skim Choir (surface-tension singers)",
    palette: "crystal / gold",
    x: 74, y: 52,
  },
  {
    id: "sleeping-tree",
    name: "The Sleeping Tree",
    tagline: "a titan mid-dream",
    desc: "The largest being in the Wildland, snoring in decade-long breaths. Its dreams leak as playable memory bubbles; waking it is the act-2 finale.",
    hazard: "Breath-wind cycles",
    puzzle: "Tuning-fork flowers — match the tree's dream-chord",
    creature: "Grandmother Slow (a moth older than the tree)",
    palette: "indigo / rose",
    x: 60, y: 40,
  },
  {
    id: "insect-cathedral",
    name: "The Insect Cathedral",
    tagline: "reverence with six legs",
    desc: "A grass-blade nave where a beetle congregation holds light-mass. Stained-dew windows. Social hub — creature relationships unlock routes and shortcuts.",
    hazard: "Ceremony schedules crowd the nave",
    puzzle: "Beetle choir: seat the singers so light hits the altar",
    creature: "Bishop Carapace & the congregation",
    palette: "stained amber / black",
    x: 46, y: 42,
  },
  {
    id: "underground-nest",
    name: "The Underground Nest",
    tagline: "the city that hums",
    desc: "A cooperative micro-city of tunnelers. Vibration is language; Milo learns to drum. Logistics puzzles at colony scale — move food, move light, move water.",
    hazard: "Total darkness between fungus lamps",
    puzzle: "Courier routing through one-way root-veins",
    creature: "The Hundred (a colony that speaks in plural)",
    palette: "earth / fungal green",
    x: 34, y: 46,
  },
  {
    id: "mirror-pond",
    name: "The Mirror Pond",
    tagline: "the reflection is older",
    desc: "A still pond whose reflection shows the garden as it was a century ago. Shadow-and-reflection puzzles: align present and memory to open sunken paths.",
    hazard: "Reflection-snatching wispfish",
    puzzle: "Stand shadows on symbols only the past can read",
    creature: "Old Underneath (the reflection's gardener)",
    palette: "black pearl / opal",
    x: 52, y: 28,
  },
  {
    id: "storm-canopy",
    name: "The Storm Canopy",
    tagline: "the roof of the world",
    desc: "Wind-torn leaf bridges high above the garden. Weather is authored here — Milo carries seeds between platforms riding gusts it feeds.",
    hazard: "Gale pulses, lightning static",
    puzzle: "Wind-sowing: germinate bridges across the gaps",
    creature: "Gustlings (seed-kites with opinions)",
    palette: "storm green / electric",
    x: 68, y: 30,
  },
  {
    id: "the-heartwood",
    name: "The Heartwood",
    tagline: "where the light went",
    desc: "The final region beneath everything: a hollow lit by the withering Heartlight itself. The truth about the First Gardeners — and about Milo — waits here.",
    hazard: "Entropy blooms (time-slip pockets)",
    puzzle: "The Nine Rites — every verb the game taught, in concert",
    creature: "The Gardener's Echo",
    palette: "dying gold / new green",
    x: 52, y: 14,
  },
];

export interface Creature {
  name: string;
  kind: string;
  personality: string;
  sound: string;
  signature: string;
}

export const CREATURES: Creature[] = [
  { name: "Lume, the Gardener-Moth", kind: "Companion", personality: "Patient, playful, faintly worried", sound: "chirped prruu-trills", signature: "Leaves light-dust over interactive things" },
  { name: "The Nibbly Brotherhood", kind: "Colony (6)", personality: "Nervous collectively, brave in quorum", sound: "staccato *nib-nib* call-and-answer", signature: "Six legs, two seeds, zero coordination" },
  { name: "Quillfin the Damp", kind: "Puddle-skater", personality: "Dignified, easily offended", sound: "violin-like leg-bows on water", signature: "Bows before crossing any droplet" },
  { name: "Mosswright", kind: "Bio-mechanical beetle", personality: "Loyal, rusted, forgetting why", sound: "gear-whirr lullabies", signature: "Plants moss wherever it rests" },
  { name: "Underchime", kind: "Walking bell", personality: "Ceremonial, lonely", sound: "a single deep note when it sits", signature: "Rings when Milo is honest" },
  { name: "Skim Choir", kind: "Surface-tension singers", personality: "Gossipy, generous", sound: "ripple-harmonies in threes", signature: "Ferries passengers who compliment the water" },
  { name: "Grandmother Slow", kind: "Ancient moth", personality: "Vast, kind, speaks in decades", sound: "almost-silent wing-brush", signature: "Dust of her wings shows old paths" },
  { name: "Bishop Carapace", kind: "Beetle cleric", personality: "Pompous, secretly tender", sound: "mandible-click sermons", signature: "Polishes the stained-dew windows hourly" },
  { name: "The Hundred", kind: "Tunneler colony", personality: "Plural mind, singular appetite", sound: "soil-drumming grammar", signature: "Speak only in 'we'; trust slowly" },
  { name: "Old Underneath", kind: "Reflection-keeper", personality: "Mirror of the player — literally", sound: "your own footsteps, half-delayed", signature: "Exists only in the Mirror Pond's surface" },
  { name: "Gustlings", kind: "Seed-kites", personality: "Opinionated meteorologists", sound: "paper-rattle arguments", signature: "Steal seeds they disapprove of" },
  { name: "The Gardener's Echo", kind: "Final witness", personality: "Regret wearing a familiar shape", sound: "a heartbeat slowed into song", signature: "Knows Milo's name before he does" },
  { name: "Pipsparrow", kind: "Petal-bird", personality: "Chaotic archivist", sound: "steals one note from every melody", signature: "Nests inside forgotten pockets of the map" },
  { name: "Loamglider", kind: "Blind cave creature", personality: "Gentle, seismic listener", sound: "reads the world in low hums", signature: "Navigates by Milo's footsteps" },
  { name: "Thriftlings", kind: "Flower-dwellers", personality: "House-proud hermits", sound: "doorbell-petal chimes", signature: "Hide inside blooms; trade shelter for stories" },
  { name: "Barrow Moth", kind: "Dusk courier", personality: "Professional, unimpressed", sound: "two syllables: 'par-cel'", signature: "Delivers letters between regions" },
  { name: "Sundew Sisters", kind: "Carnivorous flora (reformed)", personality: "Apologetic, sticky", sound: "embarrassed leaf-rustling", signature: "Hold keys they (accidentally) ate" },
  { name: "The Cartographer", kind: "Map-carrying springtail", personality: "Precise, faintly smug", sound: "pencil-scritch footsteps", signature: "Fills in your map — for crumbs" },
  { name: "Hushwing", kind: "Predator turned sentry", personality: "Reformed, vigilant, ashamed", sound: "a hush with teeth in it", signature: "Guards bridges it once broke" },
  { name: "Embermites", kind: "Light-carriers", personality: "Devout, tiny, numerous", sound: "static-crackle psalms", signature: "Re-light extinguished lamps on feast days" },
  { name: "Wallow", kind: "Mud mammoth (tiny)", personality: "Sleepy philosopher", sound: "bass mud-bubbles", signature: "Its wallow becomes a fast-travel swamp" },
  { name: "Kestrel-Brass", kind: "Ancient machine-bird", personality: "Dormant, awaiting a song", sound: "clockwork dawn chorus", signature: "The last invention of the First Gardeners" },
];

export const SYSTEMS = [
  { name: "Player Controller", desc: "Camera-relative kinematic controller: walk/run analog move, slope alignment, world-bounds sliding, parametric gait, footstep events.", status: "PROTOTYPED" },
  { name: "Cinematic Camera", desc: "Damped third-person/isometric hybrid: orbit drag, wheel/pinch zoom, terrain-aware floor, scripted shot channel, reduced-motion variants.", status: "PROTOTYPED" },
  { name: "Interaction", desc: "Proximity registry + direct tap raycast with a context verb; single API for prisms, creatures, motes, props.", status: "PROTOTYPED" },
  { name: "Puzzle Framework", desc: "State-driven beam tracing with diegetic feedback (visible light path, audio swell, companion gesture cues).", status: "PROTOTYPED" },
  { name: "Companion AI (Lume)", desc: "FSM lead/hover/celebrate, waypoint hand-off, player leash, pointing darts at the next clue, invented sound language.", status: "PROTOTYPED" },
  { name: "Procedural Audio", desc: "Pure WebAudio: generative pentatonic score, wind/pad/shimmer beds, adaptive beam drone, synthesized creature dialects, gust-coupled vegetation.", status: "PROTOTYPED" },
  { name: "Hint System", desc: "Idle-time progressive hints plus on-demand reveal; resets on any meaningful progress. Never blocks, never nags.", status: "PROTOTYPED" },
  { name: "Journal & Collectibles", desc: "Memory motes and creature observations persist to local save; every collectible carries narrative value.", status: "PROTOTYPED" },
  { name: "Accessibility", desc: "Quality presets, subtitle sizing, colorblind-safe subtitle mode, reduced motion, volume, simplified controls.", status: "PROTOTYPED" },
  { name: "Save / Load", desc: "Settings + journal auto-persist; chapter checkpoints and region streaming slots planned for full build.", status: "PARTIAL" },
  { name: "Weather & Day Cycle", desc: "Authored gust scheduler live; full rain/wind/night simulation with creature sheltering behaviour targeted for Phase 3.", status: "PLANNED" },
  { name: "Inventory & Combination", desc: "Carried seeds, lenses and keys; combine-at-context rather than grid tetris. Data model stubbed, UI Phase 2.", status: "PLANNED" },
  { name: "Creature Observation", desc: "Behavioral encyclopedia that fills as you watch creatures act, not as you catch them.", status: "PLANNED" },
  { name: "Region Streaming", desc: "Rootway network: regions mount/unmount as streamed volumes behind a travel fade; shared actors work against the region sampler façade.", status: "PROTOTYPED" },
  { name: "Level Streaming & LOD", desc: "Region-volume streaming, baked light probes, LOD chains and texture compression for Android presets.", status: "PARTIAL" },
];

export const FOLDER_TREE = `wildland/
├── src/
│   ├── App.tsx                    # shell: title / game / document routes
│   ├── TitleScreen.tsx            # cinematic title & main menu
│   ├── data/gdd.ts                # design-document content (single source)
│   ├── doc/DesignDoc.tsx          # the living game-design document
│   └── game/
│       ├── Game.tsx               # composition root + global systems
│       ├── store.ts               # discrete game state (zustand, persisted)
│       ├── runtime.ts             # per-frame mutable channel (no re-render)
│       ├── input.ts               # unified keyboard + joystick vector
│       ├── audio.ts               # procedural WebAudio engine
│       ├── layout.ts              # authored world-space constants
│       ├── terrain.ts             # analytic height field (art == logic)
│       ├── player/
│       │   ├── Milo.tsx           # character + controller
│       │   └── CameraRig.tsx      # cinematic hybrid camera
│       ├── creatures/
│       │   └── WispMoth.tsx       # Lume: companion FSM + dialect
│       ├── puzzles/
│       │   └── SunbeamPuzzle.tsx  # "Staircase of Light" beam tracing
│       ├── world/
│       │   ├── Environment.tsx    # terrain, flora, particles, Bloomheart
│       │   ├── Collectibles.tsx   # memory motes
│       │   └── textures.ts        # runtime canvas-generated textures
│       └── ui/
│           ├── HUD.tsx            # objective, subtitles, prompts, cards
│           ├── Overlays.tsx       # settings / map / journal panels
│           └── Joystick.tsx       # virtual movement control`;

export interface Phase {
  n: string;
  title: string;
  items: string[];
  live?: boolean;
}

export const ROADMAP: Phase[] = [
  {
    n: "01",
    title: "Playable Prototype — this build",
    live: true,
    items: [
      "Fallen Garden diorama at insect scale",
      "Milo controller + cinematic hybrid camera",
      "Lume companion with lead/guide behaviour",
      "Staircase of Light prism puzzle + bloom cinematic",
      "4 memory motes, journal, map, settings, hints",
      "Procedural adaptive soundtrack & SFX",
      "Touch joystick + drag orbit + pinch zoom",
      "Quality presets for scalable devices",
      "Rootway portals + Region 02 'The Hollow Root' (Loamglider, Seed-Chord puzzle, own biome)",
    ],
  },
  {
    n: "02",
    title: "Systems Core",
    items: [
      "Inventory & item combination (seeds / lenses / keys)",
      "Dialogue-emote framework for creature conversations",
      "Checkpoint save/load + region memory",
      "3 more puzzle archetypes (water / sound / wind)",
      "Creature behaviour toolkit (perch, flee, follow, work)",
    ],
  },
  {
    n: "03",
    title: "World Structure",
    items: [
      "12-region connected map + streaming volumes",
      "Region identities, hazards, collectibles, story events",
      "Hub logic: restored regions change & repopulate",
    ],
  },
  {
    n: "04",
    title: "Environmental Art Pass",
    items: [
      "Macro-quality vegetation & material library",
      "Volumetrics, water sim upgrade, mud & wetness",
      "Day/night + full weather director",
    ],
  },
  {
    n: "05",
    title: "Animation & Audio Pass",
    items: [
      "22 creature rigs + emotional animation sets",
      "Full regional soundscapes & dynamic score stems",
      "Cinematics for rites, memories, ending",
    ],
  },
  { n: "06", title: "Optimization", items: ["LOD chains, occlusion, texture compression", "GPU particle pools", "30/60 fps device budgets"] },
  { n: "07", title: "Accessibility", items: ["Full remap, assist modes", "Screen-reader journal", "Motion/contrast suite"] },
  { n: "08", title: "Testing", items: ["AI-assisted fuzz playthroughs", "Puzzle analytics & hint tuning", "Localization dry-run"] },
  { n: "09", title: "Release", items: ["Android + PC builds", "Store presence & demo slice", "Post-launch region: The Salt Lanterns"] },
];

export const AI_NOTES = [
  { area: "Procedural variation", use: "Seeded scatter for vegetation, particle fields, path wear — deterministic per save so QA stays reproducible." },
  { area: "Adaptive behaviour", use: "Creature FSMs with player-distance leases, mood weights and sheltering heuristics — authored rules, AI-tuned parameters." },
  { area: "Ambient audio", use: "Generative score layers mixed by game state (explore / mystery / danger / bloom) — no random stems at runtime without bounds." },
  { area: "Development assists", use: "Concept-art pass for regions/creatures (used in this document), texture seeds, dialogue drafts, synthetic playtest fuzzing and bug triage." },
  { area: "Guardrails", use: "No uncontrolled runtime generation: any AI-produced asset is reviewed for performance, consistency, safety and licensing before shipping." },
];

export const STORY_BEATS = [
  {
    title: "Awakening",
    body: "Milo cracks out of a seed that should not contain machine parts. The garden is dim; the Heartlight that feeds it is a dying pulse beneath the roots. A gardener-moth decides he is worth the trouble.",
  },
  {
    title: "The First Rite",
    body: "By returning one sunbeam to one flower, Milo learns the game's grammar: light is life, and the world responds. The Bloomheart's memory reveals the lamp-network — eleven more gardens, all going dark.",
  },
  {
    title: "The First Gardeners",
    body: "Fragments collect into a civilization that grew machines the way other civilizations built them: seed-looms, brass pollinators, a bird that sings dawn. They didn't vanish in a war. They finished something.",
  },
  {
    title: "The Mirror",
    body: "In the Mirror Pond, Milo's reflection keeps his shape half a moment too long. Old Underneath tends a garden that looks exactly like home — because home was planted from it.",
  },
  {
    title: "The Heartwood",
    body: "The last lamp holds the truth: the First Gardeners grew their successors out of seed and brass, and the Heartlight was never fuel. It was a lullaby the forest sings to keep itself alive — and lullabies need singers. Milo is one.",
  },
  {
    title: "Ending — 'The Wildland Sings'",
    body: "Milo replants the Heartlight into the network. Regions the player restored bloom in a closing montage; unrestored ones stay dim — saved, but waiting. Whether Milo is gardener, seed, or song is left to the player. The credits are a sunrise.",
  },
];
