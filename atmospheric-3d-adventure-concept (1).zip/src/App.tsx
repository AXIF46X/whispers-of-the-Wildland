/**
 * App.tsx — application shell with three routes:
 *   title → cinematic main menu
 *   game  → the Phase 1 playable prototype
 *   doc   → the living Game Design Document
 * The canvas unmounts while the document is open (saves GPU & battery);
 * journal, settings and story progress persist in the zustand save.
 */
import { useState } from "react";
import TitleScreen from "./TitleScreen";
import Game from "./game/Game";
import DesignDoc from "./doc/DesignDoc";

type View = "title" | "game" | "doc";

export default function App() {
  const [view, setView] = useState<View>("title");
  const [docFrom, setDocFrom] = useState<"title" | "game">("title");

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0b140d] font-body text-mist">
      {view === "title" && (
        <TitleScreen
          onEnter={() => setView("game")}
          onDoc={() => {
            setDocFrom("title");
            setView("doc");
          }}
        />
      )}
      {view === "game" && (
        <Game
          onOpenDoc={() => {
            setDocFrom("game");
            setView("doc");
          }}
        />
      )}
      {view === "doc" && (
        <DesignDoc onBack={() => setView(docFrom)} onPlay={() => setView("game")} />
      )}
    </div>
  );
}
